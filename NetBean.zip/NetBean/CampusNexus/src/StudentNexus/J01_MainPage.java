/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import com.mysql.cj.jdbc.PreparedStatementWrapper;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RootPaneContainer;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.*;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;

class DBdata extends J01_MainPage{
    
    public void ConnectionCreationMethod() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");      //Loading Driver into memory
//            conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "1234");
            conn= DriverManager.getConnection("jdbc:mysql://database-mysqlworkbench-aws.c7imqsyistkg.ap-south-1.rds.amazonaws.com/", "adminabhi", "abhi25022004");
            System.out.println("Connection Established");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Connection Failed");
            System.out.println(e);
        }
    }
    
    public void DBCreationMethod() {
        try {
            String query0 = "DROP DATABASE IF EXISTS gui";
            PreparedStatement stmt0 = conn.prepareStatement(query0);
            stmt0.executeUpdate();
            String query = "CREATE DATABASE IF NOT EXISTS gui";
            PreparedStatement stmt1 = conn.prepareStatement(query);
            stmt1.executeUpdate();
            String query1 = "USE gui";
            PreparedStatement stmt2 = conn.prepareStatement(query1);
            stmt2.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Database Creation Failed");
            System.out.println(e);
        }
    }

    public void createDB() {
        try {
            String queryAdmin = "CREATE TABLE Admin(AdminID INT PRIMARY KEY, FirstName VARCHAR(50), LastName VARCHAR(50), Email VARCHAR(50) UNIQUE)";
            PreparedStatement stmtAdmin = conn.prepareStatement(queryAdmin);
            stmtAdmin.executeUpdate();

            // Branch Table
            String queryBranch = "CREATE TABLE Branch(BranchID INT PRIMARY KEY, BranchName VARCHAR(50))";
            PreparedStatement stmtBranch = conn.prepareStatement(queryBranch);
            stmtBranch.executeUpdate();

            // Student Table
            String queryStudent = "CREATE TABLE Student(PRN INT PRIMARY KEY, FirstName VARCHAR(50), LastName VARCHAR(50), Year INT, BranchID INT, Semester INT, DOB DATE, FathersName VARCHAR(50), Email VARCHAR(50) UNIQUE, AddressStreetName VARCHAR(50), AddressStreetNumber VARCHAR(50), AddressZipCode VARCHAR(10), AddressState VARCHAR(50), AddressCity VARCHAR(50), FOREIGN KEY (BranchID) REFERENCES Branch(BranchID))";
            PreparedStatement stmtStudent = conn.prepareStatement(queryStudent);
            stmtStudent.executeUpdate();

            // PhoneNumber Table
            String queryPhoneNumber = "CREATE TABLE Phonenumber(PRN INT PRIMARY KEY, PhoneNumber1 VARCHAR(15) UNIQUE, PhoneNumber2 VARCHAR(15) UNIQUE, FOREIGN KEY (PRN) REFERENCES Student(PRN))";
            PreparedStatement stmtPhoneNumber = conn.prepareStatement(queryPhoneNumber);
            stmtPhoneNumber.executeUpdate();

            // AdminLogin Table
            String queryAdminLogin = "CREATE TABLE Adminlogin(AdminID INT PRIMARY KEY, AdminPassword VARCHAR(50), FOREIGN KEY (AdminID) REFERENCES Admin(AdminID))";
            PreparedStatement stmtAdminLogin = conn.prepareStatement(queryAdminLogin);
            stmtAdminLogin.executeUpdate();

            // StudentLogin Table
            String queryStudentLogin = "CREATE TABLE Studentlogin(PRN INT PRIMARY KEY, StudentPassword VARCHAR(50), FOREIGN KEY (PRN) REFERENCES Student(PRN))";
            PreparedStatement stmtStudentLogin = conn.prepareStatement(queryStudentLogin);
            stmtStudentLogin.executeUpdate();

            // Hostel Table
            String queryHostel = "CREATE TABLE Hostel(PRN INT PRIMARY KEY, Gender VARCHAR(6), SimpleRoom VARCHAR(3), LuxuryRoom VARCHAR(3), FOREIGN KEY (PRN) REFERENCES Student(PRN))";
            PreparedStatement stmtHostel = conn.prepareStatement(queryHostel);
            stmtHostel.executeUpdate();

            // Library Table
            String queryLibrary = "CREATE TABLE Library(LibraryID INT, Category VARCHAR(50), Issue DATE, Return1 DATE)";
            PreparedStatement stmtLibrary = conn.prepareStatement(queryLibrary);
            stmtLibrary.executeUpdate();

            // Faculty Table
            String queryFaculty = "CREATE TABLE Faculty(FacultyID INT PRIMARY KEY, FacultyName VARCHAR(50), BranchID INT, FOREIGN KEY (BranchID) REFERENCES Branch(BranchID))";
            PreparedStatement stmtFaculty = conn.prepareStatement(queryFaculty);
            stmtFaculty.executeUpdate();

            // Course Table
            String queryCourse = "CREATE TABLE Course(CourseID INT PRIMARY KEY, CourseName VARCHAR(50), Duration VARCHAR(50), BranchID INT, FOREIGN KEY (BranchID) REFERENCES Branch(BranchID))";
            PreparedStatement stmtCourse = conn.prepareStatement(queryCourse);
            stmtCourse.executeUpdate();

            // TimeTable Table
            String queryTimeTable = "CREATE TABLE Timetable(TimetableID INT PRIMARY KEY, CourseID INT, FacultyID INT, RoomNumber VARCHAR(50), Timing VARCHAR(50), FOREIGN KEY (FacultyID) REFERENCES Faculty(FacultyID), FOREIGN KEY (CourseID) REFERENCES Course(CourseID))";
            PreparedStatement stmtTimeTable = conn.prepareStatement(queryTimeTable);
            stmtTimeTable.executeUpdate();

            // Grades Table
            String queryGrades = "CREATE TABLE Grades(PRN INT PRIMARY KEY, MidSem FLOAT, EndSem FLOAT, FOREIGN KEY (PRN) REFERENCES Student(PRN))";
            PreparedStatement stmtGrades = conn.prepareStatement(queryGrades);
            stmtGrades.executeUpdate();

            // Attendance Table
            String queryAttendance = "CREATE TABLE Attendance(PRN INT PRIMARY KEY, Percentage FLOAT, Date1 DATE, FOREIGN KEY (PRN) REFERENCES Student(PRN))";
            PreparedStatement stmtAttendance = conn.prepareStatement(queryAttendance);
            stmtAttendance.executeUpdate();

            // Fees Table
            String queryFees = "CREATE TABLE Fees(PRN INT PRIMARY KEY, PaidUnpaid VARCHAR(10), Fine FLOAT, FOREIGN KEY (PRN) REFERENCES Student(PRN))";
            PreparedStatement stmtFees = conn.prepareStatement(queryFees);
            stmtFees.executeUpdate();
            
            // Insert values into BRANCH Table
            String insertBranch = "INSERT INTO Branch(BranchID, BranchName) VALUES "
                    + "(5001, 'Computer Science Engineering'),"
                    + "(5002, 'Electrical Engineering'),"
                    + "(5003, 'Mechanical Engineering'),"
                    + "(5004, 'Civil Engineering'),"
                    + "(5005, 'Aritifical Intelligence Engineering'),"
                    + "(5006, 'Robotics And Automation Engineering')";
            PreparedStatement stmtInsertBranch = conn.prepareStatement(insertBranch);
            stmtInsertBranch.executeUpdate();

            // Insert values into Admin Table
            String insertAdmin = "INSERT INTO Admin(AdminID, FirstName, LastName, Email) VALUES "
                    + "(1, 'Raj', 'Patel', 'raj@gmail.com'),"
                    + "(2, 'Priya', 'Sharma', 'priya@gmail.com'),"
                    + "(3, 'Amit', 'Gupta', 'amit@gmail.com'),"
                    + "(4, 'Sneha', 'Desai', 'sneha@gmail.com')";
            PreparedStatement stmtInsertAdmin = conn.prepareStatement(insertAdmin);
            stmtInsertAdmin.executeUpdate();


            // Insert values into Student Table
            String insertStudent = "INSERT INTO Student(PRN, FirstName, LastName, Year, BranchID, Semester, DOB, FathersName, Email, AddressStreetName, AddressStreetNumber, AddressZipCode, AddressState, AddressCity) VALUES "
                    + "(1001, 'Abhishek', 'Rajput', 2, 5001, 4, '2000-05-15', 'Mr. Rajput', 'abhishek@gmail.com', 'Main Street', '123', '400001', 'Maharashtra', 'Mumbai'),"
                    + "(1002, 'Aditya', 'Raj', 3, 5001, 6, '1999-08-20', 'Mr. Raj', 'aditya@gmail.com', 'Park Avenue', '456', '110001', 'Delhi', 'New Delhi'),"
                    + "(1003, 'Archit', 'Patil', 1, 5002, 2, '2001-02-10', 'Mr. Patil', 'archit@gmail.com', 'Broadway', '789', '560001', 'Karnataka', 'Bangalore'),"
                    + "(1004, 'Arnav', 'Jain', 4, 5002, 8, '1998-11-25', 'Mr. Jain', 'arnav@gmail.com', 'Green Street', '1011', '600001', 'Tamil Nadu', 'Chennai'),"
                    + "(1005, 'Aryan', 'Sharma', 2, 5003, 4, '2000-07-12', 'Mr. Sharma', 'aryan@gmail.com', 'High Street', '1314', '700001', 'West Bengal', 'Kolkata'),"
                    + "(1006, 'Avinash', 'Gupta', 3, 5003, 6, '1999-09-18', 'Mr. Gupta', 'avinash@gmail.com', 'River Road', '1516', '500001', 'Telangana', 'Hyderabad'),"
                    + "(1007, 'Amita', 'Singh', 1, 5004, 2, '2001-03-22', 'Mr. Singh', 'amita@gmail.com', 'Lake Street', '1718', '380001', 'Gujarat', 'Ahmedabad'),"
                    + "(1008, 'Akash', 'Kumar', 4, 5004, 8, '1998-12-30', 'Mr. Kumar', 'akash@gmail.com', 'Gandhi Road', '1920', '250001', 'Uttar Pradesh', 'Agra'),"
                    + "(1009, 'Ananya', 'Yadav', 2, 5005, 4, '2000-06-08', 'Mr. Yadav', 'ananya@gmail.com', 'Market Street', '2122', '560002', 'Karnataka', 'Mysore'),"
                    + "(1010, 'Ankit', 'Verma', 3, 5005, 6, '1999-10-14', 'Mr. Verma', 'ankit@gmail.com', 'Station Road', '2324', '110002', 'Delhi', 'New Delhi'),"
                    + "(1011, 'Aditi', 'Shah', 1, 5006, 2, '2001-04-26', 'Mr. Shah', 'aditi@gmail.com', 'Victoria Street', '2526', '600002', 'Tamil Nadu', 'Coimbatore'),"
                    + "(1012, 'Ayesha', 'Malik', 4, 5006, 8, '1998-11-03', 'Mr. Malik', 'ayesha@gmail.com', 'Church Street', '2728', '700002', 'West Bengal', 'Howrah')";
            PreparedStatement stmtInsertStudent = conn.prepareStatement(insertStudent);
            stmtInsertStudent.executeUpdate();


            
            // Insert values into PhoneNumber Table
            String insertPhoneNumber = "INSERT INTO Phonenumber(PRN, PhoneNumber1, PhoneNumber2) VALUES "
                    + "(1001, '9650104541', '9650104541'),"
                    + "(1002, '7720860456', '9650104542'),"
                    + "(1003, '8639914092', '9650104543'),"
                    + "(1004, '9377852020', '9650104544'),"
                    + "(1005, '9234567890', '9876543210'),"
                    + "(1006, '9345678901', '9012345678'),"
                    + "(1007, '9456789012', '8901234567'),"
                    + "(1008, '9567890123', '9890123456'),"
                    + "(1009, '9678901234', '8789012345'),"
                    + "(1010, '6789012345', '9678901234'),"
                    + "(1011, '8890123456', '9567890123'),"
                    + "(1012, '8901234567', '8456789012')";
            PreparedStatement stmtInsertPhoneNumber = conn.prepareStatement(insertPhoneNumber);
            stmtInsertPhoneNumber.executeUpdate();

            // Insert values into AdminLogin Table
            String insertAdminLogin = "INSERT INTO Adminlogin(AdminID, AdminPassword) VALUES "
                    + "(1, 'password1'),"
                    + "(2, 'password2'),"
                    + "(3, 'password3'),"
                    + "(4, 'password4')";
            PreparedStatement stmtInsertAdminLogin = conn.prepareStatement(insertAdminLogin);
            stmtInsertAdminLogin.executeUpdate();

            // Insert values into StudentLogin Table
            String insertStudentLogin = "INSERT INTO Studentlogin(PRN, StudentPassword) VALUES "
                    + "(1001, 'studentpass1'),"
                    + "(1002, 'studentpass2'),"
                    + "(1003, 'studentpass3'),"
                    + "(1004, 'studentpass4'),"
                    + "(1005, 'studentpass5'),"
                    + "(1006, 'studentpass6'),"
                    + "(1007, 'studentpass7'),"
                    + "(1008, 'studentpass8'),"
                    + "(1009, 'studentpass9'),"
                    + "(1010, 'studentpass10'),"
                    + "(1011, 'studentpass11'),"
                    + "(1012, 'studentpass12')";
            PreparedStatement stmtInsertStudentLogin = conn.prepareStatement(insertStudentLogin);
            stmtInsertStudentLogin.executeUpdate();

            // Insert values into Hostel Table
            String insertHostel = "INSERT INTO Hostel(PRN, Gender, SimpleRoom, LuxuryRoom) VALUES "
                    + "(1001, 'Male', 'Yes', 'No'),"
                    + "(1002, 'Male', 'No', 'Yes'),"
                    + "(1003, 'Male', 'Yes', 'No'),"
                    + "(1004, 'Male', 'No', 'Yes'),"
                    + "(1005, 'Male', 'Yes', 'No'),"
                    + "(1006, 'Male', 'Yes', 'No'),"
                    + "(1007, 'Female', 'No', 'Yes'),"
                    + "(1008, 'Male', 'Yes', 'No'),"
                    + "(1009, 'Female', 'No', 'Yes'),"
                    + "(1010, 'Male', 'Yes', 'No'),"
                    + "(1011, 'Female', 'Yes', 'No'),"
                    + "(1012, 'Female', 'No', 'Yes')";
            PreparedStatement stmtInsertHostel = conn.prepareStatement(insertHostel);
            stmtInsertHostel.executeUpdate();

            // Insert values into Library Table
            String insertLibrary = "INSERT INTO Library(LibraryID, Category, Issue, Return1) VALUES "
                    + "(1001, 'Science', '2023-01-10', '2023-02-10'),"
                    + "(1002, 'Literature', '2023-02-15', '2023-03-15'),"
                    + "(1003, 'Mathematics', '2023-03-20', '2023-04-20'),"
                    + "(1004, 'History', '2023-04-25', '2023-05-25'),"
                    + "(1001, 'Civics', '2023-05-26', '2023-06-28'),"
                    + "(1001, 'Geo', '2023-05-26', Null),"
                    + "(1005, 'Science', '2023-03-10', '2023-06-10'),"
                    + "(1007, 'Physics', '2023-01-17', Null),"
                    + "(1012, 'Mathematics-3', '2023-02-20', '2023-04-20'),"
                    + "(1009, 'C++', '2023-07-24', '2023-10-25'),"
                    + "(1010, 'Python', '2023-05-26', Null),"
                    + "(1004, 'Geo', '2023-05-26', '2023-08-11')";
            PreparedStatement stmtInsertLibrary = conn.prepareStatement(insertLibrary);
            stmtInsertLibrary.executeUpdate();

            // Insert values into Faculty Table
            String insertFaculty = "INSERT INTO Faculty(FacultyID, FacultyName, BranchID) VALUES "
                    + "(101, 'Dr. Sahil Gupta', 5001),"
                    + "(102, 'Prof. Aryan Sharma', 5001),"
                    + "(103, 'Dr. Arnav Singh', 5001),"
                    + "(104, 'Prof. Archit Patel', 5002),"
                    + "(105, 'Dr. Faraj Khan', 5002),"
                    + "(106, 'Prof. Dhurmil Verma', 5002),"
                    + "(107, 'Dr. Dhruv Joshi', 5003),"
                    + "(108, 'Prof. Pranav Reddy', 5003),"
                    + "(109, 'Dr. Ankit Malhotra', 5003),"
                    + "(110, 'Prof. Aman Gupta', 5004),"
                    + "(111, 'Dr. Ansh Sharma', 5004),"
                    + "(112, 'Prof. Vijay Singh', 5004),"
                    + "(113, 'Dr. Harsh Kumar', 5005),"
                    + "(114, 'Prof. Abhay Desai', 5005),"
                    + "(115, 'Dr. Ram Patel', 5005),"
                    + "(116, 'Prof. Amit Shah', 5006),"
                    + "(117, 'Dr. Tarak Mehta', 5006),"
                    + "(118, 'Prof. Divyansh Choudhury', 5006)";
            PreparedStatement stmtInsertFaculty = conn.prepareStatement(insertFaculty);
            stmtInsertFaculty.executeUpdate();

            // Insert values into Course Table
            String insertCourse = "INSERT INTO Course(CourseID, CourseName, Duration, BranchID) VALUES "
                    + "(601, 'Database Management', '3 months', 5001),"
                    + "(602, 'Power Systems', '4 months', 5001),"
                    + "(603, 'Thermodynamics', '5 months', 5001),"
                    + "(604, 'Structural Analysis', '6 months', 5002),"
                    + "(605, 'Java', '5 months', 5002),"
                    + "(606, 'Data Structures', '3 months', 5002),"
                    + "(607, 'Renewable Energy', '4 months', 5003),"
                    + "(608, 'Fluid Mechanics', '5 months', 5003),"
                    + "(609, 'Transportation Engineering', '6 months', 5003),"
                    + "(610, 'Python Programming', '5 months', 5004),"
                    + "(611, 'Machine Learning', '4 months', 5004),"
                    + "(612, 'Control Systems', '5 months', 5004),"
                    + "(613, 'Construction Management', '6 months', 5005),"
                    + "(614, 'Web Development', '5 months', 5005),"
                    + "(615, 'Artificial Intelligence', '4 months', 5005),"
                    + "(616, 'Heat Transfer', '5 months', 5006),"
                    + "(617, 'Automation ', '6 months', 5006),"
                    + "(618, 'Mobile App Development', '5 months', 5006)";
            PreparedStatement stmtInsertCourse = conn.prepareStatement(insertCourse);
            stmtInsertCourse.executeUpdate();

            // Insert values into TimeTable Table
            String insertTimeTable = "INSERT INTO Timetable(TimetableID, CourseID, FacultyID, RoomNumber, Timing) VALUES "
                    + "(501, 601, 101, 'Room 101', '9:00 AM - 10:00 AM'),"
                    + "(502, 602, 102, 'Room 101', '10:00 AM - 11:00 AM'),"
                    + "(503, 603, 103, 'Room CL1', '11:00 AM - 1:00 PM'),"
                    + "(504, 604, 104, 'Room 102', '9:00 AM - 10:00 AM'),"
                    + "(505, 605, 105, 'Room 102', '10:00 AM - 11:00 AM'),"
                    + "(506, 606, 106, 'Room CL2', '11:00 AM - 1:00 PM'),"
                    + "(507, 607, 107, 'Room 104', '9:00 AM - 10:00 AM'),"
                    + "(508, 608, 108, 'Room 105', '10:00 AM - 11:00 AM'),"
                    + "(509, 609, 109, 'Room CL3', '11:00 AM - 1:00 PM'),"
                    + "(510, 610, 110, 'Room 106', '9:00 AM - 10:00 AM'),"
                    + "(511, 611, 111, 'Room 106', '10:00 AM - 11:00 AM'),"
                    + "(512, 612, 112, 'Room CL4', '11:00 AM - 1:00 PM'),"
                    + "(513, 613, 113, 'Room 108', '9:00 AM - 10:00 AM'),"
                    + "(514, 614, 114, 'Room 108', '10:00 AM - 11:00 AM'),"
                    + "(515, 615, 115, 'Room CL5', '11:00 AM - 1:00 PM'),"
                    + "(516, 616, 116, 'Room 110', '9:00 AM - 10:00 AM'),"
                    + "(517, 617, 117, 'Room 110', '10:00 AM - 11:00 AM'),"
                    + "(518, 618, 118, 'Room CL6', '11:00 AM - 1:00 PM')";
            PreparedStatement stmtInsertTimeTable = conn.prepareStatement(insertTimeTable);
            stmtInsertTimeTable.executeUpdate();

            // Insert values into Grades Table
            String insertGrades = "INSERT INTO Grades(PRN, MidSem, EndSem) VALUES "
                    + "(1001, 85, 90),"
                    + "(1002, 78, 85),"
                    + "(1003, 80, 88),"
                    + "(1004, 75, 82),"
                    + "(1005, 88, 92),"
                    + "(1006, 82, 89),"
                    + "(1007, 85, 90),"
                    + "(1008, 79, 86),"
                    + "(1009, 83, 88),"
                    + "(1010, 77, 84),"
                    + "(1011, 86, 91),"
                    + "(1012, 81, 88)";
            PreparedStatement stmtInsertGrades = conn.prepareStatement(insertGrades);
            stmtInsertGrades.executeUpdate();

            // Insert values into Attendance Table
            String insertAttendance = "INSERT INTO Attendance(PRN, Percentage, Date1) VALUES "
                    + "(1001, 90, '2023-01-15'),"
                    + "(1002, 85, '2023-02-20'),"
                    + "(1003, 88, '2023-03-25'),"
                    + "(1004, 82, '2023-04-30'),"
                    + "(1005, 86, '2023-05-05'),"
                    + "(1006, 83, '2023-06-10'),"
                    + "(1007, 88, '2023-07-15'),"
                    + "(1008, 80, '2023-08-20'),"
                    + "(1009, 85, '2023-09-25'),"
                    + "(1010, 89, '2023-10-30'),"
                    + "(1011, 87, '2023-11-05'),"
                    + "(1012, 82, '2023-12-10')";
            PreparedStatement stmtInsertAttendance = conn.prepareStatement(insertAttendance);
            stmtInsertAttendance.executeUpdate();

            // Insert values into Fees Table
            String insertFees = "INSERT INTO Fees(PRN, PaidUnpaid, Fine) VALUES "
                    + "(1001, 'Paid', 0),"
                    + "(1002, 'Unpaid', 50),"
                    + "(1003, 'Paid', 0),"
                    + "(1004, 'Paid', 0),"
                    + "(1005, 'Unpaid', 50),"
                    + "(1006, 'Paid', 0),"
                    + "(1007, 'Unpaid', 500),"
                    + "(1008, 'Paid', 0),"
                    + "(1009, 'Paid', 0),"
                    + "(1010, 'Unpaid', 250),"
                    + "(1011, 'Paid', 0),"
                    + "(1012, 'Unpaid', 90)";
            PreparedStatement stmtInsertFees = conn.prepareStatement(insertFees);
            stmtInsertFees.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);
        }
    }
}
/**
 *
 * @author Abhishek
 */
public class J01_MainPage extends javax.swing.JFrame{

    /**
     * Creates new form J1_MainPage
     */
    public J01_MainPage() {
        initComponents2();
        initComponents();        

        //FOR BACK BUTTON
        lastAccessedTabIndex = jTabbedPane1.getSelectedIndex();

        objChangeListener = new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                // Update the last accessed tab index
                temp = lastAccessedTabIndex;
                newAccessedTabIndex = jTabbedPane1.getSelectedIndex();
                lastAccessedTabIndex = newAccessedTabIndex;
            }

        };
        jTabbedPane1.addChangeListener(objChangeListener);
        lastAccessedTabIndex1 = jTabbedPane2.getSelectedIndex();
        objChangeListener1 = new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                // Update the last accessed tab index
                temp1 = lastAccessedTabIndex1;
                newAccessedTabIndex1 = jTabbedPane2.getSelectedIndex();
                lastAccessedTabIndex1 = newAccessedTabIndex1;
            }

        };
        jTabbedPane2.addChangeListener(objChangeListener1);
    }

    private void initComponents2() {
        redlineP = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        t1Main = new javax.swing.JPanel();
        headingLt1 = new javax.swing.JLabel();
        adminBt1 = new javax.swing.JButton();
        studentBt1 = new javax.swing.JButton();
        logoL1 = new javax.swing.JLabel();
        crossL1 = new javax.swing.JLabel();
        bgL1 = new javax.swing.JLabel();
        t2StuLogin = new javax.swing.JPanel();
        headingLt2 = new javax.swing.JLabel();
        prnIt2 = new javax.swing.JTextField();
        passwordIt2 = new javax.swing.JPasswordField();
        prnLt2 = new javax.swing.JLabel();
        passwordLt2 = new javax.swing.JLabel();
        submitBt2 = new javax.swing.JButton();
        resetBt2 = new javax.swing.JButton();
        crossL2 = new javax.swing.JLabel();
        bgL2 = new javax.swing.JLabel();
        t3Adlogin = new javax.swing.JPanel();
        headingLt3 = new javax.swing.JLabel();
        adminidLt3 = new javax.swing.JLabel();
        passwordLt3 = new javax.swing.JLabel();
        adminidIt3 = new javax.swing.JTextField();
        passwordIt3 = new javax.swing.JPasswordField();
        submitBt3 = new javax.swing.JButton();
        resetBt3 = new javax.swing.JButton();
        crossL3 = new javax.swing.JLabel();
        bgL3 = new javax.swing.JLabel();
        t4StuMenu = new javax.swing.JPanel();
        headingL4 = new javax.swing.JLabel();
        prnL4 = new javax.swing.JLabel();
        firstnameL4 = new javax.swing.JLabel();
        lastnameL4 = new javax.swing.JLabel();
        yearL4 = new javax.swing.JLabel();
        branchidL4 = new javax.swing.JLabel();
        semesterL4 = new javax.swing.JLabel();
        dobL4 = new javax.swing.JLabel();
        prnI4 = new javax.swing.JTextField();
        firstnameI4 = new javax.swing.JTextField();
        lastnameI4 = new javax.swing.JTextField();
        yearI4 = new javax.swing.JTextField();
        branchidI4 = new javax.swing.JTextField();
        semesterI4 = new javax.swing.JTextField();
        dobI4 = new javax.swing.JTextField();
        fathernameL4 = new javax.swing.JLabel();
        emailL4 = new javax.swing.JLabel();
        phonenumberL4 = new javax.swing.JLabel();
        addressL4 = new javax.swing.JLabel();
        fathernameI4 = new javax.swing.JTextField();
        emailI4 = new javax.swing.JTextField();
        phonenumber1I4 = new javax.swing.JTextField();
        phonenumber2I4 = new javax.swing.JTextField();
        address1I4 = new javax.swing.JTextField();
        address3I4 = new javax.swing.JTextField();
        address2I4 = new javax.swing.JTextField();
        t5AdMenu = new javax.swing.JPanel();
        headingL5 = new javax.swing.JLabel();
        adminidL5 = new javax.swing.JLabel();
        firstnameL5 = new javax.swing.JLabel();
        lastnamel5 = new javax.swing.JLabel();
        emailL5 = new javax.swing.JLabel();
        adminidI5 = new javax.swing.JTextField();
        firstnameI5 = new javax.swing.JTextField();
        lastnameI5 = new javax.swing.JTextField();
        emailI5 = new javax.swing.JTextField();
        t6AdLogin = new javax.swing.JPanel();
        headingLt6 = new javax.swing.JLabel();
        scrollt6 = new javax.swing.JScrollPane();
        adminTABt6 = new javax.swing.JTable();
        deleteBt6 = new javax.swing.JButton();
        addBt6 = new javax.swing.JButton();
        updateBt6 = new javax.swing.JButton();
        showBt6 = new javax.swing.JButton();
        hideBt6 = new javax.swing.JButton();
        findBt6 = new javax.swing.JButton();
        findIt6 = new javax.swing.JTextField();
        t6_1AdUpdate = new javax.swing.JPanel();
        headingLt6_1 = new javax.swing.JLabel();
        adminidLt6_1 = new javax.swing.JLabel();
        adminidIt6_1 = new javax.swing.JTextField();
        passoldLt6_1 = new javax.swing.JLabel();
        passwordoldIt6_1 = new javax.swing.JPasswordField();
        passnewLt6_1 = new javax.swing.JLabel();
        passwordnewIt6_1 = new javax.swing.JPasswordField();
        submitBt6_1 = new javax.swing.JButton();
        resetBt6_1 = new javax.swing.JButton();
        t6_2AdAdd = new javax.swing.JPanel();
        headingLt6_2 = new javax.swing.JLabel();
        adminidLt6_2 = new javax.swing.JLabel();
        passLt6_2 = new javax.swing.JLabel();
        submitBt6_2 = new javax.swing.JButton();
        resetBt6_2 = new javax.swing.JButton();
        adminidIt6_2 = new javax.swing.JTextField();
        passwordIt6_2 = new javax.swing.JPasswordField();
        t6_3AdDelete = new javax.swing.JPanel();
        headingLt6_3 = new javax.swing.JLabel();
        adminidLt6_3 = new javax.swing.JLabel();
        passLt6_3 = new javax.swing.JLabel();
        adminidIt6_3 = new javax.swing.JTextField();
        passwordIt6_3 = new javax.swing.JPasswordField();
        resetBt6_3 = new javax.swing.JButton();
        submitBt6_3 = new javax.swing.JButton();
        t7StuLogin = new javax.swing.JPanel();
        headingLt7 = new javax.swing.JLabel();
        scroll7 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        deleteBt7 = new javax.swing.JButton();
        addBt7 = new javax.swing.JButton();
        updateBt7 = new javax.swing.JButton();
        showBt7 = new javax.swing.JButton();
        hideBt7 = new javax.swing.JButton();
        findBt7 = new javax.swing.JButton();
        findIt7 = new javax.swing.JTextField();
        t7_1StuUpdate = new javax.swing.JPanel();
        headingLt7_1 = new javax.swing.JLabel();
        prnLt7_1 = new javax.swing.JLabel();
        passwordLt7_1 = new javax.swing.JLabel();
        prnIt7_1 = new javax.swing.JTextField();
        passwordIt7_1 = new javax.swing.JTextField();
        scrollt7_1 = new javax.swing.JScrollPane();
        jTable7_1 = new javax.swing.JTable();
        updateBt7_1 = new javax.swing.JButton();
        showBt7_1 = new javax.swing.JButton();
        hideBt7_1 = new javax.swing.JButton();
        resetBt7_1 = new javax.swing.JButton();
        findB7_1 = new javax.swing.JToggleButton();
        findI7_1 = new javax.swing.JTextField();
        t7_2StuAdd = new javax.swing.JPanel();
        headingLt7_2 = new javax.swing.JLabel();
        prnLt7_2 = new javax.swing.JLabel();
        passLt7_2 = new javax.swing.JLabel();
        prnIt7_2 = new javax.swing.JTextField();
        passwordIt7_2 = new javax.swing.JPasswordField();
        submitBt7_2 = new javax.swing.JButton();
        resetBt7_2 = new javax.swing.JButton();
        t7_3StuDelete = new javax.swing.JPanel();
        headingLt7_3 = new javax.swing.JLabel();
        prnLt7_3 = new javax.swing.JLabel();
        passLt7_3 = new javax.swing.JLabel();
        prnIt7_3 = new javax.swing.JTextField();
        passwordIt7_3 = new javax.swing.JPasswordField();
        resetBt7_3 = new javax.swing.JButton();
        submitBt7_3 = new javax.swing.JButton();
        t8AdGrades = new javax.swing.JPanel();
        headingL8 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable8 = new javax.swing.JTable();
        addB8 = new javax.swing.JButton();
        updateB8 = new javax.swing.JButton();
        deleteB8 = new javax.swing.JButton();
        showB8 = new javax.swing.JButton();
        hideB8 = new javax.swing.JButton();
        findB8 = new javax.swing.JButton();
        deleteI8 = new javax.swing.JTextField();
        findI8 = new javax.swing.JTextField();
        t9AdFaculty = new javax.swing.JPanel();
        headingL9 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTable9 = new javax.swing.JTable();
        addB9 = new javax.swing.JButton();
        updateB9 = new javax.swing.JButton();
        deleteB9 = new javax.swing.JButton();
        showB9 = new javax.swing.JButton();
        hideB9 = new javax.swing.JButton();
        findB9 = new javax.swing.JButton();
        deleteI9 = new javax.swing.JTextField();
        findI9 = new javax.swing.JTextField();
        t10AdAttendance = new javax.swing.JPanel();
        headingL10 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        jTable10 = new javax.swing.JTable();
        addB10 = new javax.swing.JButton();
        updateB10 = new javax.swing.JButton();
        deleteB10 = new javax.swing.JButton();
        showB10 = new javax.swing.JButton();
        hideB10 = new javax.swing.JButton();
        findB10 = new javax.swing.JButton();
        deleteI10 = new javax.swing.JTextField();
        findI10 = new javax.swing.JTextField();
        t11AdLibrary = new javax.swing.JPanel();
        headingL11 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        jTable11 = new javax.swing.JTable();
        addB11 = new javax.swing.JButton();
        updateB11 = new javax.swing.JButton();
        deleteB11 = new javax.swing.JButton();
        showB11 = new javax.swing.JButton();
        hideB11 = new javax.swing.JButton();
        findB11 = new javax.swing.JButton();
        deleteI11 = new javax.swing.JTextField();
        findI11 = new javax.swing.JTextField();
        deleteissueI11 = new javax.swing.JTextField();
        t12AdFees = new javax.swing.JPanel();
        headingL12 = new javax.swing.JLabel();
        jScrollPane12 = new javax.swing.JScrollPane();
        jTable12 = new javax.swing.JTable();
        addB12 = new javax.swing.JButton();
        updateB12 = new javax.swing.JButton();
        deleteB12 = new javax.swing.JButton();
        showB12 = new javax.swing.JButton();
        hideB12 = new javax.swing.JButton();
        findB12 = new javax.swing.JButton();
        deleteI12 = new javax.swing.JTextField();
        findI12 = new javax.swing.JTextField();
        t13AdCourse = new javax.swing.JPanel();
        headingL13 = new javax.swing.JLabel();
        jScrollPane13 = new javax.swing.JScrollPane();
        jTable13 = new javax.swing.JTable();
        addB13 = new javax.swing.JButton();
        updateB13 = new javax.swing.JButton();
        deleteB13 = new javax.swing.JButton();
        showB13 = new javax.swing.JButton();
        hideB13 = new javax.swing.JButton();
        findB13 = new javax.swing.JButton();
        deleteI13 = new javax.swing.JTextField();
        findI13 = new javax.swing.JTextField();
        t14AdHostel = new javax.swing.JPanel();
        headingL14 = new javax.swing.JLabel();
        jScrollPane14 = new javax.swing.JScrollPane();
        jTable14 = new javax.swing.JTable();
        addB14 = new javax.swing.JButton();
        updateB14 = new javax.swing.JButton();
        deleteB14 = new javax.swing.JButton();
        showB14 = new javax.swing.JButton();
        hideB14 = new javax.swing.JButton();
        findB14 = new javax.swing.JButton();
        deleteI14 = new javax.swing.JTextField();
        findI14 = new javax.swing.JTextField();
        t15AdTimeT = new javax.swing.JPanel();
        headingL15 = new javax.swing.JLabel();
        jScrollPane15 = new javax.swing.JScrollPane();
        jTable15 = new javax.swing.JTable();
        addB15 = new javax.swing.JButton();
        updateB15 = new javax.swing.JButton();
        deleteB15 = new javax.swing.JButton();
        showB15 = new javax.swing.JButton();
        hideB15 = new javax.swing.JButton();
        findB15 = new javax.swing.JButton();
        deleteI15 = new javax.swing.JTextField();
        findI15 = new javax.swing.JTextField();
        t16StuGrades = new javax.swing.JPanel();
        headingL16 = new javax.swing.JLabel();
        prnL16 = new javax.swing.JLabel();
        midsemL16 = new javax.swing.JLabel();
        endsemL16 = new javax.swing.JLabel();
        prnI16 = new javax.swing.JTextField();
        midsemI16 = new javax.swing.JTextField();
        endsemI16 = new javax.swing.JTextField();
        t17StuAttendance = new javax.swing.JPanel();
        headingL17 = new javax.swing.JLabel();
        prnL17 = new javax.swing.JLabel();
        percentageL17 = new javax.swing.JLabel();
        dateL17 = new javax.swing.JLabel();
        prnI17 = new javax.swing.JTextField();
        percentageI17 = new javax.swing.JTextField();
        dateI17 = new javax.swing.JTextField();
        t18StuLibrary = new javax.swing.JPanel();
        headingL18 = new javax.swing.JLabel();
        libraryidL18 = new javax.swing.JLabel();
        libraryidI18 = new javax.swing.JTextField();
        jScrollPane18 = new javax.swing.JScrollPane();
        jTable18 = new javax.swing.JTable();
        t19StuFees = new javax.swing.JPanel();
        headingL19 = new javax.swing.JLabel();
        prnL19 = new javax.swing.JLabel();
        branchL19 = new javax.swing.JLabel();
        paidunpaidL19 = new javax.swing.JLabel();
        FineL19 = new javax.swing.JLabel();
        prnI19 = new javax.swing.JTextField();
        branchI19 = new javax.swing.JTextField();
        paidunpaidI19 = new javax.swing.JTextField();
        fineI19 = new javax.swing.JTextField();
        t20StuCourse = new javax.swing.JPanel();
        headingL20 = new javax.swing.JLabel();
        jScrollPane20 = new javax.swing.JScrollPane();
        jTable20 = new javax.swing.JTable();
        branchL20 = new javax.swing.JLabel();
        branchI20 = new javax.swing.JTextField();
        t21StuHostel = new javax.swing.JPanel();
        headingL21 = new javax.swing.JLabel();
        prnL21 = new javax.swing.JLabel();
        genderL21 = new javax.swing.JLabel();
        roomtypeL21 = new javax.swing.JLabel();
        prnI21 = new javax.swing.JTextField();
        genderI21 = new javax.swing.JTextField();
        roomtypeI21 = new javax.swing.JTextField();
        t22StuTimeT = new javax.swing.JPanel();
        headingL22 = new javax.swing.JLabel();
        branchL22 = new javax.swing.JLabel();
        branchI22 = new javax.swing.JTextField();
        jScrollPane22 = new javax.swing.JScrollPane();
        jTable22 = new javax.swing.JTable();
        t12_1Add = new javax.swing.JPanel();
        headingL12_1 = new javax.swing.JLabel();
        prnL12_1 = new javax.swing.JLabel();
        paidunpaidL12_1 = new javax.swing.JLabel();
        fineL12_1 = new javax.swing.JLabel();
        prnI12_1 = new javax.swing.JTextField();
        paidunpaidI12_1 = new javax.swing.JTextField();
        fineI12_1 = new javax.swing.JTextField();
        submitB12_1 = new javax.swing.JButton();
        resetB12_1 = new javax.swing.JButton();
        t12_2Update = new javax.swing.JPanel();
        headingL12_2 = new javax.swing.JLabel();
        prnL12_2 = new javax.swing.JLabel();
        paidunpaidL12_2 = new javax.swing.JLabel();
        fineL12_2 = new javax.swing.JLabel();
        prnI12_2 = new javax.swing.JTextField();
        paidunpaidI12_2 = new javax.swing.JTextField();
        fineI12_2 = new javax.swing.JTextField();
        submitB12_2 = new javax.swing.JButton();
        resetB12_2 = new javax.swing.JButton();
        jScrollPane12_2 = new javax.swing.JScrollPane();
        jTable12_2 = new javax.swing.JTable();
        showB12_2 = new javax.swing.JButton();
        hideB12_2 = new javax.swing.JButton();
        findB12_2 = new javax.swing.JButton();
        findI12_2 = new javax.swing.JTextField();
        t13_1Add = new javax.swing.JPanel();
        headingL13_1 = new javax.swing.JLabel();
        courseidL13_1 = new javax.swing.JLabel();
        coursenameL13_1 = new javax.swing.JLabel();
        durationL13_1 = new javax.swing.JLabel();
        branchidL13_1 = new javax.swing.JLabel();
        courseidI13_1 = new javax.swing.JTextField();
        coursenameI13_1 = new javax.swing.JTextField();
        durationI13_1 = new javax.swing.JTextField();
        branchidI13_1 = new javax.swing.JTextField();
        submitB13_1 = new javax.swing.JButton();
        resetB13_1 = new javax.swing.JButton();
        t13_2Update = new javax.swing.JPanel();
        headingL13_2 = new javax.swing.JLabel();
        courseidL13_2 = new javax.swing.JLabel();
        coursenameL13_2 = new javax.swing.JLabel();
        durationL13_2 = new javax.swing.JLabel();
        branchidL13_2 = new javax.swing.JLabel();
        courseidI13_2 = new javax.swing.JTextField();
        coursenameI13_2 = new javax.swing.JTextField();
        durationI13_2 = new javax.swing.JTextField();
        branchidI13_2 = new javax.swing.JTextField();
        submitB13_2 = new javax.swing.JButton();
        resetB13_2 = new javax.swing.JButton();
        showB13_2 = new javax.swing.JButton();
        hideB13_2 = new javax.swing.JButton();
        jScrollPane13_2 = new javax.swing.JScrollPane();
        jTable13_2 = new javax.swing.JTable();
        findB13_2 = new javax.swing.JButton();
        findI13_2 = new javax.swing.JTextField();
        t8_1Add = new javax.swing.JPanel();
        headingL8_1 = new javax.swing.JLabel();
        prnL8_1 = new javax.swing.JLabel();
        midsemL8_1 = new javax.swing.JLabel();
        endsemL8_1 = new javax.swing.JLabel();
        prnI8_1 = new javax.swing.JTextField();
        midsemI8_1 = new javax.swing.JTextField();
        endsemI8_1 = new javax.swing.JTextField();
        submitB8_1 = new javax.swing.JButton();
        resetB8_1 = new javax.swing.JButton();
        t8_2Update = new javax.swing.JPanel();
        headingL8_2 = new javax.swing.JLabel();
        prnL8_2 = new javax.swing.JLabel();
        midsemL8_2 = new javax.swing.JLabel();
        endsemL8_2 = new javax.swing.JLabel();
        prnI8_2 = new javax.swing.JTextField();
        midsemI8_2 = new javax.swing.JTextField();
        endsemI8_2 = new javax.swing.JTextField();
        submitB8_2 = new javax.swing.JButton();
        resetB8_2 = new javax.swing.JButton();
        showB8_2 = new javax.swing.JButton();
        hideB8_2 = new javax.swing.JButton();
        jScrollPane8_2 = new javax.swing.JScrollPane();
        jTable8_2 = new javax.swing.JTable();
        findB8_2 = new javax.swing.JButton();
        findI8_2 = new javax.swing.JTextField();
        t9_1Add = new javax.swing.JPanel();
        headingL9_1 = new javax.swing.JLabel();
        facultyidL9_1 = new javax.swing.JLabel();
        facultynameL9_1 = new javax.swing.JLabel();
        branchidL9_1 = new javax.swing.JLabel();
        facultyidI9_1 = new javax.swing.JTextField();
        facultynameI9_1 = new javax.swing.JTextField();
        branchidI9_1 = new javax.swing.JTextField();
        submitB9_1 = new javax.swing.JButton();
        resetB9_1 = new javax.swing.JButton();
        t9_2Update = new javax.swing.JPanel();
        headingL9_2 = new javax.swing.JLabel();
        facultyidL9_2 = new javax.swing.JLabel();
        facultynameL9_2 = new javax.swing.JLabel();
        branchidL9_2 = new javax.swing.JLabel();
        facultyidI9_2 = new javax.swing.JTextField();
        facultynameI9_2 = new javax.swing.JTextField();
        branchidI9_2 = new javax.swing.JTextField();
        submitB9_2 = new javax.swing.JButton();
        resetB9_2 = new javax.swing.JButton();
        jScrollPane9_2 = new javax.swing.JScrollPane();
        jTable9_2 = new javax.swing.JTable();
        showB9_2 = new javax.swing.JButton();
        hideB9_2 = new javax.swing.JButton();
        findB9_2 = new javax.swing.JButton();
        findI9_2 = new javax.swing.JTextField();
        t10_1Add = new javax.swing.JPanel();
        headingL10_1 = new javax.swing.JLabel();
        prnL10_1 = new javax.swing.JLabel();
        percentageL10_1 = new javax.swing.JLabel();
        dateL10_1 = new javax.swing.JLabel();
        prnI10_1 = new javax.swing.JTextField();
        percentageI10_1 = new javax.swing.JTextField();
        dateI10_1 = new javax.swing.JTextField();
        submitB10_1 = new javax.swing.JButton();
        resetB10_1 = new javax.swing.JButton();
        t10_2Update = new javax.swing.JPanel();
        headingL10_2 = new javax.swing.JLabel();
        prnL10_2 = new javax.swing.JLabel();
        percentageL10_2 = new javax.swing.JLabel();
        dateL10_2 = new javax.swing.JLabel();
        prnI10_2 = new javax.swing.JTextField();
        percentageI10_2 = new javax.swing.JTextField();
        dateI10_2 = new javax.swing.JTextField();
        submitB10_2 = new javax.swing.JButton();
        resetB10_2 = new javax.swing.JButton();
        showB10_2 = new javax.swing.JButton();
        hideB10_2 = new javax.swing.JButton();
        jScrollPane10_2 = new javax.swing.JScrollPane();
        jTable10_2 = new javax.swing.JTable();
        findB10_2 = new javax.swing.JButton();
        findI10_2 = new javax.swing.JTextField();
        t11_1Add = new javax.swing.JPanel();
        headingL11_1 = new javax.swing.JLabel();
        libraryidL11_1 = new javax.swing.JLabel();
        categoryL11_1 = new javax.swing.JLabel();
        issuedateL11_1 = new javax.swing.JLabel();
        libraryidI11_1 = new javax.swing.JTextField();
        categoryI11_1 = new javax.swing.JTextField();
        issuedateI11_1 = new javax.swing.JTextField();
        submitB11_1 = new javax.swing.JButton();
        resetB11_1 = new javax.swing.JButton();
        returndateL11_1 = new javax.swing.JLabel();
        returndateI11_1 = new javax.swing.JTextField();
        t11_2Update = new javax.swing.JPanel();
        headingL11_2 = new javax.swing.JLabel();
        libraryidL11_2 = new javax.swing.JLabel();
        categoryL11_2 = new javax.swing.JLabel();
        issuedateL11_2 = new javax.swing.JLabel();
        libraryidI11_2 = new javax.swing.JTextField();
        categoryI11_2 = new javax.swing.JTextField();
        issuedateI11_2 = new javax.swing.JTextField();
        submitB11_2 = new javax.swing.JButton();
        resetB11_2 = new javax.swing.JButton();
        returndateL11_2 = new javax.swing.JLabel();
        returndateI11_2 = new javax.swing.JTextField();
        showB11_2 = new javax.swing.JButton();
        hideB11_2 = new javax.swing.JButton();
        jScrollPane11_2 = new javax.swing.JScrollPane();
        jTable11_2 = new javax.swing.JTable();
        findB11_2 = new javax.swing.JButton();
        findI11_2 = new javax.swing.JTextField();
        t14_1Add = new javax.swing.JPanel();
        headingL14_1 = new javax.swing.JLabel();
        prnL14_1 = new javax.swing.JLabel();
        genderL14_1 = new javax.swing.JLabel();
        simpleroomL14_1 = new javax.swing.JLabel();
        prnI14_1 = new javax.swing.JTextField();
        genderI14_1 = new javax.swing.JTextField();
        simpleroomI14_1 = new javax.swing.JTextField();
        submitB14_1 = new javax.swing.JButton();
        resetB14_1 = new javax.swing.JButton();
        luxuryroomL14_1 = new javax.swing.JLabel();
        luxuryroomI14_1 = new javax.swing.JTextField();
        t14_2Update = new javax.swing.JPanel();
        headingL14_2 = new javax.swing.JLabel();
        prnL14_2 = new javax.swing.JLabel();
        genderL14_2 = new javax.swing.JLabel();
        simpleroomL14_2 = new javax.swing.JLabel();
        prnI14_2 = new javax.swing.JTextField();
        genderI14_2 = new javax.swing.JTextField();
        simpleroomI14_2 = new javax.swing.JTextField();
        submitB14_2 = new javax.swing.JButton();
        resetB14_2 = new javax.swing.JButton();
        luxuryroomL14_2 = new javax.swing.JLabel();
        luxuryroomI14_2 = new javax.swing.JTextField();
        showB14_2 = new javax.swing.JButton();
        hideB14_2 = new javax.swing.JButton();
        jScrollPane14_2 = new javax.swing.JScrollPane();
        jTable14_2 = new javax.swing.JTable();
        findB14_2 = new javax.swing.JButton();
        findI14_2 = new javax.swing.JTextField();
        t15_1Add = new javax.swing.JPanel();
        headingL15_1 = new javax.swing.JLabel();
        timetableidL15_1 = new javax.swing.JLabel();
        courseidL15_1 = new javax.swing.JLabel();
        facultyidL15_1 = new javax.swing.JLabel();
        timetableidI15_1 = new javax.swing.JTextField();
        courseidI15_1 = new javax.swing.JTextField();
        facultyidI15_1 = new javax.swing.JTextField();
        submitB15_1 = new javax.swing.JButton();
        resetB15_1 = new javax.swing.JButton();
        roomnumberL15_1 = new javax.swing.JLabel();
        roomnumberI15_1 = new javax.swing.JTextField();
        timingsL15_1 = new javax.swing.JLabel();
        timingsI15_1 = new javax.swing.JTextField();
        t15_2Update = new javax.swing.JPanel();
        headingL15_2 = new javax.swing.JLabel();
        timetableidL15_2 = new javax.swing.JLabel();
        courseidL15_2 = new javax.swing.JLabel();
        facultyidL15_2 = new javax.swing.JLabel();
        timetableidI15_2 = new javax.swing.JTextField();
        courseidI15_2 = new javax.swing.JTextField();
        facultyidI15_2 = new javax.swing.JTextField();
        submitB15_2 = new javax.swing.JButton();
        resetB15_2 = new javax.swing.JButton();
        roomnumberL15_2 = new javax.swing.JLabel();
        roomnumberI15_2 = new javax.swing.JTextField();
        timingsL15_2 = new javax.swing.JLabel();
        timingsI15_2 = new javax.swing.JTextField();
        showB15_2 = new javax.swing.JButton();
        hideB15_2 = new javax.swing.JButton();
        jScrollPane15_2 = new javax.swing.JScrollPane();
        jTable15_2 = new javax.swing.JTable();
        findB15_2 = new javax.swing.JButton();
        findI15_2 = new javax.swing.JTextField();
        t23AdBranch = new javax.swing.JPanel();
        headingL23 = new javax.swing.JLabel();
        jScrollPane23 = new javax.swing.JScrollPane();
        jTable23 = new javax.swing.JTable();
        addB23 = new javax.swing.JButton();
        updateB23 = new javax.swing.JButton();
        deleteB23 = new javax.swing.JButton();
        showB23 = new javax.swing.JButton();
        hideB23 = new javax.swing.JButton();
        findB23 = new javax.swing.JButton();
        deleteI23 = new javax.swing.JTextField();
        findI23 = new javax.swing.JTextField();
        t24AdStudentDetails = new javax.swing.JPanel();
        headingL24 = new javax.swing.JLabel();
        jScrollPane24 = new javax.swing.JScrollPane();
        jTable24 = new javax.swing.JTable();
        addB24 = new javax.swing.JButton();
        updateB24 = new javax.swing.JButton();
        deleteB24 = new javax.swing.JButton();
        showB24 = new javax.swing.JButton();
        hideB24 = new javax.swing.JButton();
        findB24 = new javax.swing.JButton();
        deleteI24 = new javax.swing.JTextField();
        findI24 = new javax.swing.JTextField();
        t25AdAdminDetails = new javax.swing.JPanel();
        headingL25 = new javax.swing.JLabel();
        jScrollPane25 = new javax.swing.JScrollPane();
        jTable25 = new javax.swing.JTable();
        addB25 = new javax.swing.JButton();
        updateB25 = new javax.swing.JButton();
        deleteB25 = new javax.swing.JButton();
        showB25 = new javax.swing.JButton();
        hideB25 = new javax.swing.JButton();
        findB25 = new javax.swing.JButton();
        deleteI25 = new javax.swing.JTextField();
        findI25 = new javax.swing.JTextField();
        t23_1Add = new javax.swing.JPanel();
        headingL23_1 = new javax.swing.JLabel();
        branchidL23_1 = new javax.swing.JLabel();
        branchnameL23_1 = new javax.swing.JLabel();
        branchidI23_1 = new javax.swing.JTextField();
        branchnameI23_1 = new javax.swing.JTextField();
        submitB23_1 = new javax.swing.JButton();
        resetB23_1 = new javax.swing.JButton();
        t23_2Update = new javax.swing.JPanel();
        headingL23_2 = new javax.swing.JLabel();
        branchidL23_2 = new javax.swing.JLabel();
        branchnameL23_2 = new javax.swing.JLabel();
        branchidI23_2 = new javax.swing.JTextField();
        branchnameI23_2 = new javax.swing.JTextField();
        submitB23_2 = new javax.swing.JButton();
        resetB23_2 = new javax.swing.JButton();
        showB23_2 = new javax.swing.JButton();
        hideB23_2 = new javax.swing.JButton();
        jScrollPane23_2 = new javax.swing.JScrollPane();
        jTable23_2 = new javax.swing.JTable();
        t25_1Add = new javax.swing.JPanel();
        headingL25_1 = new javax.swing.JLabel();
        adminidL25_1 = new javax.swing.JLabel();
        firstnameL25_1 = new javax.swing.JLabel();
        adminidI25_1 = new javax.swing.JTextField();
        firstnameI25_1 = new javax.swing.JTextField();
        submitB25_1 = new javax.swing.JButton();
        resetB25_1 = new javax.swing.JButton();
        lastnameL25_1 = new javax.swing.JLabel();
        emaiL25_1 = new javax.swing.JLabel();
        lastnameI25_1 = new javax.swing.JTextField();
        emailI25_1 = new javax.swing.JTextField();
        t25_2Update = new javax.swing.JPanel();
        headingL25_2 = new javax.swing.JLabel();
        adminidL25_2 = new javax.swing.JLabel();
        firstnameL25_2 = new javax.swing.JLabel();
        adminidI25_2 = new javax.swing.JTextField();
        firstnameI25_2 = new javax.swing.JTextField();
        submitB25_2 = new javax.swing.JButton();
        resetB25_2 = new javax.swing.JButton();
        lastnameL25_2 = new javax.swing.JLabel();
        emaiL25_2 = new javax.swing.JLabel();
        lastnameI25_2 = new javax.swing.JTextField();
        emailI25_2 = new javax.swing.JTextField();
        showB25_2 = new javax.swing.JButton();
        hideB25_2 = new javax.swing.JButton();
        jScrollPane25_2 = new javax.swing.JScrollPane();
        jTable25_2 = new javax.swing.JTable();
        t24_1Add = new javax.swing.JPanel();
        headingL24_1 = new javax.swing.JLabel();
        prnL24_1 = new javax.swing.JLabel();
        firstnameL24_1 = new javax.swing.JLabel();
        prnI24_1 = new javax.swing.JTextField();
        firstnameI24_1 = new javax.swing.JTextField();
        submitB24_1 = new javax.swing.JButton();
        resetB24_1 = new javax.swing.JButton();
        lastnameL24_1 = new javax.swing.JLabel();
        yearL24_1 = new javax.swing.JLabel();
        lastnameI24_1 = new javax.swing.JTextField();
        yearI24_1 = new javax.swing.JTextField();
        branchidL24_1 = new javax.swing.JLabel();
        semesterL24_1 = new javax.swing.JLabel();
        dobL24_1 = new javax.swing.JLabel();
        fathersnameL24_1 = new javax.swing.JLabel();
        branchidI24_1 = new javax.swing.JTextField();
        semesterI24_1 = new javax.swing.JTextField();
        dobI24_1 = new javax.swing.JTextField();
        fathersnameI24_1 = new javax.swing.JTextField();
        emailL24_1 = new javax.swing.JLabel();
        streetnameL24_1 = new javax.swing.JLabel();
        streetnumberL24_1 = new javax.swing.JLabel();
        zipcodeL24_1 = new javax.swing.JLabel();
        cityL24_1 = new javax.swing.JLabel();
        stateL24_1 = new javax.swing.JLabel();
        phonenumber1L24_1 = new javax.swing.JLabel();
        phonenumber2L24_1 = new javax.swing.JLabel();
        emailI24_1 = new javax.swing.JTextField();
        streetnameI24_1 = new javax.swing.JTextField();
        streetnumberI24_1 = new javax.swing.JTextField();
        zipcodeI24_1 = new javax.swing.JTextField();
        cityI24_1 = new javax.swing.JTextField();
        stateI24_1 = new javax.swing.JTextField();
        phonenumber1I24_1 = new javax.swing.JTextField();
        phonenumber2I24_1 = new javax.swing.JTextField();
        t24_2Update = new javax.swing.JPanel();
        headingL24_2 = new javax.swing.JLabel();
        prnL24_2 = new javax.swing.JLabel();
        firstnameL24_2 = new javax.swing.JLabel();
        prnI24_2 = new javax.swing.JTextField();
        firstnameI24_2 = new javax.swing.JTextField();
        submitB24_2 = new javax.swing.JButton();
        resetB24_2 = new javax.swing.JButton();
        lastnameL24_2 = new javax.swing.JLabel();
        yearL24_2 = new javax.swing.JLabel();
        lastnameI24_2 = new javax.swing.JTextField();
        yearI24_2 = new javax.swing.JTextField();
        branchidL24_2 = new javax.swing.JLabel();
        semesterL24_2 = new javax.swing.JLabel();
        dobL24_2 = new javax.swing.JLabel();
        fathersnameL24_2 = new javax.swing.JLabel();
        branchidI24_2 = new javax.swing.JTextField();
        semesterI24_2 = new javax.swing.JTextField();
        dobI24_2 = new javax.swing.JTextField();
        fathersnameI24_2 = new javax.swing.JTextField();
        emailL24_2 = new javax.swing.JLabel();
        streetnameL24_2 = new javax.swing.JLabel();
        streetnumberL24_2 = new javax.swing.JLabel();
        zipcodeL24_2 = new javax.swing.JLabel();
        cityL24_2 = new javax.swing.JLabel();
        stateL24_2 = new javax.swing.JLabel();
        phonenumber1L24_2 = new javax.swing.JLabel();
        phonenumber2L24_2 = new javax.swing.JLabel();
        emailI24_2 = new javax.swing.JTextField();
        streetnameI24_2 = new javax.swing.JTextField();
        streetnumberI24_2 = new javax.swing.JTextField();
        zipcodeI24_2 = new javax.swing.JTextField();
        cityI24_2 = new javax.swing.JTextField();
        stateI24_2 = new javax.swing.JTextField();
        phonenumber1I24_2 = new javax.swing.JTextField();
        phonenumber2I24_2 = new javax.swing.JTextField();
        jScrollPane24_2 = new javax.swing.JScrollPane();
        jTable24_2 = new javax.swing.JTable();
        showB24_2 = new javax.swing.JButton();
        hideB24_2 = new javax.swing.JButton();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        st1 = new javax.swing.JPanel();
        st2 = new javax.swing.JPanel();
        timetableBst2 = new javax.swing.JButton();
        hostelBst2 = new javax.swing.JButton();
        courseBst2 = new javax.swing.JButton();
        feesBst2 = new javax.swing.JButton();
        libraryBst2 = new javax.swing.JButton();
        gradesBst2 = new javax.swing.JButton();
        attendanceBst2 = new javax.swing.JButton();
        logoutBst2 = new javax.swing.JButton();
        profileBst2 = new javax.swing.JButton();
        st3 = new javax.swing.JPanel();
        facultyBst3 = new javax.swing.JButton();
        hostelBst3 = new javax.swing.JButton();
        profileBst3 = new javax.swing.JButton();
        libraryBst3 = new javax.swing.JButton();
        courseBst3 = new javax.swing.JButton();
        feesBst3 = new javax.swing.JButton();
        gradesBst3 = new javax.swing.JButton();
        attendanceBst3 = new javax.swing.JButton();
        studentloginBst3 = new javax.swing.JButton();
        adminloginBst3 = new javax.swing.JButton();
        backBst3 = new javax.swing.JButton();
        timetableBst3 = new javax.swing.JButton();
        branchBst3 = new javax.swing.JButton();
        studentdetailsBst3 = new javax.swing.JButton();
        admindetailsBst3 = new javax.swing.JButton();
        st4 = new javax.swing.JPanel();
        homeBst4 = new javax.swing.JButton();
        st5 = new javax.swing.JPanel();
        homeBst5 = new javax.swing.JButton();
        backBst5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        redlineP.setBackground(new java.awt.Color(196, 22, 28));
        redlineP.setPreferredSize(new java.awt.Dimension(9, 635));

        javax.swing.GroupLayout redlinePLayout = new javax.swing.GroupLayout(redlineP);
        redlineP.setLayout(redlinePLayout);
        redlinePLayout.setHorizontalGroup(
                redlinePLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 20, Short.MAX_VALUE)
        );
        redlinePLayout.setVerticalGroup(
                redlinePLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 1392, Short.MAX_VALUE)
        );

        getContentPane().add(redlineP, new org.netbeans.lib.awtextra.AbsoluteConstraints(255, 0, 20, 1392));

        t1Main.setBackground(new java.awt.Color(255, 255, 255));
        t1Main.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        headingLt1.setBackground(new java.awt.Color(0, 0, 0));
        headingLt1.setFont(new java.awt.Font("Times New Roman", 1, 60)); // NOI18N
        headingLt1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        headingLt1.setText("CAMPUS NEXUS");
        t1Main.add(headingLt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 140, 476, -1));

        adminBt1.setBackground(new java.awt.Color(0, 0, 0));
        adminBt1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        adminBt1.setForeground(new java.awt.Color(255, 255, 255));
        adminBt1.setText("ADMIN LOGIN");
        adminBt1.setBorder(null);
        adminBt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminBt1ActionPerformed(evt);
            }
        });
        t1Main.add(adminBt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 660, 210, 50));

        studentBt1.setBackground(new java.awt.Color(0, 0, 0));
        studentBt1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        studentBt1.setForeground(new java.awt.Color(255, 255, 255));
        studentBt1.setText("STUDENT LOGIN");
        studentBt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentBt1ActionPerformed(evt);
            }
        });
        t1Main.add(studentBt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 660, 240, 50));

        logoL1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StudentNexus/icon/SITIconResized.png"))); // NOI18N
        t1Main.add(logoL1, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 300, 200, 250));

        crossL1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StudentNexus/icon/cross1.png"))); // NOI18N
        crossL1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                crossL1MouseClicked(evt);
            }
        });
        t1Main.add(crossL1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1230, 35, 40, 50));

        bgL1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StudentNexus/icon/bg.jpg"))); // NOI18N
        t1Main.add(bgL1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 1270, 880));

        jTabbedPane1.addTab("tab1", t1Main);

        t2StuLogin.setBackground(new java.awt.Color(255, 255, 255));
        t2StuLogin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        headingLt2.setBackground(new java.awt.Color(102, 153, 0));
        headingLt2.setFont(new java.awt.Font("Times New Roman", 1, 50)); // NOI18N
        headingLt2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        headingLt2.setText("STUDENT LOGIN ");
        headingLt2.setToolTipText("");
        t2StuLogin.add(headingLt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 180, 450, -1));

        prnIt2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        prnIt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prnIt2ActionPerformed(evt);
            }
        });
        t2StuLogin.add(prnIt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 350, 210, -1));

        passwordIt2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        passwordIt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordIt2ActionPerformed(evt);
            }
        });
        t2StuLogin.add(passwordIt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 470, 210, -1));

        prnLt2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnLt2.setText("PRN:");
        t2StuLogin.add(prnLt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 350, 147, 41));

        passwordLt2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        passwordLt2.setText("Password:");
        t2StuLogin.add(passwordLt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 460, 180, 54));

        submitBt2.setBackground(new java.awt.Color(0, 0, 0));
        submitBt2.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        submitBt2.setForeground(new java.awt.Color(255, 255, 255));
        submitBt2.setText("Submit");
        submitBt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBt2ActionPerformed(evt);
            }
        });
        t2StuLogin.add(submitBt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 620, -1, -1));

        resetBt2.setBackground(new java.awt.Color(0, 0, 0));
        resetBt2.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        resetBt2.setForeground(new java.awt.Color(255, 255, 255));
        resetBt2.setText("Reset");
        resetBt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBt2ActionPerformed(evt);
            }
        });
        t2StuLogin.add(resetBt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 620, -1, -1));

        crossL2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StudentNexus/icon/cross1.png"))); // NOI18N
        crossL2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                crossL2MouseClicked(evt);
            }
        });
        t2StuLogin.add(crossL2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1230, 40, 40, 40));

        bgL2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StudentNexus/icon/bg.jpg"))); // NOI18N
        t2StuLogin.add(bgL2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 1270, 880));

        jTabbedPane1.addTab("tab2", t2StuLogin);

        t3Adlogin.setBackground(new java.awt.Color(255, 255, 255));
        t3Adlogin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        headingLt3.setBackground(new java.awt.Color(102, 153, 0));
        headingLt3.setFont(new java.awt.Font("Times New Roman", 1, 50)); // NOI18N
        headingLt3.setText("ADMIN LOGIN ");
        headingLt3.setToolTipText("");
        t3Adlogin.add(headingLt3, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 180, -1, 39));

        adminidLt3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        adminidLt3.setText("Admin ID:");
        t3Adlogin.add(adminidLt3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 350, 100, -1));

        passwordLt3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        passwordLt3.setText("Password:");
        t3Adlogin.add(passwordLt3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 470, 93, -1));

        adminidIt3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminidIt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminidIt3ActionPerformed(evt);
            }
        });
        t3Adlogin.add(adminidIt3, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 350, 210, -1));

        passwordIt3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        passwordIt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordIt3ActionPerformed(evt);
            }
        });
        t3Adlogin.add(passwordIt3, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 470, 210, -1));

        submitBt3.setBackground(new java.awt.Color(0, 0, 0));
        submitBt3.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        submitBt3.setForeground(new java.awt.Color(255, 255, 255));
        submitBt3.setText("Submit");
        submitBt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBt3ActionPerformed(evt);
            }
        });
        t3Adlogin.add(submitBt3, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 620, -1, -1));

        resetBt3.setBackground(new java.awt.Color(0, 0, 0));
        resetBt3.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        resetBt3.setForeground(new java.awt.Color(255, 255, 255));
        resetBt3.setText("Reset");
        resetBt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBt3ActionPerformed(evt);
            }
        });
        t3Adlogin.add(resetBt3, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 620, -1, -1));

        crossL3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StudentNexus/icon/cross1.png"))); // NOI18N
        crossL3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                crossL3MouseClicked(evt);
            }
        });
        t3Adlogin.add(crossL3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1230, 40, 40, 40));

        bgL3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/StudentNexus/icon/bg.jpg"))); // NOI18N
        t3Adlogin.add(bgL3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-2, 32, 1280, 880));

        jTabbedPane1.addTab("tab3", t3Adlogin);

        t4StuMenu.setBackground(new java.awt.Color(255, 255, 255));

        headingL4.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL4.setText("STUDENT MENU");

        prnL4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL4.setText("PRN");

        firstnameL4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        firstnameL4.setText("First Name");

        lastnameL4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lastnameL4.setText("Last Name");

        yearL4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        yearL4.setText("Year");

        branchidL4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchidL4.setText("Branch");

        semesterL4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        semesterL4.setText("Semester");

        dobL4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        dobL4.setText("DOB");

        prnI4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        firstnameI4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lastnameI4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        yearI4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        branchidI4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        semesterI4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        dobI4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        fathernameL4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        fathernameL4.setText("Father's Name");

        emailL4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        emailL4.setText("Email");

        phonenumberL4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        phonenumberL4.setText("Phone Number");

        addressL4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addressL4.setText("Address");

        fathernameI4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        emailI4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        phonenumber1I4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        phonenumber2I4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        address1I4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        address3I4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        address3I4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                address3I4ActionPerformed(evt);
            }
        });

        address2I4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        address2I4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                address2I4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t4StuMenuLayout = new javax.swing.GroupLayout(t4StuMenu);
        t4StuMenu.setLayout(t4StuMenuLayout);
        t4StuMenuLayout.setHorizontalGroup(
                t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(t4StuMenuLayout.createSequentialGroup()
                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(t4StuMenuLayout.createSequentialGroup()
                                                .addGap(200, 200, 200)
                                                .addComponent(dobL4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(89, 89, 89)
                                                .addComponent(dobI4, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(t4StuMenuLayout.createSequentialGroup()
                                                .addGap(495, 495, 495)
                                                .addComponent(headingL4))
                                        .addGroup(t4StuMenuLayout.createSequentialGroup()
                                                .addGap(220, 220, 220)
                                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(t4StuMenuLayout.createSequentialGroup()
                                                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                                        .addComponent(prnL4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(lastnameL4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(branchidL4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(yearL4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(semesterL4, javax.swing.GroupLayout.Alignment.LEADING))
                                                                .addGap(39, 39, 39))
                                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, t4StuMenuLayout.createSequentialGroup()
                                                                .addComponent(firstnameL4, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(29, 29, 29)))
                                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(prnI4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGroup(t4StuMenuLayout.createSequentialGroup()
                                                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(branchidI4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(lastnameI4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(yearI4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(semesterI4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(firstnameI4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGap(160, 160, 160)
                                                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                                        .addComponent(emailL4, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(phonenumberL4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                        .addComponent(fathernameL4, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(addressL4, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                .addGap(50, 50, 50)
                                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                                .addComponent(fathernameI4)
                                                                .addComponent(emailI4)
                                                                .addComponent(phonenumber1I4)
                                                                .addComponent(phonenumber2I4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addComponent(address1I4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(address3I4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(address2I4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addContainerGap(2261, Short.MAX_VALUE))
        );
        t4StuMenuLayout.setVerticalGroup(
                t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, t4StuMenuLayout.createSequentialGroup()
                                .addGap(125, 125, 125)
                                .addComponent(headingL4)
                                .addGap(125, 125, 125)
                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(prnL4)
                                        .addComponent(prnI4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(fathernameL4)
                                        .addComponent(fathernameI4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(43, 43, 43)
                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(firstnameL4)
                                        .addComponent(firstnameI4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(emailL4)
                                        .addComponent(emailI4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(43, 43, 43)
                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lastnameL4)
                                        .addComponent(lastnameI4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(phonenumberL4)
                                        .addComponent(phonenumber1I4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(43, 43, 43)
                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(yearL4)
                                        .addComponent(yearI4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(phonenumber2I4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(43, 43, 43)
                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(branchidI4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(branchidL4)
                                        .addComponent(addressL4)
                                        .addComponent(address1I4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(t4StuMenuLayout.createSequentialGroup()
                                                .addGap(43, 43, 43)
                                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(semesterI4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(semesterL4)))
                                        .addGroup(t4StuMenuLayout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(address2I4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(address3I4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 768, Short.MAX_VALUE)
                                .addGroup(t4StuMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(dobL4, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(dobI4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(233, 233, 233))
        );

        jTabbedPane1.addTab("tab4", t4StuMenu);

        t5AdMenu.setBackground(new java.awt.Color(255, 255, 255));

        headingL5.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL5.setText("ADMIN PROFILE");

        adminidL5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        adminidL5.setText("Admin ID");

        firstnameL5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        firstnameL5.setText("First Name");

        lastnamel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lastnamel5.setText("Last Name");

        emailL5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        emailL5.setText("Email");

        adminidI5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        firstnameI5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        lastnameI5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        emailI5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t5AdMenuLayout = new javax.swing.GroupLayout(t5AdMenu);
        t5AdMenu.setLayout(t5AdMenuLayout);
        t5AdMenuLayout.setHorizontalGroup(
                t5AdMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(t5AdMenuLayout.createSequentialGroup()
                                .addGroup(t5AdMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(t5AdMenuLayout.createSequentialGroup()
                                                .addGap(495, 495, 495)
                                                .addComponent(headingL5))
                                        .addGroup(t5AdMenuLayout.createSequentialGroup()
                                                .addGap(400, 400, 400)
                                                .addGroup(t5AdMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(firstnameL5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(lastnamel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(emailL5, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(adminidL5, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(210, 210, 210)
                                                .addGroup(t5AdMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(firstnameI5, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(adminidI5, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(lastnameI5, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(emailI5, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addContainerGap(2452, Short.MAX_VALUE))
        );
        t5AdMenuLayout.setVerticalGroup(
                t5AdMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(t5AdMenuLayout.createSequentialGroup()
                                .addGap(125, 125, 125)
                                .addComponent(headingL5)
                                .addGap(125, 125, 125)
                                .addGroup(t5AdMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(t5AdMenuLayout.createSequentialGroup()
                                                .addGroup(t5AdMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(adminidL5)
                                                        .addComponent(adminidI5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(72, 72, 72)
                                                .addComponent(firstnameL5))
                                        .addComponent(firstnameI5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(72, 72, 72)
                                .addGroup(t5AdMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lastnamel5)
                                        .addComponent(lastnameI5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(69, 69, 69)
                                .addGroup(t5AdMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(emailL5)
                                        .addComponent(emailI5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(1103, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab5", t5AdMenu);

        t6AdLogin.setBackground(new java.awt.Color(255, 255, 255));

        headingLt6.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingLt6.setText("ADMIN LOGIN");

        adminTABt6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminTABt6.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "Admin ID", "Admin Password"
                }
        ));
        adminTABt6.setRowHeight(30);
        adminTABt6.setSelectionBackground(new java.awt.Color(153, 153, 153));
        scrollt6.setViewportView(adminTABt6);

        deleteBt6.setBackground(new java.awt.Color(0, 0, 0));
        deleteBt6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteBt6.setForeground(new java.awt.Color(255, 255, 255));
        deleteBt6.setText("Delete");
        deleteBt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBt6ActionPerformed(evt);
            }
        });

        addBt6.setBackground(new java.awt.Color(0, 0, 0));
        addBt6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addBt6.setForeground(new java.awt.Color(255, 255, 255));
        addBt6.setText("Add");
        addBt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBt6ActionPerformed(evt);
            }
        });

        updateBt6.setBackground(new java.awt.Color(0, 0, 0));
        updateBt6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateBt6.setForeground(new java.awt.Color(255, 255, 255));
        updateBt6.setText("Update");
        updateBt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBt6ActionPerformed(evt);
            }
        });

        showBt6.setBackground(new java.awt.Color(0, 0, 0));
        showBt6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showBt6.setForeground(new java.awt.Color(255, 255, 255));
        showBt6.setText("Show");
        showBt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showBt6ActionPerformed(evt);
            }
        });

        hideBt6.setBackground(new java.awt.Color(0, 0, 0));
        hideBt6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideBt6.setForeground(new java.awt.Color(255, 255, 255));
        hideBt6.setText("Hide");
        hideBt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideBt6ActionPerformed(evt);
            }
        });

        findBt6.setBackground(new java.awt.Color(0, 0, 0));
        findBt6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findBt6.setForeground(new java.awt.Color(255, 255, 255));
        findBt6.setText("Find");
        findBt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findBt6ActionPerformed(evt);
            }
        });

        findIt6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        findIt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findIt6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t6AdLoginLayout = new javax.swing.GroupLayout(t6AdLogin);
        t6AdLogin.setLayout(t6AdLoginLayout);
        t6AdLoginLayout.setHorizontalGroup(
                t6AdLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(t6AdLoginLayout.createSequentialGroup()
                                .addGroup(t6AdLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(t6AdLoginLayout.createSequentialGroup()
                                                .addGap(160, 160, 160)
                                                .addComponent(scrollt6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(160, 160, 160)
                                                .addGroup(t6AdLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(addBt6)
                                                        .addComponent(showBt6)
                                                        .addGroup(t6AdLoginLayout.createSequentialGroup()
                                                                .addGroup(t6AdLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                                        .addComponent(hideBt6)
                                                                        .addComponent(findBt6))
                                                                .addGap(80, 80, 80)
                                                                .addComponent(findIt6, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addComponent(deleteBt6)
                                                        .addComponent(updateBt6)))
                                        .addGroup(t6AdLoginLayout.createSequentialGroup()
                                                .addGap(495, 495, 495)
                                                .addComponent(headingLt6)))
                                .addGap(463, 2226, Short.MAX_VALUE))
        );
        t6AdLoginLayout.setVerticalGroup(
                t6AdLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(t6AdLoginLayout.createSequentialGroup()
                                .addGap(125, 125, 125)
                                .addComponent(headingLt6)
                                .addGap(125, 125, 125)
                                .addGroup(t6AdLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(t6AdLoginLayout.createSequentialGroup()
                                                .addComponent(addBt6)
                                                .addGap(48, 48, 48)
                                                .addComponent(updateBt6)
                                                .addGap(48, 48, 48)
                                                .addComponent(deleteBt6)
                                                .addGap(48, 48, 48)
                                                .addComponent(showBt6)
                                                .addGap(48, 48, 48)
                                                .addComponent(hideBt6)
                                                .addGap(48, 48, 48)
                                                .addGroup(t6AdLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(findBt6)
                                                        .addComponent(findIt6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addComponent(scrollt6))
                                .addContainerGap(990, Short.MAX_VALUE))
        );
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

       

        jTabbedPane1.addTab("tab6", t6AdLogin);

        t6_1AdUpdate.setBackground(new java.awt.Color(255, 255, 255));

        headingLt6_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingLt6_1.setText("Update");

        adminidLt6_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        adminidLt6_1.setText("Admin ID");

        adminidIt6_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminidIt6_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminidIt6_1ActionPerformed(evt);
            }
        });

        passoldLt6_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        passoldLt6_1.setText("Old Password");

        passwordoldIt6_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        passwordoldIt6_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordoldIt6_1ActionPerformed(evt);
            }
        });

        passnewLt6_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        passnewLt6_1.setText("New Password");

        passwordnewIt6_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        passwordnewIt6_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordnewIt6_1ActionPerformed(evt);
            }
        });

        submitBt6_1.setBackground(new java.awt.Color(0, 0, 0));
        submitBt6_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitBt6_1.setForeground(new java.awt.Color(255, 255, 255));
        submitBt6_1.setText("Submit");
        submitBt6_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBt6_1ActionPerformed(evt);
            }
        });

        resetBt6_1.setBackground(new java.awt.Color(0, 0, 0));
        resetBt6_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetBt6_1.setForeground(new java.awt.Color(255, 255, 255));
        resetBt6_1.setText("Reset");
        resetBt6_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBt6_1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t6_1AdUpdateLayout = new javax.swing.GroupLayout(t6_1AdUpdate);
        t6_1AdUpdate.setLayout(t6_1AdUpdateLayout);
        t6_1AdUpdateLayout.setHorizontalGroup(
            t6_1AdUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t6_1AdUpdateLayout.createSequentialGroup()
                .addGap(400, 400, 400)
                .addGroup(t6_1AdUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t6_1AdUpdateLayout.createSequentialGroup()
                        .addGroup(t6_1AdUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminidLt6_1)
                            .addComponent(passnewLt6_1))
                        .addGap(210, 210, 210)
                        .addGroup(t6_1AdUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(passwordoldIt6_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(passwordnewIt6_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(adminidIt6_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)))
                    .addComponent(passoldLt6_1))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(t6_1AdUpdateLayout.createSequentialGroup()
                .addGroup(t6_1AdUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t6_1AdUpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingLt6_1, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t6_1AdUpdateLayout.createSequentialGroup()
                        .addGap(479, 479, 479)
                        .addComponent(submitBt6_1)
                        .addGap(240, 240, 240)
                        .addComponent(resetBt6_1)))
                .addContainerGap(2478, Short.MAX_VALUE))
        );
        t6_1AdUpdateLayout.setVerticalGroup(
            t6_1AdUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t6_1AdUpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingLt6_1)
                .addGap(125, 125, 125)
                .addGroup(t6_1AdUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminidLt6_1)
                    .addComponent(adminidIt6_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(95, 95, 95)
                .addGroup(t6_1AdUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(passoldLt6_1)
                    .addComponent(passwordoldIt6_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(95, 95, 95)
                .addGroup(t6_1AdUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(passnewLt6_1)
                    .addComponent(passwordnewIt6_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t6_1AdUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitBt6_1)
                    .addComponent(resetBt6_1))
                .addContainerGap(994, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab7", t6_1AdUpdate);

        t6_2AdAdd.setBackground(new java.awt.Color(255, 255, 255));

        headingLt6_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingLt6_2.setText("Add");

        adminidLt6_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        adminidLt6_2.setText("Admin ID");

        passLt6_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        passLt6_2.setText("Password");

        submitBt6_2.setBackground(new java.awt.Color(0, 0, 0));
        submitBt6_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitBt6_2.setForeground(new java.awt.Color(255, 255, 255));
        submitBt6_2.setText("Submit");
        submitBt6_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBt6_2ActionPerformed(evt);
            }
        });

        resetBt6_2.setBackground(new java.awt.Color(0, 0, 0));
        resetBt6_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetBt6_2.setForeground(new java.awt.Color(255, 255, 255));
        resetBt6_2.setText("Reset");
        resetBt6_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBt6_2ActionPerformed(evt);
            }
        });

        adminidIt6_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminidIt6_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminidIt6_2ActionPerformed(evt);
            }
        });

        passwordIt6_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        passwordIt6_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordIt6_2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t6_2AdAddLayout = new javax.swing.GroupLayout(t6_2AdAdd);
        t6_2AdAdd.setLayout(t6_2AdAddLayout);
        t6_2AdAddLayout.setHorizontalGroup(
            t6_2AdAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t6_2AdAddLayout.createSequentialGroup()
                .addGroup(t6_2AdAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t6_2AdAddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t6_2AdAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminidLt6_2)
                            .addComponent(passLt6_2))
                        .addGap(210, 210, 210)
                        .addGroup(t6_2AdAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminidIt6_2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(passwordIt6_2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t6_2AdAddLayout.createSequentialGroup()
                        .addGap(458, 458, 458)
                        .addComponent(submitBt6_2)
                        .addGap(240, 240, 240)
                        .addComponent(resetBt6_2))
                    .addGroup(t6_2AdAddLayout.createSequentialGroup()
                        .addGap(610, 610, 610)
                        .addComponent(headingLt6_2, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2456, Short.MAX_VALUE))
        );
        t6_2AdAddLayout.setVerticalGroup(
            t6_2AdAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t6_2AdAddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingLt6_2)
                .addGap(124, 124, 124)
                .addGroup(t6_2AdAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminidIt6_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(adminidLt6_2))
                .addGap(125, 125, 125)
                .addGroup(t6_2AdAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(passLt6_2)
                    .addComponent(passwordIt6_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t6_2AdAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitBt6_2)
                    .addComponent(resetBt6_2))
                .addContainerGap(1087, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab8", t6_2AdAdd);

        t6_3AdDelete.setBackground(new java.awt.Color(255, 255, 255));

        headingLt6_3.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingLt6_3.setText("Delete");

        adminidLt6_3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        adminidLt6_3.setText("Admin ID");

        passLt6_3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        passLt6_3.setText("Password");

        adminidIt6_3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminidIt6_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminidIt6_3ActionPerformed(evt);
            }
        });

        passwordIt6_3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        passwordIt6_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordIt6_3ActionPerformed(evt);
            }
        });

        resetBt6_3.setBackground(new java.awt.Color(0, 0, 0));
        resetBt6_3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetBt6_3.setForeground(new java.awt.Color(255, 255, 255));
        resetBt6_3.setText("Reset");
        resetBt6_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBt6_3ActionPerformed(evt);
            }
        });

        submitBt6_3.setBackground(new java.awt.Color(0, 0, 0));
        submitBt6_3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitBt6_3.setForeground(new java.awt.Color(255, 255, 255));
        submitBt6_3.setText("Submit");
        submitBt6_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBt6_3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t6_3AdDeleteLayout = new javax.swing.GroupLayout(t6_3AdDelete);
        t6_3AdDelete.setLayout(t6_3AdDeleteLayout);
        t6_3AdDeleteLayout.setHorizontalGroup(
            t6_3AdDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t6_3AdDeleteLayout.createSequentialGroup()
                .addGroup(t6_3AdDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t6_3AdDeleteLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t6_3AdDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminidLt6_3)
                            .addComponent(passLt6_3))
                        .addGap(210, 210, 210)
                        .addGroup(t6_3AdDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminidIt6_3, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(passwordIt6_3, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t6_3AdDeleteLayout.createSequentialGroup()
                        .addGap(463, 463, 463)
                        .addComponent(submitBt6_3)
                        .addGap(235, 235, 235)
                        .addComponent(resetBt6_3))
                    .addGroup(t6_3AdDeleteLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingLt6_3, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2365, Short.MAX_VALUE))
        );
        t6_3AdDeleteLayout.setVerticalGroup(
            t6_3AdDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t6_3AdDeleteLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingLt6_3)
                .addGap(125, 125, 125)
                .addGroup(t6_3AdDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(adminidIt6_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(adminidLt6_3))
                .addGap(125, 125, 125)
                .addGroup(t6_3AdDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(passLt6_3)
                    .addComponent(passwordIt6_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t6_3AdDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resetBt6_3)
                    .addComponent(submitBt6_3))
                .addContainerGap(1087, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab9", t6_3AdDelete);

        t7StuLogin.setBackground(new java.awt.Color(255, 255, 255));

        headingLt7.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingLt7.setText("STUDENT LOGIN");

        jTable7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PRN", "Student Password"
            }
        ));
        jTable7.setRowHeight(30);
        scroll7.setViewportView(jTable7);

        deleteBt7.setBackground(new java.awt.Color(0, 0, 0));
        deleteBt7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteBt7.setForeground(new java.awt.Color(255, 255, 255));
        deleteBt7.setText("Delete");
        deleteBt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBt7ActionPerformed(evt);
            }
        });

        addBt7.setBackground(new java.awt.Color(0, 0, 0));
        addBt7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addBt7.setForeground(new java.awt.Color(255, 255, 255));
        addBt7.setText("Add");
        addBt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBt7ActionPerformed(evt);
            }
        });

        updateBt7.setBackground(new java.awt.Color(0, 0, 0));
        updateBt7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateBt7.setForeground(new java.awt.Color(255, 255, 255));
        updateBt7.setText("Update");
        updateBt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBt7ActionPerformed(evt);
            }
        });

        showBt7.setBackground(new java.awt.Color(0, 0, 0));
        showBt7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showBt7.setForeground(new java.awt.Color(255, 255, 255));
        showBt7.setText("Show");
        showBt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showBt7ActionPerformed(evt);
            }
        });

        hideBt7.setBackground(new java.awt.Color(0, 0, 0));
        hideBt7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideBt7.setForeground(new java.awt.Color(255, 255, 255));
        hideBt7.setText("Hide");
        hideBt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideBt7ActionPerformed(evt);
            }
        });

        findBt7.setBackground(new java.awt.Color(0, 0, 0));
        findBt7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findBt7.setForeground(new java.awt.Color(255, 255, 255));
        findBt7.setText("Find");
        findBt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findBt7ActionPerformed(evt);
            }
        });

        findIt7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t7StuLoginLayout = new javax.swing.GroupLayout(t7StuLogin);
        t7StuLogin.setLayout(t7StuLoginLayout);
        t7StuLoginLayout.setHorizontalGroup(
            t7StuLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t7StuLoginLayout.createSequentialGroup()
                .addGroup(t7StuLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(t7StuLoginLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingLt7, javax.swing.GroupLayout.PREFERRED_SIZE, 419, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, t7StuLoginLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(scroll7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 160, Short.MAX_VALUE)
                        .addGroup(t7StuLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(hideBt7)
                            .addComponent(showBt7)
                            .addComponent(addBt7)
                            .addGroup(t7StuLoginLayout.createSequentialGroup()
                                .addComponent(findBt7)
                                .addGap(80, 80, 80)
                                .addComponent(findIt7, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(updateBt7)
                            .addComponent(deleteBt7))))
                .addContainerGap(2226, Short.MAX_VALUE))
        );
        t7StuLoginLayout.setVerticalGroup(
            t7StuLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t7StuLoginLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingLt7)
                .addGap(125, 125, 125)
                .addGroup(t7StuLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(t7StuLoginLayout.createSequentialGroup()
                        .addComponent(addBt7)
                        .addGap(48, 48, 48)
                        .addComponent(updateBt7)
                        .addGap(48, 48, 48)
                        .addComponent(deleteBt7)
                        .addGap(48, 48, 48)
                        .addComponent(showBt7)
                        .addGap(48, 48, 48)
                        .addComponent(hideBt7)
                        .addGap(48, 48, 48)
                        .addGroup(t7StuLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(findBt7)
                            .addComponent(findIt7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(scroll7))
                .addContainerGap(990, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab10", t7StuLogin);

        t7_1StuUpdate.setBackground(new java.awt.Color(255, 255, 255));

        headingLt7_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingLt7_1.setText("Update");

        prnLt7_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnLt7_1.setText("PRN");

        passwordLt7_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        passwordLt7_1.setText("Password");

        prnIt7_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        prnIt7_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                prnIt7_1MouseClicked(evt);
            }
        });

        passwordIt7_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jTable7_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable7_1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PRN", "Password"
            }
        ));
        jTable7_1.setRowHeight(30);
        jTable7_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable7_1MouseClicked(evt);
            }
        });
        scrollt7_1.setViewportView(jTable7_1);

        updateBt7_1.setBackground(new java.awt.Color(0, 0, 0));
        updateBt7_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateBt7_1.setForeground(new java.awt.Color(255, 255, 255));
        updateBt7_1.setText("Submit");
        updateBt7_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBt7_1ActionPerformed(evt);
            }
        });

        showBt7_1.setBackground(new java.awt.Color(0, 0, 0));
        showBt7_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showBt7_1.setForeground(new java.awt.Color(255, 255, 255));
        showBt7_1.setText("Show");
        showBt7_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showBt7_1ActionPerformed(evt);
            }
        });

        hideBt7_1.setBackground(new java.awt.Color(0, 0, 0));
        hideBt7_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideBt7_1.setForeground(new java.awt.Color(255, 255, 255));
        hideBt7_1.setText("Hide");
        hideBt7_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideBt7_1ActionPerformed(evt);
            }
        });

        resetBt7_1.setBackground(new java.awt.Color(0, 0, 0));
        resetBt7_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetBt7_1.setForeground(new java.awt.Color(255, 255, 255));
        resetBt7_1.setText("Reset");
        resetBt7_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBt7_1ActionPerformed(evt);
            }
        });

        findB7_1.setBackground(new java.awt.Color(0, 0, 0));
        findB7_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB7_1.setForeground(new java.awt.Color(255, 255, 255));
        findB7_1.setText("Find");
        findB7_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB7_1ActionPerformed(evt);
            }
        });

        findI7_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t7_1StuUpdateLayout = new javax.swing.GroupLayout(t7_1StuUpdate);
        t7_1StuUpdate.setLayout(t7_1StuUpdateLayout);
        t7_1StuUpdateLayout.setHorizontalGroup(
            t7_1StuUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t7_1StuUpdateLayout.createSequentialGroup()
                .addGroup(t7_1StuUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t7_1StuUpdateLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(t7_1StuUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(t7_1StuUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, t7_1StuUpdateLayout.createSequentialGroup()
                                    .addComponent(passwordLt7_1)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                                    .addComponent(passwordIt7_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, t7_1StuUpdateLayout.createSequentialGroup()
                                    .addComponent(prnLt7_1)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(prnIt7_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(t7_1StuUpdateLayout.createSequentialGroup()
                                .addComponent(updateBt7_1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(resetBt7_1)
                                .addGap(18, 18, 18)
                                .addComponent(showBt7_1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(hideBt7_1)))
                        .addGap(160, 160, 160)
                        .addGroup(t7_1StuUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t7_1StuUpdateLayout.createSequentialGroup()
                                .addComponent(findB7_1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(findI7_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(scrollt7_1, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t7_1StuUpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingLt7_1, javax.swing.GroupLayout.PREFERRED_SIZE, 447, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2207, Short.MAX_VALUE))
        );
        t7_1StuUpdateLayout.setVerticalGroup(
            t7_1StuUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t7_1StuUpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingLt7_1)
                .addGap(125, 125, 125)
                .addGroup(t7_1StuUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t7_1StuUpdateLayout.createSequentialGroup()
                        .addGroup(t7_1StuUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(prnLt7_1)
                            .addComponent(prnIt7_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(100, 100, 100)
                        .addGroup(t7_1StuUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(passwordLt7_1)
                            .addComponent(passwordIt7_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(scrollt7_1, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(t7_1StuUpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(showBt7_1)
                    .addComponent(hideBt7_1)
                    .addComponent(updateBt7_1)
                    .addComponent(resetBt7_1)
                    .addComponent(findB7_1)
                    .addComponent(findI7_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(1036, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab11", t7_1StuUpdate);

        t7_2StuAdd.setBackground(new java.awt.Color(255, 255, 255));

        headingLt7_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingLt7_2.setText("Add");

        prnLt7_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnLt7_2.setText("PRN");

        passLt7_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        passLt7_2.setText("Password");

        prnIt7_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        prnIt7_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prnIt7_2ActionPerformed(evt);
            }
        });

        passwordIt7_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        passwordIt7_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordIt7_2ActionPerformed(evt);
            }
        });

        submitBt7_2.setBackground(new java.awt.Color(0, 0, 0));
        submitBt7_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitBt7_2.setForeground(new java.awt.Color(255, 255, 255));
        submitBt7_2.setText("Submit");
        submitBt7_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBt7_2ActionPerformed(evt);
            }
        });

        resetBt7_2.setBackground(new java.awt.Color(0, 0, 0));
        resetBt7_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetBt7_2.setForeground(new java.awt.Color(255, 255, 255));
        resetBt7_2.setText("Reset");
        resetBt7_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBt7_2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t7_2StuAddLayout = new javax.swing.GroupLayout(t7_2StuAdd);
        t7_2StuAdd.setLayout(t7_2StuAddLayout);
        t7_2StuAddLayout.setHorizontalGroup(
            t7_2StuAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t7_2StuAddLayout.createSequentialGroup()
                .addGroup(t7_2StuAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t7_2StuAddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t7_2StuAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(prnLt7_2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(passLt7_2))
                        .addGap(210, 210, 210)
                        .addGroup(t7_2StuAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(passwordIt7_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(prnIt7_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t7_2StuAddLayout.createSequentialGroup()
                        .addGap(610, 610, 610)
                        .addComponent(headingLt7_2))
                    .addGroup(t7_2StuAddLayout.createSequentialGroup()
                        .addGap(482, 482, 482)
                        .addComponent(submitBt7_2)
                        .addGap(240, 240, 240)
                        .addComponent(resetBt7_2)))
                .addContainerGap(2462, Short.MAX_VALUE))
        );
        t7_2StuAddLayout.setVerticalGroup(
            t7_2StuAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t7_2StuAddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingLt7_2)
                .addGap(125, 125, 125)
                .addGroup(t7_2StuAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(prnLt7_2)
                    .addComponent(prnIt7_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t7_2StuAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(passLt7_2)
                    .addComponent(passwordIt7_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t7_2StuAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitBt7_2)
                    .addComponent(resetBt7_2))
                .addContainerGap(1086, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab12", t7_2StuAdd);

        t7_3StuDelete.setBackground(new java.awt.Color(255, 255, 255));

        headingLt7_3.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingLt7_3.setText("Delete");

        prnLt7_3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnLt7_3.setText("PRN");

        passLt7_3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        passLt7_3.setText("Password");

        prnIt7_3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        prnIt7_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prnIt7_3ActionPerformed(evt);
            }
        });

        passwordIt7_3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        passwordIt7_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordIt7_3ActionPerformed(evt);
            }
        });

        resetBt7_3.setBackground(new java.awt.Color(0, 0, 0));
        resetBt7_3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetBt7_3.setForeground(new java.awt.Color(255, 255, 255));
        resetBt7_3.setText("Reset");
        resetBt7_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBt7_3ActionPerformed(evt);
            }
        });

        submitBt7_3.setBackground(new java.awt.Color(0, 0, 0));
        submitBt7_3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitBt7_3.setForeground(new java.awt.Color(255, 255, 255));
        submitBt7_3.setText("Submit");
        submitBt7_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBt7_3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t7_3StuDeleteLayout = new javax.swing.GroupLayout(t7_3StuDelete);
        t7_3StuDelete.setLayout(t7_3StuDeleteLayout);
        t7_3StuDeleteLayout.setHorizontalGroup(
            t7_3StuDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t7_3StuDeleteLayout.createSequentialGroup()
                .addGroup(t7_3StuDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t7_3StuDeleteLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t7_3StuDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(prnLt7_3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(passLt7_3))
                        .addGap(210, 210, 210)
                        .addGroup(t7_3StuDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(passwordIt7_3, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(prnIt7_3, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t7_3StuDeleteLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingLt7_3, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t7_3StuDeleteLayout.createSequentialGroup()
                        .addGap(477, 477, 477)
                        .addComponent(submitBt7_3)
                        .addGap(240, 240, 240)
                        .addComponent(resetBt7_3)))
                .addContainerGap(2440, Short.MAX_VALUE))
        );
        t7_3StuDeleteLayout.setVerticalGroup(
            t7_3StuDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t7_3StuDeleteLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingLt7_3)
                .addGap(125, 125, 125)
                .addGroup(t7_3StuDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(prnIt7_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(prnLt7_3))
                .addGap(125, 125, 125)
                .addGroup(t7_3StuDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(passwordIt7_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(passLt7_3))
                .addGap(125, 125, 125)
                .addGroup(t7_3StuDeleteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resetBt7_3)
                    .addComponent(submitBt7_3))
                .addContainerGap(1086, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab13", t7_3StuDelete);

        t8AdGrades.setBackground(new java.awt.Color(255, 255, 255));

        headingL8.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL8.setText("ADMIN GRADES");

        jTable8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable8.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "PRN", "Mid Sem Marks", "End Sem Marks"
            }
        ));
        jTable8.setRowHeight(30);
        jScrollPane8.setViewportView(jTable8);

        addB8.setBackground(new java.awt.Color(0, 0, 0));
        addB8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addB8.setForeground(new java.awt.Color(255, 255, 255));
        addB8.setText("Add");
        addB8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addB8ActionPerformed(evt);
            }
        });

        updateB8.setBackground(new java.awt.Color(0, 0, 0));
        updateB8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateB8.setForeground(new java.awt.Color(255, 255, 255));
        updateB8.setText("Update");
        updateB8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateB8ActionPerformed(evt);
            }
        });

        deleteB8.setBackground(new java.awt.Color(0, 0, 0));
        deleteB8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteB8.setForeground(new java.awt.Color(255, 255, 255));
        deleteB8.setText("Delete");
        deleteB8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteB8ActionPerformed(evt);
            }
        });

        showB8.setBackground(new java.awt.Color(0, 0, 0));
        showB8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB8.setForeground(new java.awt.Color(255, 255, 255));
        showB8.setText("Show");
        showB8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB8ActionPerformed(evt);
            }
        });

        hideB8.setBackground(new java.awt.Color(0, 0, 0));
        hideB8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB8.setForeground(new java.awt.Color(255, 255, 255));
        hideB8.setText("Hide");
        hideB8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB8ActionPerformed(evt);
            }
        });

        findB8.setBackground(new java.awt.Color(0, 0, 0));
        findB8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB8.setForeground(new java.awt.Color(255, 255, 255));
        findB8.setText("Find");
        findB8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB8ActionPerformed(evt);
            }
        });

        deleteI8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        deleteI8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteI8ActionPerformed(evt);
            }
        });

        findI8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t8AdGradesLayout = new javax.swing.GroupLayout(t8AdGrades);
        t8AdGrades.setLayout(t8AdGradesLayout);
        t8AdGradesLayout.setHorizontalGroup(
            t8AdGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t8AdGradesLayout.createSequentialGroup()
                .addGroup(t8AdGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t8AdGradesLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(160, 160, 160)
                        .addGroup(t8AdGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addB8)
                            .addComponent(updateB8)
                            .addComponent(showB8)
                            .addComponent(hideB8)
                            .addGroup(t8AdGradesLayout.createSequentialGroup()
                                .addGroup(t8AdGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(deleteB8)
                                    .addComponent(findB8))
                                .addGap(80, 80, 80)
                                .addGroup(t8AdGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(findI8, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(deleteI8, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(t8AdGradesLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL8, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2215, Short.MAX_VALUE))
        );
        t8AdGradesLayout.setVerticalGroup(
            t8AdGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t8AdGradesLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL8)
                .addGap(125, 125, 125)
                .addGroup(t8AdGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t8AdGradesLayout.createSequentialGroup()
                        .addComponent(addB8)
                        .addGap(48, 48, 48)
                        .addComponent(updateB8)
                        .addGap(48, 48, 48)
                        .addGroup(t8AdGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteB8)
                            .addComponent(deleteI8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addComponent(showB8)
                        .addGap(48, 48, 48)
                        .addComponent(hideB8)
                        .addGap(48, 48, 48)
                        .addGroup(t8AdGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(findB8)
                            .addComponent(findI8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 432, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(990, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab14", t8AdGrades);

        t9AdFaculty.setBackground(new java.awt.Color(255, 255, 255));

        headingL9.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL9.setText("ADMIN FACULTY");

        jTable9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable9.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Faculty ID", "Faculty Name", "Branch ID"
            }
        ));
        jTable9.setRowHeight(30);
        jScrollPane9.setViewportView(jTable9);

        addB9.setBackground(new java.awt.Color(0, 0, 0));
        addB9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addB9.setForeground(new java.awt.Color(255, 255, 255));
        addB9.setText("Add");
        addB9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addB9ActionPerformed(evt);
            }
        });

        updateB9.setBackground(new java.awt.Color(0, 0, 0));
        updateB9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateB9.setForeground(new java.awt.Color(255, 255, 255));
        updateB9.setText("Update");
        updateB9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateB9ActionPerformed(evt);
            }
        });

        deleteB9.setBackground(new java.awt.Color(0, 0, 0));
        deleteB9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteB9.setForeground(new java.awt.Color(255, 255, 255));
        deleteB9.setText("Delete");
        deleteB9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteB9ActionPerformed(evt);
            }
        });

        showB9.setBackground(new java.awt.Color(0, 0, 0));
        showB9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB9.setForeground(new java.awt.Color(255, 255, 255));
        showB9.setText("Show");
        showB9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB9ActionPerformed(evt);
            }
        });

        hideB9.setBackground(new java.awt.Color(0, 0, 0));
        hideB9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB9.setForeground(new java.awt.Color(255, 255, 255));
        hideB9.setText("Hide");
        hideB9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB9ActionPerformed(evt);
            }
        });

        findB9.setBackground(new java.awt.Color(0, 0, 0));
        findB9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB9.setForeground(new java.awt.Color(255, 255, 255));
        findB9.setText("Find");
        findB9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB9ActionPerformed(evt);
            }
        });

        deleteI9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        findI9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t9AdFacultyLayout = new javax.swing.GroupLayout(t9AdFaculty);
        t9AdFaculty.setLayout(t9AdFacultyLayout);
        t9AdFacultyLayout.setHorizontalGroup(
            t9AdFacultyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t9AdFacultyLayout.createSequentialGroup()
                .addGroup(t9AdFacultyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t9AdFacultyLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(160, 160, 160)
                        .addGroup(t9AdFacultyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addB9)
                            .addComponent(updateB9)
                            .addComponent(showB9)
                            .addComponent(hideB9)
                            .addGroup(t9AdFacultyLayout.createSequentialGroup()
                                .addGroup(t9AdFacultyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(deleteB9)
                                    .addComponent(findB9))
                                .addGap(80, 80, 80)
                                .addGroup(t9AdFacultyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(findI9, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(deleteI9, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(t9AdFacultyLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL9, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2215, Short.MAX_VALUE))
        );
        t9AdFacultyLayout.setVerticalGroup(
            t9AdFacultyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t9AdFacultyLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL9)
                .addGap(125, 125, 125)
                .addGroup(t9AdFacultyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(t9AdFacultyLayout.createSequentialGroup()
                        .addComponent(addB9)
                        .addGap(48, 48, 48)
                        .addComponent(updateB9)
                        .addGap(48, 48, 48)
                        .addGroup(t9AdFacultyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteB9)
                            .addComponent(deleteI9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addComponent(showB9)
                        .addGap(48, 48, 48)
                        .addComponent(hideB9)
                        .addGap(48, 48, 48)
                        .addGroup(t9AdFacultyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(findB9)
                            .addComponent(findI9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane9))
                .addContainerGap(990, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab15", t9AdFaculty);

        t10AdAttendance.setBackground(new java.awt.Color(255, 255, 255));

        headingL10.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL10.setText("ADMIN ATTENDANCE");

        jTable10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable10.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "PRN", "Percentage", "Date"
            }
        ));
        jTable10.setRowHeight(30);
        jScrollPane10.setViewportView(jTable10);

        addB10.setBackground(new java.awt.Color(0, 0, 0));
        addB10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addB10.setForeground(new java.awt.Color(255, 255, 255));
        addB10.setText("Add");
        addB10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addB10ActionPerformed(evt);
            }
        });

        updateB10.setBackground(new java.awt.Color(0, 0, 0));
        updateB10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateB10.setForeground(new java.awt.Color(255, 255, 255));
        updateB10.setText("Udpate");
        updateB10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateB10ActionPerformed(evt);
            }
        });

        deleteB10.setBackground(new java.awt.Color(0, 0, 0));
        deleteB10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteB10.setForeground(new java.awt.Color(255, 255, 255));
        deleteB10.setText("Delete");
        deleteB10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteB10ActionPerformed(evt);
            }
        });

        showB10.setBackground(new java.awt.Color(0, 0, 0));
        showB10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB10.setForeground(new java.awt.Color(255, 255, 255));
        showB10.setText("Show");
        showB10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB10ActionPerformed(evt);
            }
        });

        hideB10.setBackground(new java.awt.Color(0, 0, 0));
        hideB10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB10.setForeground(new java.awt.Color(255, 255, 255));
        hideB10.setText("Hide");
        hideB10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB10ActionPerformed(evt);
            }
        });

        findB10.setBackground(new java.awt.Color(0, 0, 0));
        findB10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB10.setForeground(new java.awt.Color(255, 255, 255));
        findB10.setText("Find");
        findB10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB10ActionPerformed(evt);
            }
        });

        deleteI10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        findI10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t10AdAttendanceLayout = new javax.swing.GroupLayout(t10AdAttendance);
        t10AdAttendance.setLayout(t10AdAttendanceLayout);
        t10AdAttendanceLayout.setHorizontalGroup(
            t10AdAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t10AdAttendanceLayout.createSequentialGroup()
                .addGap(160, 160, 160)
                .addGroup(t10AdAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(t10AdAttendanceLayout.createSequentialGroup()
                        .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(160, 160, 160)
                        .addGroup(t10AdAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(updateB10)
                            .addComponent(showB10)
                            .addComponent(hideB10)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, t10AdAttendanceLayout.createSequentialGroup()
                                .addGroup(t10AdAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(deleteB10)
                                    .addComponent(findB10))
                                .addGap(80, 80, 80)
                                .addGroup(t10AdAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(findI10, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(deleteI10, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(addB10)))
                    .addGroup(t10AdAttendanceLayout.createSequentialGroup()
                        .addComponent(headingL10)
                        .addGap(277, 277, 277)))
                .addContainerGap(2215, Short.MAX_VALUE))
        );
        t10AdAttendanceLayout.setVerticalGroup(
            t10AdAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t10AdAttendanceLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL10)
                .addGap(125, 125, 125)
                .addGroup(t10AdAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t10AdAttendanceLayout.createSequentialGroup()
                        .addComponent(addB10)
                        .addGap(48, 48, 48)
                        .addComponent(updateB10)
                        .addGap(48, 48, 48)
                        .addGroup(t10AdAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteB10)
                            .addComponent(deleteI10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addComponent(showB10)
                        .addGap(48, 48, 48)
                        .addComponent(hideB10)
                        .addGap(48, 48, 48)
                        .addGroup(t10AdAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(findB10)
                            .addComponent(findI10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 432, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(990, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab16", t10AdAttendance);

        t11AdLibrary.setBackground(new java.awt.Color(255, 255, 255));

        headingL11.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL11.setText("ADMIN LIBRARY");

        jTable11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable11.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Library ID", "Category", "Issue Date", "Return Date"
            }
        ));
        jTable11.setRowHeight(30);
        jScrollPane11.setViewportView(jTable11);

        addB11.setBackground(new java.awt.Color(0, 0, 0));
        addB11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addB11.setForeground(new java.awt.Color(255, 255, 255));
        addB11.setText("Add");
        addB11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addB11ActionPerformed(evt);
            }
        });

        updateB11.setBackground(new java.awt.Color(0, 0, 0));
        updateB11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateB11.setForeground(new java.awt.Color(255, 255, 255));
        updateB11.setText("Update");
        updateB11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateB11ActionPerformed(evt);
            }
        });

        deleteB11.setBackground(new java.awt.Color(0, 0, 0));
        deleteB11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteB11.setForeground(new java.awt.Color(255, 255, 255));
        deleteB11.setText("Delete");
        deleteB11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteB11ActionPerformed(evt);
            }
        });

        showB11.setBackground(new java.awt.Color(0, 0, 0));
        showB11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB11.setForeground(new java.awt.Color(255, 255, 255));
        showB11.setText("Show");
        showB11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB11ActionPerformed(evt);
            }
        });

        hideB11.setBackground(new java.awt.Color(0, 0, 0));
        hideB11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB11.setForeground(new java.awt.Color(255, 255, 255));
        hideB11.setText("Hide");
        hideB11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB11ActionPerformed(evt);
            }
        });

        findB11.setBackground(new java.awt.Color(0, 0, 0));
        findB11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB11.setForeground(new java.awt.Color(255, 255, 255));
        findB11.setText("Find");
        findB11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB11ActionPerformed(evt);
            }
        });

        deleteI11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        deleteI11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteI11ActionPerformed(evt);
            }
        });

        findI11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        deleteissueI11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t11AdLibraryLayout = new javax.swing.GroupLayout(t11AdLibrary);
        t11AdLibrary.setLayout(t11AdLibraryLayout);
        t11AdLibraryLayout.setHorizontalGroup(
            t11AdLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t11AdLibraryLayout.createSequentialGroup()
                .addGroup(t11AdLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t11AdLibraryLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(160, 160, 160)
                        .addGroup(t11AdLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t11AdLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(updateB11)
                                .addComponent(addB11, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(deleteB11, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(showB11, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(hideB11, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(findB11))
                        .addGap(80, 80, 80)
                        .addGroup(t11AdLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(findI11, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteI11, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteissueI11, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t11AdLibraryLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL11, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2207, Short.MAX_VALUE))
        );
        t11AdLibraryLayout.setVerticalGroup(
            t11AdLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t11AdLibraryLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL11)
                .addGap(125, 125, 125)
                .addGroup(t11AdLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(t11AdLibraryLayout.createSequentialGroup()
                        .addComponent(addB11)
                        .addGap(48, 48, 48)
                        .addComponent(updateB11)
                        .addGap(48, 48, 48)
                        .addGroup(t11AdLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteB11)
                            .addComponent(deleteI11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(deleteissueI11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addComponent(showB11)
                        .addGap(48, 48, 48)
                        .addComponent(hideB11)
                        .addGap(48, 48, 48)
                        .addGroup(t11AdLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(findB11)
                            .addComponent(findI11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 434, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(988, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab17", t11AdLibrary);

        t12AdFees.setBackground(new java.awt.Color(255, 255, 255));

        headingL12.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL12.setText("ADMIN FEES");

        jTable12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable12.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "PRN", "Paid/Unpaid", "Fine"
            }
        ));
        jTable12.setRowHeight(30);
        jScrollPane12.setViewportView(jTable12);

        addB12.setBackground(new java.awt.Color(0, 0, 0));
        addB12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addB12.setForeground(new java.awt.Color(255, 255, 255));
        addB12.setText("Add");
        addB12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addB12ActionPerformed(evt);
            }
        });

        updateB12.setBackground(new java.awt.Color(0, 0, 0));
        updateB12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateB12.setForeground(new java.awt.Color(255, 255, 255));
        updateB12.setText("Update");
        updateB12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateB12ActionPerformed(evt);
            }
        });

        deleteB12.setBackground(new java.awt.Color(0, 0, 0));
        deleteB12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteB12.setForeground(new java.awt.Color(255, 255, 255));
        deleteB12.setText("Delete");
        deleteB12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteB12ActionPerformed(evt);
            }
        });

        showB12.setBackground(new java.awt.Color(0, 0, 0));
        showB12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB12.setForeground(new java.awt.Color(255, 255, 255));
        showB12.setText("Show");
        showB12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB12ActionPerformed(evt);
            }
        });

        hideB12.setBackground(new java.awt.Color(0, 0, 0));
        hideB12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB12.setForeground(new java.awt.Color(255, 255, 255));
        hideB12.setText("Hide");
        hideB12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB12ActionPerformed(evt);
            }
        });

        findB12.setBackground(new java.awt.Color(0, 0, 0));
        findB12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB12.setForeground(new java.awt.Color(255, 255, 255));
        findB12.setText("Find");
        findB12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB12ActionPerformed(evt);
            }
        });

        deleteI12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        findI12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        findI12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findI12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t12AdFeesLayout = new javax.swing.GroupLayout(t12AdFees);
        t12AdFees.setLayout(t12AdFeesLayout);
        t12AdFeesLayout.setHorizontalGroup(
            t12AdFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t12AdFeesLayout.createSequentialGroup()
                .addGroup(t12AdFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t12AdFeesLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(160, 160, 160)
                        .addGroup(t12AdFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(updateB12)
                            .addComponent(addB12)
                            .addComponent(deleteB12)
                            .addComponent(showB12)
                            .addComponent(hideB12)
                            .addComponent(findB12))
                        .addGap(80, 80, 80)
                        .addGroup(t12AdFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(deleteI12, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(findI12, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t12AdFeesLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL12)))
                .addContainerGap(2207, Short.MAX_VALUE))
        );
        t12AdFeesLayout.setVerticalGroup(
            t12AdFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t12AdFeesLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL12)
                .addGap(125, 125, 125)
                .addGroup(t12AdFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(t12AdFeesLayout.createSequentialGroup()
                        .addComponent(addB12)
                        .addGap(48, 48, 48)
                        .addComponent(updateB12)
                        .addGap(48, 48, 48)
                        .addGroup(t12AdFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteB12)
                            .addComponent(deleteI12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addComponent(showB12)
                        .addGap(48, 48, 48)
                        .addComponent(hideB12)
                        .addGap(48, 48, 48)
                        .addGroup(t12AdFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(findB12)
                            .addComponent(findI12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane12))
                .addContainerGap(990, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab18", t12AdFees);

        t13AdCourse.setBackground(new java.awt.Color(255, 255, 255));

        headingL13.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL13.setText("ADMIN COURSE");

        jTable13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable13.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Course ID", "Course Name", "Duration", "Branch ID"
            }
        ));
        jTable13.setRowHeight(30);
        jScrollPane13.setViewportView(jTable13);

        addB13.setBackground(new java.awt.Color(0, 0, 0));
        addB13.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addB13.setForeground(new java.awt.Color(255, 255, 255));
        addB13.setText("Add");
        addB13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addB13ActionPerformed(evt);
            }
        });

        updateB13.setBackground(new java.awt.Color(0, 0, 0));
        updateB13.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateB13.setForeground(new java.awt.Color(255, 255, 255));
        updateB13.setText("Update");
        updateB13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateB13ActionPerformed(evt);
            }
        });

        deleteB13.setBackground(new java.awt.Color(0, 0, 0));
        deleteB13.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteB13.setForeground(new java.awt.Color(255, 255, 255));
        deleteB13.setText("Delete");
        deleteB13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteB13ActionPerformed(evt);
            }
        });

        showB13.setBackground(new java.awt.Color(0, 0, 0));
        showB13.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB13.setForeground(new java.awt.Color(255, 255, 255));
        showB13.setText("Show");
        showB13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB13ActionPerformed(evt);
            }
        });

        hideB13.setBackground(new java.awt.Color(0, 0, 0));
        hideB13.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB13.setForeground(new java.awt.Color(255, 255, 255));
        hideB13.setText("Hide");
        hideB13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB13ActionPerformed(evt);
            }
        });

        findB13.setBackground(new java.awt.Color(0, 0, 0));
        findB13.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB13.setForeground(new java.awt.Color(255, 255, 255));
        findB13.setText("Find");
        findB13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB13ActionPerformed(evt);
            }
        });

        deleteI13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        deleteI13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteI13ActionPerformed(evt);
            }
        });

        findI13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t13AdCourseLayout = new javax.swing.GroupLayout(t13AdCourse);
        t13AdCourse.setLayout(t13AdCourseLayout);
        t13AdCourseLayout.setHorizontalGroup(
            t13AdCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t13AdCourseLayout.createSequentialGroup()
                .addGroup(t13AdCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t13AdCourseLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(160, 160, 160)
                        .addGroup(t13AdCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(findB13)
                            .addGroup(t13AdCourseLayout.createSequentialGroup()
                                .addGroup(t13AdCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(addB13)
                                    .addComponent(updateB13)
                                    .addComponent(deleteB13)
                                    .addComponent(showB13)
                                    .addComponent(hideB13))
                                .addGap(80, 80, 80)
                                .addGroup(t13AdCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(findI13, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(deleteI13, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(t13AdCourseLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL13)))
                .addContainerGap(2207, Short.MAX_VALUE))
        );
        t13AdCourseLayout.setVerticalGroup(
            t13AdCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t13AdCourseLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL13)
                .addGap(125, 125, 125)
                .addGroup(t13AdCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(t13AdCourseLayout.createSequentialGroup()
                        .addComponent(addB13)
                        .addGap(48, 48, 48)
                        .addComponent(updateB13)
                        .addGap(48, 48, 48)
                        .addGroup(t13AdCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteB13)
                            .addComponent(deleteI13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addComponent(showB13)
                        .addGap(48, 48, 48)
                        .addComponent(hideB13)
                        .addGap(48, 48, 48)
                        .addGroup(t13AdCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(findB13)
                            .addComponent(findI13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane13))
                .addContainerGap(990, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab19", t13AdCourse);

        t14AdHostel.setBackground(new java.awt.Color(255, 255, 255));

        headingL14.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL14.setText("ADMIN HOSTEL");

        jTable14.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable14.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "PRN", "Gender", "Simple Room", "Luxury Room"
            }
        ));
        jTable14.setRowHeight(30);
        jScrollPane14.setViewportView(jTable14);

        addB14.setBackground(new java.awt.Color(0, 0, 0));
        addB14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addB14.setForeground(new java.awt.Color(255, 255, 255));
        addB14.setText("Add");
        addB14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addB14ActionPerformed(evt);
            }
        });

        updateB14.setBackground(new java.awt.Color(0, 0, 0));
        updateB14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateB14.setForeground(new java.awt.Color(255, 255, 255));
        updateB14.setText("Update");
        updateB14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateB14ActionPerformed(evt);
            }
        });

        deleteB14.setBackground(new java.awt.Color(0, 0, 0));
        deleteB14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteB14.setForeground(new java.awt.Color(255, 255, 255));
        deleteB14.setText("Delete");
        deleteB14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteB14ActionPerformed(evt);
            }
        });

        showB14.setBackground(new java.awt.Color(0, 0, 0));
        showB14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB14.setForeground(new java.awt.Color(255, 255, 255));
        showB14.setText("Show");
        showB14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB14ActionPerformed(evt);
            }
        });

        hideB14.setBackground(new java.awt.Color(0, 0, 0));
        hideB14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB14.setForeground(new java.awt.Color(255, 255, 255));
        hideB14.setText("Hide");
        hideB14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB14ActionPerformed(evt);
            }
        });

        findB14.setBackground(new java.awt.Color(0, 0, 0));
        findB14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB14.setForeground(new java.awt.Color(255, 255, 255));
        findB14.setText("Find");
        findB14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB14ActionPerformed(evt);
            }
        });

        deleteI14.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        findI14.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t14AdHostelLayout = new javax.swing.GroupLayout(t14AdHostel);
        t14AdHostel.setLayout(t14AdHostelLayout);
        t14AdHostelLayout.setHorizontalGroup(
            t14AdHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t14AdHostelLayout.createSequentialGroup()
                .addGroup(t14AdHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t14AdHostelLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(160, 160, 160)
                        .addGroup(t14AdHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(updateB14, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(addB14)
                            .addComponent(deleteB14)
                            .addComponent(showB14)
                            .addComponent(hideB14)
                            .addComponent(findB14))
                        .addGap(80, 80, 80)
                        .addGroup(t14AdHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(deleteI14, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(findI14, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t14AdHostelLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL14)))
                .addContainerGap(2207, Short.MAX_VALUE))
        );
        t14AdHostelLayout.setVerticalGroup(
            t14AdHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t14AdHostelLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL14)
                .addGap(125, 125, 125)
                .addGroup(t14AdHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(t14AdHostelLayout.createSequentialGroup()
                        .addComponent(addB14)
                        .addGap(48, 48, 48)
                        .addComponent(updateB14)
                        .addGap(48, 48, 48)
                        .addGroup(t14AdHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteB14)
                            .addComponent(deleteI14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addComponent(showB14)
                        .addGap(48, 48, 48)
                        .addComponent(hideB14)
                        .addGap(48, 48, 48)
                        .addGroup(t14AdHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(findI14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(findB14)))
                    .addComponent(jScrollPane14))
                .addContainerGap(990, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab20", t14AdHostel);

        t15AdTimeT.setBackground(new java.awt.Color(255, 255, 255));

        headingL15.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL15.setText("ADMIN TIME TABLE");

        jTable15.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable15.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Time Table ID", "Course ID", "Faculty ID", "Room Number", "Timings"
            }
        ));
        jTable15.setRowHeight(30);
        jScrollPane15.setViewportView(jTable15);

        addB15.setBackground(new java.awt.Color(0, 0, 0));
        addB15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addB15.setForeground(new java.awt.Color(255, 255, 255));
        addB15.setText("Add");
        addB15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addB15ActionPerformed(evt);
            }
        });

        updateB15.setBackground(new java.awt.Color(0, 0, 0));
        updateB15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateB15.setForeground(new java.awt.Color(255, 255, 255));
        updateB15.setText("Update");
        updateB15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateB15ActionPerformed(evt);
            }
        });

        deleteB15.setBackground(new java.awt.Color(0, 0, 0));
        deleteB15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteB15.setForeground(new java.awt.Color(255, 255, 255));
        deleteB15.setText("Delete");
        deleteB15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteB15ActionPerformed(evt);
            }
        });

        showB15.setBackground(new java.awt.Color(0, 0, 0));
        showB15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB15.setForeground(new java.awt.Color(255, 255, 255));
        showB15.setText("Show");
        showB15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB15ActionPerformed(evt);
            }
        });

        hideB15.setBackground(new java.awt.Color(0, 0, 0));
        hideB15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB15.setForeground(new java.awt.Color(255, 255, 255));
        hideB15.setText("Hide");
        hideB15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB15ActionPerformed(evt);
            }
        });

        findB15.setBackground(new java.awt.Color(0, 0, 0));
        findB15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB15.setForeground(new java.awt.Color(255, 255, 255));
        findB15.setText("Find");
        findB15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB15ActionPerformed(evt);
            }
        });

        deleteI15.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        deleteI15.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                deleteI15FocusGained(evt);
            }
        });
        deleteI15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteI15ActionPerformed(evt);
            }
        });

        findI15.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t15AdTimeTLayout = new javax.swing.GroupLayout(t15AdTimeT);
        t15AdTimeT.setLayout(t15AdTimeTLayout);
        t15AdTimeTLayout.setHorizontalGroup(
            t15AdTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t15AdTimeTLayout.createSequentialGroup()
                .addGap(160, 160, 160)
                .addGroup(t15AdTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(t15AdTimeTLayout.createSequentialGroup()
                        .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(160, 160, 160)
                        .addGroup(t15AdTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(showB15)
                            .addComponent(hideB15)
                            .addGroup(t15AdTimeTLayout.createSequentialGroup()
                                .addGroup(t15AdTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(updateB15)
                                    .addComponent(addB15)
                                    .addComponent(deleteB15)
                                    .addComponent(findB15))
                                .addGap(80, 80, 80)
                                .addGroup(t15AdTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(findI15, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(deleteI15, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(t15AdTimeTLayout.createSequentialGroup()
                        .addComponent(headingL15, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(290, 290, 290)))
                .addContainerGap(2207, Short.MAX_VALUE))
        );
        t15AdTimeTLayout.setVerticalGroup(
            t15AdTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t15AdTimeTLayout.createSequentialGroup()
                .addGap(123, 123, 123)
                .addComponent(headingL15)
                .addGap(127, 127, 127)
                .addGroup(t15AdTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane15)
                    .addGroup(t15AdTimeTLayout.createSequentialGroup()
                        .addComponent(addB15)
                        .addGap(48, 48, 48)
                        .addComponent(updateB15)
                        .addGap(48, 48, 48)
                        .addGroup(t15AdTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteB15)
                            .addComponent(deleteI15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addComponent(showB15)
                        .addGap(48, 48, 48)
                        .addComponent(hideB15)
                        .addGap(48, 48, 48)
                        .addGroup(t15AdTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(findB15)
                            .addComponent(findI15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(990, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab21", t15AdTimeT);

        t16StuGrades.setBackground(new java.awt.Color(255, 255, 255));

        headingL16.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL16.setText("STUDENT GRADES");

        prnL16.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL16.setText("PRN");

        midsemL16.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        midsemL16.setText("Mid Sem Percentage");

        endsemL16.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        endsemL16.setText("End Sem Percentage");

        prnI16.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        midsemI16.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        endsemI16.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t16StuGradesLayout = new javax.swing.GroupLayout(t16StuGrades);
        t16StuGrades.setLayout(t16StuGradesLayout);
        t16StuGradesLayout.setHorizontalGroup(
            t16StuGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t16StuGradesLayout.createSequentialGroup()
                .addGroup(t16StuGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t16StuGradesLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL16))
                    .addGroup(t16StuGradesLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t16StuGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(prnL16, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(midsemL16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(endsemL16, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(210, 210, 210)
                        .addGroup(t16StuGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t16StuGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(prnI16)
                                .addComponent(endsemI16, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(midsemI16, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(2370, Short.MAX_VALUE))
        );
        t16StuGradesLayout.setVerticalGroup(
            t16StuGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t16StuGradesLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL16)
                .addGap(125, 125, 125)
                .addGroup(t16StuGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(prnL16)
                    .addComponent(prnI16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(95, 95, 95)
                .addGroup(t16StuGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(midsemL16)
                    .addComponent(midsemI16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(95, 95, 95)
                .addGroup(t16StuGradesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(endsemL16)
                    .addComponent(endsemI16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(1152, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab22", t16StuGrades);

        t17StuAttendance.setBackground(new java.awt.Color(255, 255, 255));

        headingL17.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL17.setText("STUDENT ATTENDANCE");

        prnL17.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL17.setText("PRN");

        percentageL17.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        percentageL17.setText("Percentage");

        dateL17.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        dateL17.setText("Till Date");

        prnI17.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        percentageI17.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        dateI17.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t17StuAttendanceLayout = new javax.swing.GroupLayout(t17StuAttendance);
        t17StuAttendance.setLayout(t17StuAttendanceLayout);
        t17StuAttendanceLayout.setHorizontalGroup(
            t17StuAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t17StuAttendanceLayout.createSequentialGroup()
                .addGroup(t17StuAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t17StuAttendanceLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t17StuAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dateL17, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(prnL17, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(percentageL17, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(210, 210, 210)
                        .addGroup(t17StuAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(percentageI17, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(prnI17, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dateI17, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t17StuAttendanceLayout.createSequentialGroup()
                        .addGap(444, 444, 444)
                        .addComponent(headingL17)))
                .addContainerGap(2439, Short.MAX_VALUE))
        );
        t17StuAttendanceLayout.setVerticalGroup(
            t17StuAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t17StuAttendanceLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL17)
                .addGap(125, 125, 125)
                .addGroup(t17StuAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(t17StuAttendanceLayout.createSequentialGroup()
                        .addComponent(prnI17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(95, 95, 95)
                        .addComponent(percentageI17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(95, 95, 95)
                        .addComponent(dateI17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t17StuAttendanceLayout.createSequentialGroup()
                        .addComponent(prnL17)
                        .addGap(95, 95, 95)
                        .addComponent(percentageL17)
                        .addGap(95, 95, 95)
                        .addComponent(dateL17)))
                .addContainerGap(1154, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab23", t17StuAttendance);

        t18StuLibrary.setBackground(new java.awt.Color(255, 255, 255));

        headingL18.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL18.setText("STUDENT LIBRARY");

        libraryidL18.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        libraryidL18.setText("Library ID");

        libraryidI18.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jTable18.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable18.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Category", "Issue Date", "Return Date"
            }
        ));
        jTable18.setRowHeight(30);
        jScrollPane18.setViewportView(jTable18);

        javax.swing.GroupLayout t18StuLibraryLayout = new javax.swing.GroupLayout(t18StuLibrary);
        t18StuLibrary.setLayout(t18StuLibraryLayout);
        t18StuLibraryLayout.setHorizontalGroup(
            t18StuLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t18StuLibraryLayout.createSequentialGroup()
                .addGroup(t18StuLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t18StuLibraryLayout.createSequentialGroup()
                        .addGap(469, 469, 469)
                        .addComponent(headingL18))
                    .addGroup(t18StuLibraryLayout.createSequentialGroup()
                        .addGap(182, 182, 182)
                        .addComponent(libraryidL18, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(libraryidI18, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(136, 136, 136)
                        .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2271, Short.MAX_VALUE))
        );
        t18StuLibraryLayout.setVerticalGroup(
            t18StuLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t18StuLibraryLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL18)
                .addGroup(t18StuLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t18StuLibraryLayout.createSequentialGroup()
                        .addGap(125, 125, 125)
                        .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t18StuLibraryLayout.createSequentialGroup()
                        .addGap(292, 292, 292)
                        .addGroup(t18StuLibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(libraryidL18)
                            .addComponent(libraryidI18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(995, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab24", t18StuLibrary);

        t19StuFees.setBackground(new java.awt.Color(255, 255, 255));

        headingL19.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL19.setText("STUDENT FEES");

        prnL19.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL19.setText("PRN");

        branchL19.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchL19.setText("Branch");

        paidunpaidL19.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        paidunpaidL19.setText("Paid/Unpaid");

        FineL19.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        FineL19.setText("Fine");

        prnI19.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        prnI19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prnI19ActionPerformed(evt);
            }
        });

        branchI19.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        branchI19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                branchI19ActionPerformed(evt);
            }
        });

        paidunpaidI19.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        fineI19.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        fineI19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fineI19ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t19StuFeesLayout = new javax.swing.GroupLayout(t19StuFees);
        t19StuFees.setLayout(t19StuFeesLayout);
        t19StuFeesLayout.setHorizontalGroup(
            t19StuFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t19StuFeesLayout.createSequentialGroup()
                .addGroup(t19StuFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t19StuFeesLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t19StuFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(prnL19, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(paidunpaidL19)
                            .addComponent(FineL19, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(branchL19))
                        .addGap(210, 210, 210)
                        .addGroup(t19StuFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(branchI19, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(prnI19, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(paidunpaidI19, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fineI19, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t19StuFeesLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL19, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2437, Short.MAX_VALUE))
        );
        t19StuFeesLayout.setVerticalGroup(
            t19StuFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t19StuFeesLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL19)
                .addGap(125, 125, 125)
                .addGroup(t19StuFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(prnL19)
                    .addComponent(prnI19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addGroup(t19StuFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(branchL19, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(branchI19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addGroup(t19StuFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(paidunpaidI19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(paidunpaidL19))
                .addGap(72, 72, 72)
                .addGroup(t19StuFeesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FineL19)
                    .addComponent(fineI19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(1100, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab25", t19StuFees);

        t20StuCourse.setBackground(new java.awt.Color(255, 255, 255));

        headingL20.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL20.setText("STUDENT COURSE");

        jTable20.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable20.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Course ID", "Course Name", "Duration"
            }
        ));
        jTable20.setRowHeight(30);
        jScrollPane20.setViewportView(jTable20);

        branchL20.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchL20.setText("Branch");

        branchI20.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        branchI20.setPreferredSize(null);

        javax.swing.GroupLayout t20StuCourseLayout = new javax.swing.GroupLayout(t20StuCourse);
        t20StuCourse.setLayout(t20StuCourseLayout);
        t20StuCourseLayout.setHorizontalGroup(
            t20StuCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t20StuCourseLayout.createSequentialGroup()
                .addGroup(t20StuCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t20StuCourseLayout.createSequentialGroup()
                        .addGap(182, 182, 182)
                        .addComponent(branchL20, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(branchI20, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(136, 136, 136)
                        .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t20StuCourseLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL20)))
                .addContainerGap(2277, Short.MAX_VALUE))
        );
        t20StuCourseLayout.setVerticalGroup(
            t20StuCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t20StuCourseLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL20)
                .addGroup(t20StuCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t20StuCourseLayout.createSequentialGroup()
                        .addGap(125, 125, 125)
                        .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t20StuCourseLayout.createSequentialGroup()
                        .addGap(292, 292, 292)
                        .addGroup(t20StuCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(branchL20)
                            .addComponent(branchI20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(995, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab26", t20StuCourse);

        t21StuHostel.setBackground(new java.awt.Color(255, 255, 255));

        headingL21.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL21.setText("STUDENT HOSTEL");

        prnL21.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL21.setText("PRN");

        genderL21.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        genderL21.setText("Gender");

        roomtypeL21.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        roomtypeL21.setText("Room Type");

        prnI21.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        genderI21.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        roomtypeI21.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t21StuHostelLayout = new javax.swing.GroupLayout(t21StuHostel);
        t21StuHostel.setLayout(t21StuHostelLayout);
        t21StuHostelLayout.setHorizontalGroup(
            t21StuHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t21StuHostelLayout.createSequentialGroup()
                .addGroup(t21StuHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t21StuHostelLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t21StuHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(genderL21, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(prnL21, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(roomtypeL21, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(210, 210, 210)
                        .addGroup(t21StuHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(genderI21, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(prnI21, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(roomtypeI21, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t21StuHostelLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL21)))
                .addContainerGap(2440, Short.MAX_VALUE))
        );
        t21StuHostelLayout.setVerticalGroup(
            t21StuHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t21StuHostelLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL21)
                .addGap(125, 125, 125)
                .addGroup(t21StuHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(t21StuHostelLayout.createSequentialGroup()
                        .addGroup(t21StuHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(prnL21)
                            .addComponent(prnI21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(113, 113, 113))
                    .addGroup(t21StuHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(genderI21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(genderL21)))
                .addGap(95, 95, 95)
                .addGroup(t21StuHostelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(roomtypeL21)
                    .addComponent(roomtypeI21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(1160, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab27", t21StuHostel);

        t22StuTimeT.setBackground(new java.awt.Color(255, 255, 255));

        headingL22.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL22.setText("STUDENT TIME TABLE");

        branchL22.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchL22.setText("Branch");

        branchI22.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jTable22.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable22.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Course ID", "Course Name", "Faculty ID", "Faculty Name", "Room Number", "Timing"
            }
        ));
        jTable22.setRowHeight(30);
        jScrollPane22.setViewportView(jTable22);

        javax.swing.GroupLayout t22StuTimeTLayout = new javax.swing.GroupLayout(t22StuTimeT);
        t22StuTimeT.setLayout(t22StuTimeTLayout);
        t22StuTimeTLayout.setHorizontalGroup(
            t22StuTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t22StuTimeTLayout.createSequentialGroup()
                .addGap(501, 501, 501)
                .addComponent(branchL22, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(84, 84, 84)
                .addComponent(branchI22, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(t22StuTimeTLayout.createSequentialGroup()
                .addGroup(t22StuTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t22StuTimeTLayout.createSequentialGroup()
                        .addGap(466, 466, 466)
                        .addComponent(headingL22))
                    .addGroup(t22StuTimeTLayout.createSequentialGroup()
                        .addGap(223, 223, 223)
                        .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 839, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2298, Short.MAX_VALUE))
        );
        t22StuTimeTLayout.setVerticalGroup(
            t22StuTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t22StuTimeTLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL22)
                .addGap(125, 125, 125)
                .addGroup(t22StuTimeTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(branchI22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(branchL22))
                .addGap(121, 121, 121)
                .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(933, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab28", t22StuTimeT);

        t12_1Add.setBackground(new java.awt.Color(255, 255, 255));

        headingL12_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL12_1.setText("Add");

        prnL12_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL12_1.setText("PRN");

        paidunpaidL12_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        paidunpaidL12_1.setText("Paid / Unpaid ");

        fineL12_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        fineL12_1.setText("Fine");

        prnI12_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        paidunpaidI12_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        fineI12_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB12_1.setBackground(new java.awt.Color(0, 0, 0));
        submitB12_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB12_1.setForeground(new java.awt.Color(255, 255, 255));
        submitB12_1.setText("Submit");
        submitB12_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB12_1ActionPerformed(evt);
            }
        });

        resetB12_1.setBackground(new java.awt.Color(0, 0, 0));
        resetB12_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB12_1.setForeground(new java.awt.Color(255, 255, 255));
        resetB12_1.setText("Reset");
        resetB12_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB12_1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t12_1AddLayout = new javax.swing.GroupLayout(t12_1Add);
        t12_1Add.setLayout(t12_1AddLayout);
        t12_1AddLayout.setHorizontalGroup(
            t12_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t12_1AddLayout.createSequentialGroup()
                .addGroup(t12_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t12_1AddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t12_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t12_1AddLayout.createSequentialGroup()
                                .addGroup(t12_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(prnL12_1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(fineL12_1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(paidunpaidL12_1))
                                .addGap(210, 210, 210)
                                .addGroup(t12_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(fineI12_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(paidunpaidI12_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(prnI12_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(t12_1AddLayout.createSequentialGroup()
                                .addGap(70, 70, 70)
                                .addComponent(submitB12_1)
                                .addGap(240, 240, 240)
                                .addComponent(resetB12_1))))
                    .addGroup(t12_1AddLayout.createSequentialGroup()
                        .addGap(600, 600, 600)
                        .addComponent(headingL12_1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2422, Short.MAX_VALUE))
        );
        t12_1AddLayout.setVerticalGroup(
            t12_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t12_1AddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL12_1)
                .addGap(125, 125, 125)
                .addGroup(t12_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(t12_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(resetB12_1)
                        .addComponent(submitB12_1))
                    .addGroup(t12_1AddLayout.createSequentialGroup()
                        .addGroup(t12_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(prnL12_1)
                            .addComponent(prnI12_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(95, 95, 95)
                        .addGroup(t12_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(paidunpaidL12_1)
                            .addComponent(paidunpaidI12_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(95, 95, 95)
                        .addGroup(t12_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(fineL12_1)
                            .addComponent(fineI12_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(125, 125, 125)))
                .addContainerGap(1026, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab29", t12_1Add);

        t12_2Update.setBackground(new java.awt.Color(255, 255, 255));

        headingL12_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL12_2.setText("Update");

        prnL12_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL12_2.setText("PRN");

        paidunpaidL12_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        paidunpaidL12_2.setText("Paid / Unpaid ");

        fineL12_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        fineL12_2.setText("Fine");

        prnI12_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        paidunpaidI12_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        fineI12_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB12_2.setBackground(new java.awt.Color(0, 0, 0));
        submitB12_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB12_2.setForeground(new java.awt.Color(255, 255, 255));
        submitB12_2.setText("Submit");
        submitB12_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB12_2ActionPerformed(evt);
            }
        });

        resetB12_2.setBackground(new java.awt.Color(0, 0, 0));
        resetB12_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB12_2.setForeground(new java.awt.Color(255, 255, 255));
        resetB12_2.setText("Reset");
        resetB12_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB12_2ActionPerformed(evt);
            }
        });

        jTable12_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable12_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "PRN", "Paid/Unpaid", "Fine"
            }
        ));
        jTable12_2.setRowHeight(30);
        jTable12_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable12_2MouseClicked(evt);
            }
        });
        jScrollPane12_2.setViewportView(jTable12_2);

        showB12_2.setBackground(new java.awt.Color(0, 0, 0));
        showB12_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB12_2.setForeground(new java.awt.Color(255, 255, 255));
        showB12_2.setText("Show");
        showB12_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB12_2ActionPerformed(evt);
            }
        });

        hideB12_2.setBackground(new java.awt.Color(0, 0, 0));
        hideB12_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB12_2.setForeground(new java.awt.Color(255, 255, 255));
        hideB12_2.setText("Hide");
        hideB12_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB12_2ActionPerformed(evt);
            }
        });

        findB12_2.setBackground(new java.awt.Color(0, 0, 0));
        findB12_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB12_2.setForeground(new java.awt.Color(255, 255, 255));
        findB12_2.setText("Find");
        findB12_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB12_2ActionPerformed(evt);
            }
        });

        findI12_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t12_2UpdateLayout = new javax.swing.GroupLayout(t12_2Update);
        t12_2Update.setLayout(t12_2UpdateLayout);
        t12_2UpdateLayout.setHorizontalGroup(
            t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t12_2UpdateLayout.createSequentialGroup()
                .addGroup(t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t12_2UpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingL12_2, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t12_2UpdateLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t12_2UpdateLayout.createSequentialGroup()
                                .addComponent(submitB12_2)
                                .addGap(29, 29, 29)
                                .addComponent(resetB12_2)
                                .addGap(27, 27, 27)
                                .addComponent(showB12_2)
                                .addGap(18, 18, 18)
                                .addComponent(hideB12_2))
                            .addGroup(t12_2UpdateLayout.createSequentialGroup()
                                .addGroup(t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(prnL12_2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(paidunpaidL12_2)
                                    .addComponent(fineL12_2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(55, 55, 55)
                                .addGroup(t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(prnI12_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(paidunpaidI12_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(fineI12_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(160, 160, 160)
                                .addGroup(t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(t12_2UpdateLayout.createSequentialGroup()
                                        .addComponent(findB12_2)
                                        .addGap(18, 18, 18)
                                        .addComponent(findI12_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jScrollPane12_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(2205, Short.MAX_VALUE))
        );
        t12_2UpdateLayout.setVerticalGroup(
            t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t12_2UpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL12_2)
                .addGap(125, 125, 125)
                .addGroup(t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t12_2UpdateLayout.createSequentialGroup()
                        .addGroup(t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(prnL12_2)
                            .addComponent(prnI12_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(100, 100, 100)
                        .addGroup(t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(paidunpaidL12_2)
                            .addComponent(paidunpaidI12_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(100, 100, 100)
                        .addGroup(t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(fineL12_2)
                            .addComponent(fineI12_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane12_2, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(t12_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(hideB12_2)
                    .addComponent(showB12_2)
                    .addComponent(resetB12_2)
                    .addComponent(submitB12_2)
                    .addComponent(findB12_2)
                    .addComponent(findI12_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(984, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab30", t12_2Update);

        t13_1Add.setBackground(new java.awt.Color(255, 255, 255));

        headingL13_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL13_1.setText("Add");

        courseidL13_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        courseidL13_1.setText("Course ID");

        coursenameL13_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        coursenameL13_1.setText("Cours Name");

        durationL13_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        durationL13_1.setText("Duration");

        branchidL13_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchidL13_1.setText("Brand ID");

        courseidI13_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        coursenameI13_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        durationI13_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        branchidI13_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB13_1.setBackground(new java.awt.Color(0, 0, 0));
        submitB13_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB13_1.setForeground(new java.awt.Color(255, 255, 255));
        submitB13_1.setText("Submit");
        submitB13_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB13_1ActionPerformed(evt);
            }
        });

        resetB13_1.setBackground(new java.awt.Color(0, 0, 0));
        resetB13_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB13_1.setForeground(new java.awt.Color(255, 255, 255));
        resetB13_1.setText("Reset");
        resetB13_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB13_1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t13_1AddLayout = new javax.swing.GroupLayout(t13_1Add);
        t13_1Add.setLayout(t13_1AddLayout);
        t13_1AddLayout.setHorizontalGroup(
            t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t13_1AddLayout.createSequentialGroup()
                .addGroup(t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t13_1AddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t13_1AddLayout.createSequentialGroup()
                                .addGroup(t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(durationL13_1)
                                    .addComponent(coursenameL13_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(branchidL13_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(courseidL13_1, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(210, 210, 210)
                                .addGroup(t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(branchidI13_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(durationI13_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(coursenameI13_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(courseidI13_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(t13_1AddLayout.createSequentialGroup()
                                .addGap(58, 58, 58)
                                .addComponent(submitB13_1)
                                .addGap(240, 240, 240)
                                .addComponent(resetB13_1))))
                    .addGroup(t13_1AddLayout.createSequentialGroup()
                        .addGap(600, 600, 600)
                        .addComponent(headingL13_1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2440, Short.MAX_VALUE))
        );
        t13_1AddLayout.setVerticalGroup(
            t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t13_1AddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL13_1)
                .addGap(125, 125, 125)
                .addGroup(t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(resetB13_1)
                        .addComponent(submitB13_1))
                    .addGroup(t13_1AddLayout.createSequentialGroup()
                        .addGroup(t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(courseidL13_1)
                            .addComponent(courseidI13_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(78, 78, 78)
                        .addGroup(t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(coursenameL13_1)
                            .addComponent(coursenameI13_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(78, 78, 78)
                        .addGroup(t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(durationL13_1)
                            .addComponent(durationI13_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(78, 78, 78)
                        .addGroup(t13_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(branchidL13_1)
                            .addComponent(branchidI13_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(125, 125, 125)))
                .addContainerGap(955, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab31", t13_1Add);

        t13_2Update.setBackground(new java.awt.Color(255, 255, 255));

        headingL13_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL13_2.setText("Update");

        courseidL13_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        courseidL13_2.setText("Course ID");

        coursenameL13_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        coursenameL13_2.setText("Cours Name");

        durationL13_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        durationL13_2.setText("Duration");

        branchidL13_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchidL13_2.setText("Brand ID");

        courseidI13_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        coursenameI13_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        durationI13_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        branchidI13_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB13_2.setBackground(new java.awt.Color(0, 0, 0));
        submitB13_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB13_2.setForeground(new java.awt.Color(255, 255, 255));
        submitB13_2.setText("Submit");
        submitB13_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB13_2ActionPerformed(evt);
            }
        });

        resetB13_2.setBackground(new java.awt.Color(0, 0, 0));
        resetB13_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB13_2.setForeground(new java.awt.Color(255, 255, 255));
        resetB13_2.setText("Reset");
        resetB13_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB13_2ActionPerformed(evt);
            }
        });

        showB13_2.setBackground(new java.awt.Color(0, 0, 0));
        showB13_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB13_2.setForeground(new java.awt.Color(255, 255, 255));
        showB13_2.setText("Show");
        showB13_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB13_2ActionPerformed(evt);
            }
        });

        hideB13_2.setBackground(new java.awt.Color(0, 0, 0));
        hideB13_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB13_2.setForeground(new java.awt.Color(255, 255, 255));
        hideB13_2.setText("Hide");
        hideB13_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB13_2ActionPerformed(evt);
            }
        });

        jTable13_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Course ID", "Course Name", "Duration", "Branch ID"
            }
        ));
        jTable13_2.setGridColor(new java.awt.Color(0, 0, 0));
        jTable13_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable13_2MouseClicked(evt);
            }
        });
        jScrollPane13_2.setViewportView(jTable13_2);

        findB13_2.setBackground(new java.awt.Color(0, 0, 0));
        findB13_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB13_2.setForeground(new java.awt.Color(255, 255, 255));
        findB13_2.setText("Find");
        findB13_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB13_2ActionPerformed(evt);
            }
        });

        findI13_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t13_2UpdateLayout = new javax.swing.GroupLayout(t13_2Update);
        t13_2Update.setLayout(t13_2UpdateLayout);
        t13_2UpdateLayout.setHorizontalGroup(
            t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t13_2UpdateLayout.createSequentialGroup()
                .addGap(580, 580, 580)
                .addComponent(headingL13_2, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(t13_2UpdateLayout.createSequentialGroup()
                .addGap(160, 160, 160)
                .addGroup(t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(t13_2UpdateLayout.createSequentialGroup()
                        .addComponent(submitB13_2)
                        .addGap(30, 30, 30)
                        .addComponent(resetB13_2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(showB13_2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(hideB13_2))
                    .addGroup(t13_2UpdateLayout.createSequentialGroup()
                        .addGroup(t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(durationL13_2)
                            .addComponent(coursenameL13_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(branchidL13_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(courseidL13_2))
                        .addGap(55, 55, 55)
                        .addGroup(t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(branchidI13_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(durationI13_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(coursenameI13_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(courseidI13_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(160, 160, 160)
                .addGroup(t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t13_2UpdateLayout.createSequentialGroup()
                        .addComponent(findB13_2)
                        .addGap(18, 18, 18)
                        .addComponent(findI13_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane13_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 2223, Short.MAX_VALUE))
        );
        t13_2UpdateLayout.setVerticalGroup(
            t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t13_2UpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL13_2)
                .addGap(125, 125, 125)
                .addGroup(t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t13_2UpdateLayout.createSequentialGroup()
                        .addGroup(t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(courseidL13_2)
                            .addComponent(courseidI13_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(coursenameL13_2)
                            .addComponent(coursenameI13_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(durationL13_2)
                            .addComponent(durationI13_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(branchidL13_2)
                            .addComponent(branchidI13_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane13_2, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(t13_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB13_2)
                    .addComponent(resetB13_2)
                    .addComponent(hideB13_2)
                    .addComponent(showB13_2)
                    .addComponent(findB13_2)
                    .addComponent(findI13_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(992, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab32", t13_2Update);

        t8_1Add.setBackground(new java.awt.Color(255, 255, 255));

        headingL8_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL8_1.setText("Add");

        prnL8_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL8_1.setText("PRN");

        midsemL8_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        midsemL8_1.setText("Mid Sem");

        endsemL8_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        endsemL8_1.setText("End Sem");

        prnI8_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        midsemI8_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        endsemI8_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB8_1.setBackground(new java.awt.Color(0, 0, 0));
        submitB8_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB8_1.setForeground(new java.awt.Color(255, 255, 255));
        submitB8_1.setText("Submit");
        submitB8_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB8_1ActionPerformed(evt);
            }
        });

        resetB8_1.setBackground(new java.awt.Color(0, 0, 0));
        resetB8_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB8_1.setForeground(new java.awt.Color(255, 255, 255));
        resetB8_1.setText("Reset");
        resetB8_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB8_1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t8_1AddLayout = new javax.swing.GroupLayout(t8_1Add);
        t8_1Add.setLayout(t8_1AddLayout);
        t8_1AddLayout.setHorizontalGroup(
            t8_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t8_1AddLayout.createSequentialGroup()
                .addGroup(t8_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t8_1AddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t8_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t8_1AddLayout.createSequentialGroup()
                                .addGroup(t8_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(endsemL8_1)
                                    .addComponent(prnL8_1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(midsemL8_1))
                                .addGap(210, 210, 210)
                                .addGroup(t8_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(endsemI8_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(midsemI8_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(prnI8_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(t8_1AddLayout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(submitB8_1)
                                .addGap(240, 240, 240)
                                .addComponent(resetB8_1))))
                    .addGroup(t8_1AddLayout.createSequentialGroup()
                        .addGap(600, 600, 600)
                        .addComponent(headingL8_1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2467, Short.MAX_VALUE))
        );
        t8_1AddLayout.setVerticalGroup(
            t8_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t8_1AddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL8_1)
                .addGap(125, 125, 125)
                .addGroup(t8_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(prnL8_1)
                    .addComponent(prnI8_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(95, 95, 95)
                .addGroup(t8_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(midsemL8_1)
                    .addComponent(midsemI8_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(95, 95, 95)
                .addGroup(t8_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(endsemL8_1)
                    .addComponent(endsemI8_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t8_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resetB8_1)
                    .addComponent(submitB8_1))
                .addContainerGap(994, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab33", t8_1Add);

        t8_2Update.setBackground(new java.awt.Color(255, 255, 255));

        headingL8_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL8_2.setText("Update");

        prnL8_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL8_2.setText("PRN");

        midsemL8_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        midsemL8_2.setText("Mid Sem");

        endsemL8_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        endsemL8_2.setText("End Sem");

        prnI8_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        midsemI8_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        endsemI8_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB8_2.setBackground(new java.awt.Color(0, 0, 0));
        submitB8_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB8_2.setForeground(new java.awt.Color(255, 255, 255));
        submitB8_2.setText("Submit");
        submitB8_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB8_2ActionPerformed(evt);
            }
        });

        resetB8_2.setBackground(new java.awt.Color(0, 0, 0));
        resetB8_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB8_2.setForeground(new java.awt.Color(255, 255, 255));
        resetB8_2.setText("Reset");
        resetB8_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB8_2ActionPerformed(evt);
            }
        });

        showB8_2.setBackground(new java.awt.Color(0, 0, 0));
        showB8_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB8_2.setForeground(new java.awt.Color(255, 255, 255));
        showB8_2.setText("Show");
        showB8_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB8_2ActionPerformed(evt);
            }
        });

        hideB8_2.setBackground(new java.awt.Color(0, 0, 0));
        hideB8_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB8_2.setForeground(new java.awt.Color(255, 255, 255));
        hideB8_2.setText("Hide");
        hideB8_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB8_2ActionPerformed(evt);
            }
        });

        jTable8_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable8_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "PRN", "Mid Sem Marks", "End Sem Marks"
            }
        ));
        jTable8_2.setRowHeight(30);
        jTable8_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable8_2MouseClicked(evt);
            }
        });
        jScrollPane8_2.setViewportView(jTable8_2);

        findB8_2.setBackground(new java.awt.Color(0, 0, 0));
        findB8_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB8_2.setForeground(new java.awt.Color(255, 255, 255));
        findB8_2.setText("Find");
        findB8_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB8_2ActionPerformed(evt);
            }
        });

        findI8_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        findI8_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findI8_2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t8_2UpdateLayout = new javax.swing.GroupLayout(t8_2Update);
        t8_2Update.setLayout(t8_2UpdateLayout);
        t8_2UpdateLayout.setHorizontalGroup(
            t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t8_2UpdateLayout.createSequentialGroup()
                .addGroup(t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t8_2UpdateLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(t8_2UpdateLayout.createSequentialGroup()
                                .addGroup(t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(prnL8_2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(midsemL8_2, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(t8_2UpdateLayout.createSequentialGroup()
                                        .addGap(3, 3, 3)
                                        .addComponent(endsemL8_2)))
                                .addGap(55, 55, 55)
                                .addGroup(t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(endsemI8_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(midsemI8_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(prnI8_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(t8_2UpdateLayout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(submitB8_2)
                                .addGap(16, 16, 16)
                                .addComponent(resetB8_2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(showB8_2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(hideB8_2)))
                        .addGap(160, 160, 160)
                        .addGroup(t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane8_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(t8_2UpdateLayout.createSequentialGroup()
                                .addComponent(findB8_2)
                                .addGap(18, 18, 18)
                                .addComponent(findI8_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(t8_2UpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingL8_2, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2242, Short.MAX_VALUE))
        );
        t8_2UpdateLayout.setVerticalGroup(
            t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t8_2UpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL8_2)
                .addGap(125, 125, 125)
                .addGroup(t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t8_2UpdateLayout.createSequentialGroup()
                        .addGroup(t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(prnL8_2)
                            .addComponent(prnI8_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(100, 100, 100)
                        .addGroup(t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(midsemL8_2)
                            .addComponent(midsemI8_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(100, 100, 100)
                        .addGroup(t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(endsemL8_2)
                            .addComponent(endsemI8_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane8_2, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(t8_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB8_2)
                    .addComponent(resetB8_2)
                    .addComponent(hideB8_2)
                    .addComponent(showB8_2)
                    .addComponent(findB8_2)
                    .addComponent(findI8_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(984, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab34", t8_2Update);

        t9_1Add.setBackground(new java.awt.Color(255, 255, 255));

        headingL9_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL9_1.setText("Add");

        facultyidL9_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        facultyidL9_1.setText("Faculty ID");

        facultynameL9_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        facultynameL9_1.setText("Faculty Name");

        branchidL9_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchidL9_1.setText("Branch ID");

        facultyidI9_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        facultynameI9_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        branchidI9_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB9_1.setBackground(new java.awt.Color(0, 0, 0));
        submitB9_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB9_1.setForeground(new java.awt.Color(255, 255, 255));
        submitB9_1.setText("Submit");
        submitB9_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB9_1ActionPerformed(evt);
            }
        });

        resetB9_1.setBackground(new java.awt.Color(0, 0, 0));
        resetB9_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB9_1.setForeground(new java.awt.Color(255, 255, 255));
        resetB9_1.setText("Reset");
        resetB9_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB9_1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t9_1AddLayout = new javax.swing.GroupLayout(t9_1Add);
        t9_1Add.setLayout(t9_1AddLayout);
        t9_1AddLayout.setHorizontalGroup(
            t9_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t9_1AddLayout.createSequentialGroup()
                .addGroup(t9_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t9_1AddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t9_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t9_1AddLayout.createSequentialGroup()
                                .addGroup(t9_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(branchidL9_1)
                                    .addComponent(facultynameL9_1)
                                    .addComponent(facultyidL9_1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(210, 210, 210)
                                .addGroup(t9_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(branchidI9_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(facultynameI9_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(facultyidI9_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(t9_1AddLayout.createSequentialGroup()
                                .addGap(63, 63, 63)
                                .addComponent(submitB9_1)
                                .addGap(240, 240, 240)
                                .addComponent(resetB9_1))))
                    .addGroup(t9_1AddLayout.createSequentialGroup()
                        .addGap(600, 600, 600)
                        .addComponent(headingL9_1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2429, Short.MAX_VALUE))
        );
        t9_1AddLayout.setVerticalGroup(
            t9_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t9_1AddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL9_1)
                .addGap(125, 125, 125)
                .addGroup(t9_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(facultyidL9_1)
                    .addComponent(facultyidI9_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(95, 95, 95)
                .addGroup(t9_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(facultynameL9_1)
                    .addComponent(facultynameI9_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(95, 95, 95)
                .addGroup(t9_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(branchidL9_1)
                    .addComponent(branchidI9_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t9_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resetB9_1)
                    .addComponent(submitB9_1))
                .addContainerGap(994, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab35", t9_1Add);

        t9_2Update.setBackground(new java.awt.Color(255, 255, 255));

        headingL9_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL9_2.setText("Update");

        facultyidL9_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        facultyidL9_2.setText("Faculty ID");

        facultynameL9_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        facultynameL9_2.setText("Faculty Name");

        branchidL9_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchidL9_2.setText("Branch ID");

        facultyidI9_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        facultynameI9_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        branchidI9_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB9_2.setBackground(new java.awt.Color(0, 0, 0));
        submitB9_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB9_2.setForeground(new java.awt.Color(255, 255, 255));
        submitB9_2.setText("Submit");
        submitB9_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB9_2ActionPerformed(evt);
            }
        });

        resetB9_2.setBackground(new java.awt.Color(0, 0, 0));
        resetB9_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB9_2.setForeground(new java.awt.Color(255, 255, 255));
        resetB9_2.setText("Reset");
        resetB9_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB9_2ActionPerformed(evt);
            }
        });

        jTable9_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable9_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Faculty ID", "Faculty Name", "Branch ID"
            }
        ));
        jTable9_2.setRowHeight(30);
        jTable9_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable9_2MouseClicked(evt);
            }
        });
        jScrollPane9_2.setViewportView(jTable9_2);

        showB9_2.setBackground(new java.awt.Color(0, 0, 0));
        showB9_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB9_2.setForeground(new java.awt.Color(255, 255, 255));
        showB9_2.setText("Show");
        showB9_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB9_2ActionPerformed(evt);
            }
        });

        hideB9_2.setBackground(new java.awt.Color(0, 0, 0));
        hideB9_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB9_2.setForeground(new java.awt.Color(255, 255, 255));
        hideB9_2.setText("Hide");
        hideB9_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB9_2ActionPerformed(evt);
            }
        });

        findB9_2.setBackground(new java.awt.Color(0, 0, 0));
        findB9_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB9_2.setForeground(new java.awt.Color(255, 255, 255));
        findB9_2.setText("Find");
        findB9_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB9_2ActionPerformed(evt);
            }
        });

        findI9_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t9_2UpdateLayout = new javax.swing.GroupLayout(t9_2Update);
        t9_2Update.setLayout(t9_2UpdateLayout);
        t9_2UpdateLayout.setHorizontalGroup(
            t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t9_2UpdateLayout.createSequentialGroup()
                .addGroup(t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t9_2UpdateLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t9_2UpdateLayout.createSequentialGroup()
                                .addGroup(t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(branchidL9_2)
                                    .addComponent(facultyidL9_2)
                                    .addComponent(facultynameL9_2))
                                .addGap(55, 55, 55)
                                .addGroup(t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(branchidI9_2, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(facultynameI9_2, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(facultyidI9_2, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(t9_2UpdateLayout.createSequentialGroup()
                                .addComponent(submitB9_2)
                                .addGap(18, 18, 18)
                                .addComponent(resetB9_2)
                                .addGap(26, 26, 26)
                                .addComponent(showB9_2)
                                .addGap(18, 18, 18)
                                .addComponent(hideB9_2)))
                        .addGap(160, 160, 160)
                        .addGroup(t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane9_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(t9_2UpdateLayout.createSequentialGroup()
                                .addComponent(findB9_2)
                                .addGap(26, 26, 26)
                                .addComponent(findI9_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(t9_2UpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingL9_2, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2217, Short.MAX_VALUE))
        );
        t9_2UpdateLayout.setVerticalGroup(
            t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t9_2UpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL9_2)
                .addGap(125, 125, 125)
                .addGroup(t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t9_2UpdateLayout.createSequentialGroup()
                        .addGroup(t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(facultyidL9_2)
                            .addComponent(facultyidI9_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(100, 100, 100)
                        .addGroup(t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(facultynameL9_2)
                            .addComponent(facultynameI9_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(100, 100, 100)
                        .addGroup(t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(branchidL9_2)
                            .addComponent(branchidI9_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane9_2, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(t9_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB9_2)
                    .addComponent(resetB9_2)
                    .addComponent(showB9_2)
                    .addComponent(hideB9_2)
                    .addComponent(findB9_2)
                    .addComponent(findI9_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(984, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab36", t9_2Update);

        t10_1Add.setBackground(new java.awt.Color(255, 255, 255));

        headingL10_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL10_1.setText("Add");

        prnL10_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL10_1.setText("PRN");

        percentageL10_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        percentageL10_1.setText("Percentage");

        dateL10_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        dateL10_1.setText("Till Date");

        prnI10_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        percentageI10_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        dateI10_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB10_1.setBackground(new java.awt.Color(0, 0, 0));
        submitB10_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB10_1.setForeground(new java.awt.Color(255, 255, 255));
        submitB10_1.setText("Submit");
        submitB10_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB10_1ActionPerformed(evt);
            }
        });

        resetB10_1.setBackground(new java.awt.Color(0, 0, 0));
        resetB10_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB10_1.setForeground(new java.awt.Color(255, 255, 255));
        resetB10_1.setText("Reset");
        resetB10_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB10_1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t10_1AddLayout = new javax.swing.GroupLayout(t10_1Add);
        t10_1Add.setLayout(t10_1AddLayout);
        t10_1AddLayout.setHorizontalGroup(
            t10_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t10_1AddLayout.createSequentialGroup()
                .addGroup(t10_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t10_1AddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t10_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dateL10_1)
                            .addComponent(prnL10_1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(percentageL10_1))
                        .addGap(210, 210, 210)
                        .addGroup(t10_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dateI10_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(percentageI10_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(prnI10_1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t10_1AddLayout.createSequentialGroup()
                        .addGap(467, 467, 467)
                        .addComponent(submitB10_1)
                        .addGap(240, 240, 240)
                        .addComponent(resetB10_1))
                    .addGroup(t10_1AddLayout.createSequentialGroup()
                        .addGap(600, 600, 600)
                        .addComponent(headingL10_1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2448, Short.MAX_VALUE))
        );
        t10_1AddLayout.setVerticalGroup(
            t10_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t10_1AddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL10_1)
                .addGap(125, 125, 125)
                .addGroup(t10_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(prnL10_1)
                    .addComponent(prnI10_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(95, 95, 95)
                .addGroup(t10_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(percentageL10_1)
                    .addComponent(percentageI10_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(95, 95, 95)
                .addGroup(t10_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateL10_1)
                    .addComponent(dateI10_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t10_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resetB10_1)
                    .addComponent(submitB10_1))
                .addContainerGap(994, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab37", t10_1Add);

        t10_2Update.setBackground(new java.awt.Color(255, 255, 255));

        headingL10_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL10_2.setText("Update");

        prnL10_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL10_2.setText("PRN");

        percentageL10_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        percentageL10_2.setText("Percentage");

        dateL10_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        dateL10_2.setText("Till Date");

        prnI10_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        percentageI10_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        dateI10_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB10_2.setBackground(new java.awt.Color(0, 0, 0));
        submitB10_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB10_2.setForeground(new java.awt.Color(255, 255, 255));
        submitB10_2.setText("Submit");
        submitB10_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB10_2ActionPerformed(evt);
            }
        });

        resetB10_2.setBackground(new java.awt.Color(0, 0, 0));
        resetB10_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB10_2.setForeground(new java.awt.Color(255, 255, 255));
        resetB10_2.setText("Reset");
        resetB10_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB10_2ActionPerformed(evt);
            }
        });

        showB10_2.setBackground(new java.awt.Color(0, 0, 0));
        showB10_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB10_2.setForeground(new java.awt.Color(255, 255, 255));
        showB10_2.setText("Show");
        showB10_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB10_2ActionPerformed(evt);
            }
        });

        hideB10_2.setBackground(new java.awt.Color(0, 0, 0));
        hideB10_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB10_2.setForeground(new java.awt.Color(255, 255, 255));
        hideB10_2.setText("Hide");
        hideB10_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB10_2ActionPerformed(evt);
            }
        });

        jTable10_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable10_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "PRN", "Percentage", "Date"
            }
        ));
        jTable10_2.setRowHeight(30);
        jTable10_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable10_2MouseClicked(evt);
            }
        });
        jScrollPane10_2.setViewportView(jTable10_2);

        findB10_2.setBackground(new java.awt.Color(0, 0, 0));
        findB10_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB10_2.setForeground(new java.awt.Color(255, 255, 255));
        findB10_2.setText("Find");
        findB10_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB10_2ActionPerformed(evt);
            }
        });

        findI10_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t10_2UpdateLayout = new javax.swing.GroupLayout(t10_2Update);
        t10_2Update.setLayout(t10_2UpdateLayout);
        t10_2UpdateLayout.setHorizontalGroup(
            t10_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t10_2UpdateLayout.createSequentialGroup()
                .addGroup(t10_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t10_2UpdateLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(t10_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t10_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(t10_2UpdateLayout.createSequentialGroup()
                                    .addComponent(dateL10_2)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(dateI10_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(t10_2UpdateLayout.createSequentialGroup()
                                    .addComponent(prnL10_2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(prnI10_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, t10_2UpdateLayout.createSequentialGroup()
                                    .addComponent(percentageL10_2)
                                    .addGap(55, 55, 55)
                                    .addComponent(percentageI10_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(t10_2UpdateLayout.createSequentialGroup()
                                .addComponent(submitB10_2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(resetB10_2)
                                .addGap(24, 24, 24)
                                .addComponent(showB10_2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(hideB10_2)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 146, Short.MAX_VALUE)
                        .addGroup(t10_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t10_2UpdateLayout.createSequentialGroup()
                                .addComponent(findB10_2)
                                .addGap(18, 18, 18)
                                .addComponent(findI10_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane10_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t10_2UpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingL10_2, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2245, Short.MAX_VALUE))
        );
        t10_2UpdateLayout.setVerticalGroup(
            t10_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t10_2UpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL10_2)
                .addGap(125, 125, 125)
                .addGroup(t10_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t10_2UpdateLayout.createSequentialGroup()
                        .addGroup(t10_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(prnI10_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(prnL10_2))
                        .addGap(100, 100, 100)
                        .addGroup(t10_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(percentageL10_2)
                            .addComponent(percentageI10_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(100, 100, 100)
                        .addGroup(t10_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dateL10_2)
                            .addComponent(dateI10_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane10_2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(t10_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB10_2)
                    .addComponent(resetB10_2)
                    .addComponent(showB10_2)
                    .addComponent(hideB10_2)
                    .addComponent(findB10_2)
                    .addComponent(findI10_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(982, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab38", t10_2Update);

        t11_1Add.setBackground(new java.awt.Color(255, 255, 255));

        headingL11_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL11_1.setText("Add");

        libraryidL11_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        libraryidL11_1.setText("Library ID");

        categoryL11_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        categoryL11_1.setText("Category");

        issuedateL11_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        issuedateL11_1.setText("Issue Date");

        libraryidI11_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        categoryI11_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        issuedateI11_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB11_1.setBackground(new java.awt.Color(0, 0, 0));
        submitB11_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB11_1.setForeground(new java.awt.Color(255, 255, 255));
        submitB11_1.setText("Submit");
        submitB11_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB11_1ActionPerformed(evt);
            }
        });

        resetB11_1.setBackground(new java.awt.Color(0, 0, 0));
        resetB11_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB11_1.setForeground(new java.awt.Color(255, 255, 255));
        resetB11_1.setText("Reset");
        resetB11_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB11_1ActionPerformed(evt);
            }
        });

        returndateL11_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        returndateL11_1.setText("Return Date");

        returndateI11_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t11_1AddLayout = new javax.swing.GroupLayout(t11_1Add);
        t11_1Add.setLayout(t11_1AddLayout);
        t11_1AddLayout.setHorizontalGroup(
            t11_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t11_1AddLayout.createSequentialGroup()
                .addGroup(t11_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t11_1AddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t11_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(categoryL11_1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(returndateL11_1)
                            .addGroup(t11_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(libraryidL11_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(issuedateL11_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(210, 210, 210)
                        .addGroup(t11_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(issuedateI11_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(categoryI11_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(libraryidI11_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(returndateI11_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)))
                    .addGroup(t11_1AddLayout.createSequentialGroup()
                        .addGap(476, 476, 476)
                        .addComponent(submitB11_1)
                        .addGap(240, 240, 240)
                        .addComponent(resetB11_1))
                    .addGroup(t11_1AddLayout.createSequentialGroup()
                        .addGap(600, 600, 600)
                        .addComponent(headingL11_1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2442, Short.MAX_VALUE))
        );
        t11_1AddLayout.setVerticalGroup(
            t11_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t11_1AddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL11_1)
                .addGap(125, 125, 125)
                .addGroup(t11_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(libraryidL11_1)
                    .addComponent(libraryidI11_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addGroup(t11_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(categoryL11_1)
                    .addComponent(categoryI11_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addGroup(t11_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(issuedateL11_1)
                    .addComponent(issuedateI11_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addGroup(t11_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t11_1AddLayout.createSequentialGroup()
                        .addComponent(returndateL11_1)
                        .addGap(125, 125, 125)
                        .addGroup(t11_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(submitB11_1)
                            .addComponent(resetB11_1)))
                    .addComponent(returndateI11_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(943, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab39", t11_1Add);

        t11_2Update.setBackground(new java.awt.Color(255, 255, 255));

        headingL11_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL11_2.setText("Update");

        libraryidL11_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        libraryidL11_2.setText("Library ID");

        categoryL11_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        categoryL11_2.setText("Category");

        issuedateL11_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        issuedateL11_2.setText("Issue Date");

        libraryidI11_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        categoryI11_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        issuedateI11_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB11_2.setBackground(new java.awt.Color(0, 0, 0));
        submitB11_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB11_2.setForeground(new java.awt.Color(255, 255, 255));
        submitB11_2.setText("Submit");
        submitB11_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB11_2ActionPerformed(evt);
            }
        });

        resetB11_2.setBackground(new java.awt.Color(0, 0, 0));
        resetB11_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB11_2.setForeground(new java.awt.Color(255, 255, 255));
        resetB11_2.setText("Reset");
        resetB11_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB11_2ActionPerformed(evt);
            }
        });

        returndateL11_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        returndateL11_2.setText("Return Date");

        returndateI11_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        showB11_2.setBackground(new java.awt.Color(0, 0, 0));
        showB11_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB11_2.setForeground(new java.awt.Color(255, 255, 255));
        showB11_2.setText("Show");
        showB11_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB11_2ActionPerformed(evt);
            }
        });

        hideB11_2.setBackground(new java.awt.Color(0, 0, 0));
        hideB11_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB11_2.setForeground(new java.awt.Color(255, 255, 255));
        hideB11_2.setText("Hide");
        hideB11_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB11_2ActionPerformed(evt);
            }
        });

        jTable11_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable11_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Library ID", "Category", "Issue Date", "Return Date"
            }
        ));
        jTable11_2.setRowHeight(30);
        jTable11_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable11_2MouseClicked(evt);
            }
        });
        jScrollPane11_2.setViewportView(jTable11_2);

        findB11_2.setBackground(new java.awt.Color(0, 0, 0));
        findB11_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB11_2.setForeground(new java.awt.Color(255, 255, 255));
        findB11_2.setText("Find");
        findB11_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB11_2ActionPerformed(evt);
            }
        });

        findI11_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t11_2UpdateLayout = new javax.swing.GroupLayout(t11_2Update);
        t11_2Update.setLayout(t11_2UpdateLayout);
        t11_2UpdateLayout.setHorizontalGroup(
            t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t11_2UpdateLayout.createSequentialGroup()
                .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t11_2UpdateLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(libraryidL11_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(issuedateL11_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(categoryL11_2, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(returndateL11_2)
                            .addComponent(submitB11_2))
                        .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(t11_2UpdateLayout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(returndateI11_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(categoryI11_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(libraryidI11_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(issuedateI11_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(t11_2UpdateLayout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(resetB11_2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(showB11_2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(hideB11_2)))
                        .addGap(160, 160, 160)
                        .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane11_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(t11_2UpdateLayout.createSequentialGroup()
                                .addComponent(findB11_2)
                                .addGap(18, 18, 18)
                                .addComponent(findI11_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(t11_2UpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingL11_2, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2225, Short.MAX_VALUE))
        );
        t11_2UpdateLayout.setVerticalGroup(
            t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t11_2UpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL11_2)
                .addGap(125, 125, 125)
                .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t11_2UpdateLayout.createSequentialGroup()
                        .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(libraryidL11_2)
                            .addComponent(libraryidI11_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(categoryL11_2)
                            .addComponent(categoryI11_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(issuedateL11_2)
                            .addComponent(issuedateI11_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(returndateL11_2)
                            .addComponent(returndateI11_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane11_2, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(t11_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB11_2)
                    .addComponent(resetB11_2)
                    .addComponent(showB11_2)
                    .addComponent(hideB11_2)
                    .addComponent(findB11_2)
                    .addComponent(findI11_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(992, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab40", t11_2Update);

        t14_1Add.setBackground(new java.awt.Color(255, 255, 255));

        headingL14_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL14_1.setText("Add");

        prnL14_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL14_1.setText("PRN");

        genderL14_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        genderL14_1.setText("Gender");

        simpleroomL14_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        simpleroomL14_1.setText("Simple Room");

        prnI14_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        genderI14_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        simpleroomI14_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB14_1.setBackground(new java.awt.Color(0, 0, 0));
        submitB14_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB14_1.setForeground(new java.awt.Color(255, 255, 255));
        submitB14_1.setText("Submit");
        submitB14_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB14_1ActionPerformed(evt);
            }
        });

        resetB14_1.setBackground(new java.awt.Color(0, 0, 0));
        resetB14_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB14_1.setForeground(new java.awt.Color(255, 255, 255));
        resetB14_1.setText("Reset");
        resetB14_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB14_1ActionPerformed(evt);
            }
        });

        luxuryroomL14_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        luxuryroomL14_1.setText("Luxury Room");

        luxuryroomI14_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t14_1AddLayout = new javax.swing.GroupLayout(t14_1Add);
        t14_1Add.setLayout(t14_1AddLayout);
        t14_1AddLayout.setHorizontalGroup(
            t14_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t14_1AddLayout.createSequentialGroup()
                .addGroup(t14_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t14_1AddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t14_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(simpleroomL14_1)
                            .addComponent(prnL14_1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(genderL14_1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(luxuryroomL14_1))
                        .addGap(210, 210, 210)
                        .addGroup(t14_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(simpleroomI14_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(genderI14_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(prnI14_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(luxuryroomI14_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)))
                    .addGroup(t14_1AddLayout.createSequentialGroup()
                        .addGap(465, 465, 465)
                        .addComponent(submitB14_1)
                        .addGap(240, 240, 240)
                        .addComponent(resetB14_1))
                    .addGroup(t14_1AddLayout.createSequentialGroup()
                        .addGap(600, 600, 600)
                        .addComponent(headingL14_1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2431, Short.MAX_VALUE))
        );
        t14_1AddLayout.setVerticalGroup(
            t14_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t14_1AddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL14_1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 104, Short.MAX_VALUE)
                .addGroup(t14_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(prnL14_1)
                    .addComponent(prnI14_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addGroup(t14_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(genderL14_1)
                    .addComponent(genderI14_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addGroup(t14_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(simpleroomL14_1)
                    .addComponent(simpleroomI14_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addGroup(t14_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(luxuryroomL14_1)
                    .addComponent(luxuryroomI14_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t14_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB14_1)
                    .addComponent(resetB14_1))
                .addGap(963, 963, 963))
        );

        jTabbedPane1.addTab("tab41", t14_1Add);

        t14_2Update.setBackground(new java.awt.Color(255, 255, 255));

        headingL14_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL14_2.setText("Update");

        prnL14_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL14_2.setText("PRN");

        genderL14_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        genderL14_2.setText("Gender");

        simpleroomL14_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        simpleroomL14_2.setText("Simple Room");

        prnI14_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        genderI14_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        simpleroomI14_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB14_2.setBackground(new java.awt.Color(0, 0, 0));
        submitB14_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB14_2.setForeground(new java.awt.Color(255, 255, 255));
        submitB14_2.setText("Submit");
        submitB14_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB14_2ActionPerformed(evt);
            }
        });

        resetB14_2.setBackground(new java.awt.Color(0, 0, 0));
        resetB14_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB14_2.setForeground(new java.awt.Color(255, 255, 255));
        resetB14_2.setText("Reset");
        resetB14_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB14_2ActionPerformed(evt);
            }
        });

        luxuryroomL14_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        luxuryroomL14_2.setText("Luxury Room");

        luxuryroomI14_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        showB14_2.setBackground(new java.awt.Color(0, 0, 0));
        showB14_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB14_2.setForeground(new java.awt.Color(255, 255, 255));
        showB14_2.setText("Show");
        showB14_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB14_2ActionPerformed(evt);
            }
        });

        hideB14_2.setBackground(new java.awt.Color(0, 0, 0));
        hideB14_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB14_2.setForeground(new java.awt.Color(255, 255, 255));
        hideB14_2.setText("Hide");
        hideB14_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB14_2ActionPerformed(evt);
            }
        });

        jTable14_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable14_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "PRN", "Gender", "Simple Room", "Luxury Room"
            }
        ));
        jTable14_2.setRowHeight(30);
        jTable14_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable14_2MouseClicked(evt);
            }
        });
        jScrollPane14_2.setViewportView(jTable14_2);

        findB14_2.setBackground(new java.awt.Color(0, 0, 0));
        findB14_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB14_2.setForeground(new java.awt.Color(255, 255, 255));
        findB14_2.setText("Find");
        findB14_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB14_2ActionPerformed(evt);
            }
        });

        findI14_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t14_2UpdateLayout = new javax.swing.GroupLayout(t14_2Update);
        t14_2Update.setLayout(t14_2UpdateLayout);
        t14_2UpdateLayout.setHorizontalGroup(
            t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t14_2UpdateLayout.createSequentialGroup()
                .addGroup(t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t14_2UpdateLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(simpleroomL14_2)
                            .addComponent(prnL14_2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(genderL14_2, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(luxuryroomL14_2, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(55, 55, 55)
                        .addGroup(t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(simpleroomI14_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(genderI14_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(prnI14_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(luxuryroomI14_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))
                        .addGap(160, 160, 160)
                        .addGroup(t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t14_2UpdateLayout.createSequentialGroup()
                                .addComponent(findB14_2)
                                .addGap(49, 49, 49)
                                .addComponent(findI14_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane14_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t14_2UpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingL14_2))
                    .addGroup(t14_2UpdateLayout.createSequentialGroup()
                        .addGap(158, 158, 158)
                        .addComponent(submitB14_2)
                        .addGap(18, 18, 18)
                        .addComponent(resetB14_2)
                        .addGap(28, 28, 28)
                        .addComponent(showB14_2)
                        .addGap(18, 18, 18)
                        .addComponent(hideB14_2)))
                .addContainerGap(2214, Short.MAX_VALUE))
        );
        t14_2UpdateLayout.setVerticalGroup(
            t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t14_2UpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL14_2)
                .addGap(125, 125, 125)
                .addGroup(t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t14_2UpdateLayout.createSequentialGroup()
                        .addGroup(t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(prnL14_2)
                            .addComponent(prnI14_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(genderL14_2)
                            .addComponent(genderI14_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(simpleroomL14_2)
                            .addComponent(simpleroomI14_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(luxuryroomL14_2)
                            .addComponent(luxuryroomI14_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane14_2, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(t14_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB14_2)
                    .addComponent(resetB14_2)
                    .addComponent(hideB14_2)
                    .addComponent(showB14_2)
                    .addComponent(findB14_2)
                    .addComponent(findI14_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(992, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab42", t14_2Update);

        t15_1Add.setBackground(new java.awt.Color(255, 255, 255));

        headingL15_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL15_1.setText("Add");

        timetableidL15_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        timetableidL15_1.setText("Time Table ID");

        courseidL15_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        courseidL15_1.setText("Course ID");

        facultyidL15_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        facultyidL15_1.setText("Faculty ID");

        timetableidI15_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        courseidI15_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        facultyidI15_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB15_1.setBackground(new java.awt.Color(0, 0, 0));
        submitB15_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB15_1.setForeground(new java.awt.Color(255, 255, 255));
        submitB15_1.setText("Submit");
        submitB15_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB15_1ActionPerformed(evt);
            }
        });

        resetB15_1.setBackground(new java.awt.Color(0, 0, 0));
        resetB15_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB15_1.setForeground(new java.awt.Color(255, 255, 255));
        resetB15_1.setText("Reset");
        resetB15_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB15_1ActionPerformed(evt);
            }
        });

        roomnumberL15_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        roomnumberL15_1.setText("Room Number");

        roomnumberI15_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        timingsL15_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        timingsL15_1.setText("Timings");

        timingsI15_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t15_1AddLayout = new javax.swing.GroupLayout(t15_1Add);
        t15_1Add.setLayout(t15_1AddLayout);
        t15_1AddLayout.setHorizontalGroup(
            t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t15_1AddLayout.createSequentialGroup()
                .addGroup(t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t15_1AddLayout.createSequentialGroup()
                        .addGap(600, 600, 600)
                        .addComponent(headingL15_1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t15_1AddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(facultyidL15_1)
                            .addComponent(roomnumberL15_1)
                            .addComponent(timingsL15_1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(timetableidL15_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(courseidL15_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(210, 210, 210)
                        .addGroup(t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(facultyidI15_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(courseidI15_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(timetableidI15_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(roomnumberI15_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(timingsI15_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)))
                    .addGroup(t15_1AddLayout.createSequentialGroup()
                        .addGap(475, 475, 475)
                        .addComponent(submitB15_1)
                        .addGap(246, 246, 246)
                        .addComponent(resetB15_1)))
                .addContainerGap(2420, Short.MAX_VALUE))
        );
        t15_1AddLayout.setVerticalGroup(
            t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t15_1AddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL15_1)
                .addGap(125, 125, 125)
                .addGroup(t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timetableidL15_1)
                    .addComponent(timetableidI15_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60)
                .addGroup(t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseidL15_1)
                    .addComponent(courseidI15_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60)
                .addGroup(t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(facultyidL15_1)
                    .addComponent(facultyidI15_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60)
                .addGroup(t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(roomnumberL15_1)
                    .addComponent(roomnumberI15_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60)
                .addGroup(t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(timingsL15_1)
                    .addComponent(timingsI15_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(100, 100, 100)
                .addGroup(t15_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB15_1)
                    .addComponent(resetB15_1))
                .addContainerGap(917, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab43", t15_1Add);

        t15_2Update.setBackground(new java.awt.Color(255, 255, 255));

        headingL15_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL15_2.setText("Update");

        timetableidL15_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        timetableidL15_2.setText("Time Table ID");

        courseidL15_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        courseidL15_2.setText("Course ID");

        facultyidL15_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        facultyidL15_2.setText("Faculty ID");

        timetableidI15_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        courseidI15_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        facultyidI15_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB15_2.setBackground(new java.awt.Color(0, 0, 0));
        submitB15_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB15_2.setForeground(new java.awt.Color(255, 255, 255));
        submitB15_2.setText("Submit");
        submitB15_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB15_2ActionPerformed(evt);
            }
        });

        resetB15_2.setBackground(new java.awt.Color(0, 0, 0));
        resetB15_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB15_2.setForeground(new java.awt.Color(255, 255, 255));
        resetB15_2.setText("Reset");
        resetB15_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB15_2ActionPerformed(evt);
            }
        });

        roomnumberL15_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        roomnumberL15_2.setText("Room Number");

        roomnumberI15_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        timingsL15_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        timingsL15_2.setText("Timings");

        timingsI15_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        showB15_2.setBackground(new java.awt.Color(0, 0, 0));
        showB15_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB15_2.setForeground(new java.awt.Color(255, 255, 255));
        showB15_2.setText("Show");
        showB15_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB15_2ActionPerformed(evt);
            }
        });

        hideB15_2.setBackground(new java.awt.Color(0, 0, 0));
        hideB15_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB15_2.setForeground(new java.awt.Color(255, 255, 255));
        hideB15_2.setText("Hide");
        hideB15_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB15_2ActionPerformed(evt);
            }
        });

        jTable15_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable15_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Time Table ID", "Course ID", "Faculty ID", "Room Number", "Timings"
            }
        ));
        jTable15_2.setRowHeight(30);
        jTable15_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable15_2MouseClicked(evt);
            }
        });
        jScrollPane15_2.setViewportView(jTable15_2);

        findB15_2.setBackground(new java.awt.Color(0, 0, 0));
        findB15_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB15_2.setForeground(new java.awt.Color(255, 255, 255));
        findB15_2.setText("Find");
        findB15_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB15_2ActionPerformed(evt);
            }
        });

        findI15_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        findI15_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findI15_2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t15_2UpdateLayout = new javax.swing.GroupLayout(t15_2Update);
        t15_2Update.setLayout(t15_2UpdateLayout);
        t15_2UpdateLayout.setHorizontalGroup(
            t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t15_2UpdateLayout.createSequentialGroup()
                .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t15_2UpdateLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(facultyidL15_2)
                            .addComponent(roomnumberL15_2)
                            .addComponent(timingsL15_2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(timetableidL15_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(courseidL15_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(t15_2UpdateLayout.createSequentialGroup()
                                .addComponent(submitB15_2)
                                .addGap(18, 18, 18)
                                .addComponent(resetB15_2)))
                        .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(courseidI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(facultyidI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(timetableidI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(roomnumberI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(timingsI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, t15_2UpdateLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(showB15_2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(hideB15_2)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 165, Short.MAX_VALUE)
                        .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t15_2UpdateLayout.createSequentialGroup()
                                .addComponent(findB15_2)
                                .addGap(30, 30, 30)
                                .addComponent(findI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane15_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t15_2UpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingL15_2)))
                .addContainerGap(2192, Short.MAX_VALUE))
        );
        t15_2UpdateLayout.setVerticalGroup(
            t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t15_2UpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL15_2)
                .addGap(125, 125, 125)
                .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(t15_2UpdateLayout.createSequentialGroup()
                        .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(timetableidL15_2)
                            .addComponent(timetableidI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(courseidL15_2)
                            .addComponent(courseidI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(facultyidL15_2)
                            .addComponent(facultyidI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(roomnumberL15_2)
                            .addComponent(roomnumberI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(timingsL15_2)
                            .addComponent(timingsI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane15_2, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(t15_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB15_2)
                    .addComponent(resetB15_2)
                    .addComponent(showB15_2)
                    .addComponent(findB15_2)
                    .addComponent(findI15_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(hideB15_2))
                .addContainerGap(980, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab44", t15_2Update);

        t23AdBranch.setBackground(new java.awt.Color(255, 255, 255));

        headingL23.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL23.setText("ADMIN BRANCH");

        jTable23.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable23.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Branch ID", "Branch Name"
            }
        ));
        jTable23.setRowHeight(30);
        jScrollPane23.setViewportView(jTable23);

        addB23.setBackground(new java.awt.Color(0, 0, 0));
        addB23.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addB23.setForeground(new java.awt.Color(255, 255, 255));
        addB23.setText("Add");
        addB23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addB23ActionPerformed(evt);
            }
        });

        updateB23.setBackground(new java.awt.Color(0, 0, 0));
        updateB23.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateB23.setForeground(new java.awt.Color(255, 255, 255));
        updateB23.setText("Update");
        updateB23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateB23ActionPerformed(evt);
            }
        });

        deleteB23.setBackground(new java.awt.Color(0, 0, 0));
        deleteB23.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteB23.setForeground(new java.awt.Color(255, 255, 255));
        deleteB23.setText("Delete");
        deleteB23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteB23ActionPerformed(evt);
            }
        });

        showB23.setBackground(new java.awt.Color(0, 0, 0));
        showB23.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB23.setForeground(new java.awt.Color(255, 255, 255));
        showB23.setText("Show");
        showB23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB23ActionPerformed(evt);
            }
        });

        hideB23.setBackground(new java.awt.Color(0, 0, 0));
        hideB23.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB23.setForeground(new java.awt.Color(255, 255, 255));
        hideB23.setText("Hide");
        hideB23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB23ActionPerformed(evt);
            }
        });

        findB23.setBackground(new java.awt.Color(0, 0, 0));
        findB23.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB23.setForeground(new java.awt.Color(255, 255, 255));
        findB23.setText("Find");
        findB23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB23ActionPerformed(evt);
            }
        });

        deleteI23.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        deleteI23.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                deleteI23FocusGained(evt);
            }
        });
        deleteI23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteI23ActionPerformed(evt);
            }
        });

        findI23.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t23AdBranchLayout = new javax.swing.GroupLayout(t23AdBranch);
        t23AdBranch.setLayout(t23AdBranchLayout);
        t23AdBranchLayout.setHorizontalGroup(
            t23AdBranchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t23AdBranchLayout.createSequentialGroup()
                .addGroup(t23AdBranchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t23AdBranchLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(160, 160, 160)
                        .addGroup(t23AdBranchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(updateB23)
                            .addComponent(addB23)
                            .addComponent(deleteB23)
                            .addComponent(showB23)
                            .addComponent(hideB23)
                            .addComponent(findB23))
                        .addGap(80, 80, 80)
                        .addGroup(t23AdBranchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(findI23, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteI23, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(t23AdBranchLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL23, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2207, Short.MAX_VALUE))
        );
        t23AdBranchLayout.setVerticalGroup(
            t23AdBranchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t23AdBranchLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL23)
                .addGap(125, 125, 125)
                .addGroup(t23AdBranchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t23AdBranchLayout.createSequentialGroup()
                        .addComponent(addB23)
                        .addGap(48, 48, 48)
                        .addComponent(updateB23)
                        .addGap(48, 48, 48)
                        .addGroup(t23AdBranchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteB23)
                            .addComponent(deleteI23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(48, 48, 48)
                        .addComponent(showB23)
                        .addGap(48, 48, 48)
                        .addComponent(hideB23)
                        .addGap(48, 48, 48)
                        .addGroup(t23AdBranchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(findB23)
                            .addComponent(findI23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 432, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(990, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab45", t23AdBranch);

        t24AdStudentDetails.setBackground(new java.awt.Color(255, 255, 255));

        headingL24.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL24.setText("STUDENT DETAILS");

        jTable24.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable24.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "PRN", "First Name", "Last Name", "Year", "Branch ID", "Semester", "DOB", "Father's Name", "Email", "Street Name", "Street Number", "Zip Code", "State", "City", "Phone Number 1", "Phone Number 2"
            }
        ));
        jTable24.setRowHeight(30);
        jScrollPane24.setViewportView(jTable24);
        if (jTable24.getColumnModel().getColumnCount() > 0) {
            jTable24.getColumnModel().getColumn(0).setHeaderValue("PRN");
            jTable24.getColumnModel().getColumn(1).setHeaderValue("First Name");
            jTable24.getColumnModel().getColumn(2).setHeaderValue("Last Name");
            jTable24.getColumnModel().getColumn(3).setHeaderValue("Year");
            jTable24.getColumnModel().getColumn(4).setHeaderValue("Branch ID");
            jTable24.getColumnModel().getColumn(5).setHeaderValue("Semester");
            jTable24.getColumnModel().getColumn(6).setHeaderValue("DOB");
            jTable24.getColumnModel().getColumn(7).setHeaderValue("Father's Name");
            jTable24.getColumnModel().getColumn(8).setHeaderValue("Email");
            jTable24.getColumnModel().getColumn(9).setHeaderValue("Street Name");
            jTable24.getColumnModel().getColumn(10).setHeaderValue("Street Number");
            jTable24.getColumnModel().getColumn(11).setHeaderValue("Zip Code");
            jTable24.getColumnModel().getColumn(12).setHeaderValue("State");
            jTable24.getColumnModel().getColumn(13).setHeaderValue("City");
            jTable24.getColumnModel().getColumn(14).setHeaderValue("Phone Number 1");
            jTable24.getColumnModel().getColumn(15).setHeaderValue("Phone Number 2");
        }

        addB24.setBackground(new java.awt.Color(0, 0, 0));
        addB24.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addB24.setForeground(new java.awt.Color(255, 255, 255));
        addB24.setText("Add");
        addB24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addB24ActionPerformed(evt);
            }
        });

        updateB24.setBackground(new java.awt.Color(0, 0, 0));
        updateB24.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateB24.setForeground(new java.awt.Color(255, 255, 255));
        updateB24.setText("Update");
        updateB24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateB24ActionPerformed(evt);
            }
        });

        deleteB24.setBackground(new java.awt.Color(0, 0, 0));
        deleteB24.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteB24.setForeground(new java.awt.Color(255, 255, 255));
        deleteB24.setText("Delete");
        deleteB24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteB24ActionPerformed(evt);
            }
        });

        showB24.setBackground(new java.awt.Color(0, 0, 0));
        showB24.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB24.setForeground(new java.awt.Color(255, 255, 255));
        showB24.setText("Show");
        showB24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB24ActionPerformed(evt);
            }
        });

        hideB24.setBackground(new java.awt.Color(0, 0, 0));
        hideB24.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB24.setForeground(new java.awt.Color(255, 255, 255));
        hideB24.setText("Hide");
        hideB24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB24ActionPerformed(evt);
            }
        });

        findB24.setBackground(new java.awt.Color(0, 0, 0));
        findB24.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB24.setForeground(new java.awt.Color(255, 255, 255));
        findB24.setText("Find");
        findB24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB24ActionPerformed(evt);
            }
        });

        deleteI24.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        deleteI24.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                deleteI24FocusGained(evt);
            }
        });
        deleteI24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteI24ActionPerformed(evt);
            }
        });

        findI24.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t24AdStudentDetailsLayout = new javax.swing.GroupLayout(t24AdStudentDetails);
        t24AdStudentDetails.setLayout(t24AdStudentDetailsLayout);
        t24AdStudentDetailsLayout.setHorizontalGroup(
            t24AdStudentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t24AdStudentDetailsLayout.createSequentialGroup()
                .addGroup(t24AdStudentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t24AdStudentDetailsLayout.createSequentialGroup()
                        .addGap(479, 479, 479)
                        .addComponent(headingL24, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t24AdStudentDetailsLayout.createSequentialGroup()
                        .addGap(150, 150, 150)
                        .addGroup(t24AdStudentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(t24AdStudentDetailsLayout.createSequentialGroup()
                                .addGroup(t24AdStudentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(deleteB24)
                                    .addComponent(addB24))
                                .addGroup(t24AdStudentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(t24AdStudentDetailsLayout.createSequentialGroup()
                                        .addGap(60, 60, 60)
                                        .addComponent(deleteI24, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(findB24)
                                        .addGap(60, 60, 60)
                                        .addComponent(findI24, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(t24AdStudentDetailsLayout.createSequentialGroup()
                                        .addGap(196, 196, 196)
                                        .addComponent(updateB24)
                                        .addGap(232, 232, 232)
                                        .addComponent(showB24)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(hideB24))))
                            .addComponent(jScrollPane24, javax.swing.GroupLayout.PREFERRED_SIZE, 1002, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(2208, Short.MAX_VALUE))
        );
        t24AdStudentDetailsLayout.setVerticalGroup(
            t24AdStudentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t24AdStudentDetailsLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL24)
                .addGap(124, 124, 124)
                .addComponent(jScrollPane24, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addGroup(t24AdStudentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t24AdStudentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(deleteB24)
                        .addComponent(deleteI24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t24AdStudentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(findB24)
                        .addComponent(findI24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50)
                .addGroup(t24AdStudentDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addB24)
                    .addComponent(updateB24)
                    .addComponent(hideB24)
                    .addComponent(showB24))
                .addContainerGap(901, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab46", t24AdStudentDetails);

        t25AdAdminDetails.setBackground(new java.awt.Color(255, 255, 255));

        headingL25.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL25.setText("ADMIN DETAILS");

        jTable25.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable25.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Admin ID", "First Name", "Last Name", "Email"
            }
        ));
        jTable25.setRowHeight(30);
        jScrollPane25.setViewportView(jTable25);

        addB25.setBackground(new java.awt.Color(0, 0, 0));
        addB25.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        addB25.setForeground(new java.awt.Color(255, 255, 255));
        addB25.setText("Add");
        addB25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addB25ActionPerformed(evt);
            }
        });

        updateB25.setBackground(new java.awt.Color(0, 0, 0));
        updateB25.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        updateB25.setForeground(new java.awt.Color(255, 255, 255));
        updateB25.setText("Update");
        updateB25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateB25ActionPerformed(evt);
            }
        });

        deleteB25.setBackground(new java.awt.Color(0, 0, 0));
        deleteB25.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        deleteB25.setForeground(new java.awt.Color(255, 255, 255));
        deleteB25.setText("Delete");
        deleteB25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteB25ActionPerformed(evt);
            }
        });

        showB25.setBackground(new java.awt.Color(0, 0, 0));
        showB25.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB25.setForeground(new java.awt.Color(255, 255, 255));
        showB25.setText("Show");
        showB25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB25ActionPerformed(evt);
            }
        });

        hideB25.setBackground(new java.awt.Color(0, 0, 0));
        hideB25.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB25.setForeground(new java.awt.Color(255, 255, 255));
        hideB25.setText("Hide");
        hideB25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB25ActionPerformed(evt);
            }
        });

        findB25.setBackground(new java.awt.Color(0, 0, 0));
        findB25.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        findB25.setForeground(new java.awt.Color(255, 255, 255));
        findB25.setText("Find");
        findB25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findB25ActionPerformed(evt);
            }
        });

        deleteI25.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        deleteI25.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                deleteI25FocusGained(evt);
            }
        });
        deleteI25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteI25ActionPerformed(evt);
            }
        });

        findI25.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t25AdAdminDetailsLayout = new javax.swing.GroupLayout(t25AdAdminDetails);
        t25AdAdminDetails.setLayout(t25AdAdminDetailsLayout);
        t25AdAdminDetailsLayout.setHorizontalGroup(
            t25AdAdminDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t25AdAdminDetailsLayout.createSequentialGroup()
                .addGroup(t25AdAdminDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t25AdAdminDetailsLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(jScrollPane25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(160, 160, 160)
                        .addGroup(t25AdAdminDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t25AdAdminDetailsLayout.createSequentialGroup()
                                .addGroup(t25AdAdminDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(deleteB25, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(showB25)
                                    .addComponent(hideB25)
                                    .addComponent(findB25))
                                .addGap(80, 80, 80)
                                .addGroup(t25AdAdminDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(deleteI25, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(findI25, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(updateB25)
                            .addComponent(addB25)))
                    .addGroup(t25AdAdminDetailsLayout.createSequentialGroup()
                        .addGap(495, 495, 495)
                        .addComponent(headingL25, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2215, Short.MAX_VALUE))
        );
        t25AdAdminDetailsLayout.setVerticalGroup(
            t25AdAdminDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t25AdAdminDetailsLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL25)
                .addGap(125, 125, 125)
                .addGroup(t25AdAdminDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(t25AdAdminDetailsLayout.createSequentialGroup()
                        .addComponent(addB25)
                        .addGap(48, 48, 48)
                        .addComponent(updateB25)
                        .addGap(48, 48, 48)
                        .addGroup(t25AdAdminDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(deleteI25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deleteB25))
                        .addGap(48, 48, 48)
                        .addComponent(showB25)
                        .addGap(48, 48, 48)
                        .addComponent(hideB25)
                        .addGap(48, 48, 48)
                        .addGroup(t25AdAdminDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(findB25)
                            .addComponent(findI25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane25))
                .addContainerGap(990, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab47", t25AdAdminDetails);

        t23_1Add.setBackground(new java.awt.Color(255, 255, 255));

        headingL23_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL23_1.setText("Add");

        branchidL23_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchidL23_1.setText("Branch ID");

        branchnameL23_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchnameL23_1.setText("Branch Name");

        branchidI23_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        branchnameI23_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB23_1.setBackground(new java.awt.Color(0, 0, 0));
        submitB23_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB23_1.setForeground(new java.awt.Color(255, 255, 255));
        submitB23_1.setText("Submit");
        submitB23_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB23_1ActionPerformed(evt);
            }
        });

        resetB23_1.setBackground(new java.awt.Color(0, 0, 0));
        resetB23_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB23_1.setForeground(new java.awt.Color(255, 255, 255));
        resetB23_1.setText("Reset");
        resetB23_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB23_1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t23_1AddLayout = new javax.swing.GroupLayout(t23_1Add);
        t23_1Add.setLayout(t23_1AddLayout);
        t23_1AddLayout.setHorizontalGroup(
            t23_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t23_1AddLayout.createSequentialGroup()
                .addGroup(t23_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t23_1AddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t23_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(branchidL23_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(branchnameL23_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(210, 210, 210)
                        .addGroup(t23_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(branchnameI23_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(branchidI23_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)))
                    .addGroup(t23_1AddLayout.createSequentialGroup()
                        .addGap(600, 600, 600)
                        .addComponent(headingL23_1, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t23_1AddLayout.createSequentialGroup()
                        .addGap(467, 467, 467)
                        .addComponent(submitB23_1)
                        .addGap(249, 249, 249)
                        .addComponent(resetB23_1)))
                .addContainerGap(2430, Short.MAX_VALUE))
        );
        t23_1AddLayout.setVerticalGroup(
            t23_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t23_1AddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL23_1)
                .addGap(125, 125, 125)
                .addGroup(t23_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(branchidL23_1)
                    .addComponent(branchidI23_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t23_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(branchnameL23_1)
                    .addComponent(branchnameI23_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t23_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(resetB23_1)
                    .addComponent(submitB23_1))
                .addContainerGap(1086, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab48", t23_1Add);

        t23_2Update.setBackground(new java.awt.Color(255, 255, 255));

        headingL23_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL23_2.setText("Update");

        branchidL23_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchidL23_2.setText("Branch ID");

        branchnameL23_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchnameL23_2.setText("Branch Name");

        branchidI23_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        branchnameI23_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB23_2.setBackground(new java.awt.Color(0, 0, 0));
        submitB23_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB23_2.setForeground(new java.awt.Color(255, 255, 255));
        submitB23_2.setText("Submit");
        submitB23_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB23_2ActionPerformed(evt);
            }
        });

        resetB23_2.setBackground(new java.awt.Color(0, 0, 0));
        resetB23_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB23_2.setForeground(new java.awt.Color(255, 255, 255));
        resetB23_2.setText("Reset");
        resetB23_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB23_2ActionPerformed(evt);
            }
        });

        showB23_2.setBackground(new java.awt.Color(0, 0, 0));
        showB23_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB23_2.setForeground(new java.awt.Color(255, 255, 255));
        showB23_2.setText("Show");
        showB23_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB23_2ActionPerformed(evt);
            }
        });

        hideB23_2.setBackground(new java.awt.Color(0, 0, 0));
        hideB23_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB23_2.setForeground(new java.awt.Color(255, 255, 255));
        hideB23_2.setText("Hide");
        hideB23_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB23_2ActionPerformed(evt);
            }
        });

        jTable23_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable23_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Branch ID", "Branch Name"
            }
        ));
        jTable23_2.setRowHeight(30);
        jTable23_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable23_2MouseClicked(evt);
            }
        });
        jScrollPane23_2.setViewportView(jTable23_2);

        javax.swing.GroupLayout t23_2UpdateLayout = new javax.swing.GroupLayout(t23_2Update);
        t23_2Update.setLayout(t23_2UpdateLayout);
        t23_2UpdateLayout.setHorizontalGroup(
            t23_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t23_2UpdateLayout.createSequentialGroup()
                .addGroup(t23_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t23_2UpdateLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(t23_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t23_2UpdateLayout.createSequentialGroup()
                                .addGroup(t23_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(branchidL23_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(branchnameL23_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(55, 55, 55)
                                .addGroup(t23_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(branchnameI23_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(branchidI23_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)))
                            .addGroup(t23_2UpdateLayout.createSequentialGroup()
                                .addComponent(submitB23_2)
                                .addGap(18, 18, 18)
                                .addComponent(resetB23_2)
                                .addGap(29, 29, 29)
                                .addComponent(showB23_2)
                                .addGap(18, 18, 18)
                                .addComponent(hideB23_2)))
                        .addGap(160, 160, 160)
                        .addComponent(jScrollPane23_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t23_2UpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingL23_2, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2213, Short.MAX_VALUE))
        );
        t23_2UpdateLayout.setVerticalGroup(
            t23_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t23_2UpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL23_2)
                .addGap(125, 125, 125)
                .addGroup(t23_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t23_2UpdateLayout.createSequentialGroup()
                        .addGroup(t23_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(branchidL23_2)
                            .addComponent(branchidI23_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(125, 125, 125)
                        .addGroup(t23_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(branchnameL23_2)
                            .addComponent(branchnameI23_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(200, 200, 200)
                        .addGroup(t23_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(submitB23_2)
                            .addComponent(resetB23_2)
                            .addComponent(showB23_2)
                            .addComponent(hideB23_2)))
                    .addComponent(jScrollPane23_2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 411, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(1011, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab49", t23_2Update);

        t25_1Add.setBackground(new java.awt.Color(255, 255, 255));

        headingL25_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL25_1.setText("Add");

        adminidL25_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        adminidL25_1.setText("Admin ID");

        firstnameL25_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        firstnameL25_1.setText("First Name");

        adminidI25_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        firstnameI25_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB25_1.setBackground(new java.awt.Color(0, 0, 0));
        submitB25_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB25_1.setForeground(new java.awt.Color(255, 255, 255));
        submitB25_1.setText("Submit");
        submitB25_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB25_1ActionPerformed(evt);
            }
        });

        resetB25_1.setBackground(new java.awt.Color(0, 0, 0));
        resetB25_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB25_1.setForeground(new java.awt.Color(255, 255, 255));
        resetB25_1.setText("Reset");
        resetB25_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB25_1ActionPerformed(evt);
            }
        });

        lastnameL25_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lastnameL25_1.setText("Last Name");

        emaiL25_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        emaiL25_1.setText("Email");

        lastnameI25_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        emailI25_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t25_1AddLayout = new javax.swing.GroupLayout(t25_1Add);
        t25_1Add.setLayout(t25_1AddLayout);
        t25_1AddLayout.setHorizontalGroup(
            t25_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t25_1AddLayout.createSequentialGroup()
                .addGroup(t25_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t25_1AddLayout.createSequentialGroup()
                        .addGap(400, 400, 400)
                        .addGroup(t25_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(adminidL25_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(firstnameL25_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lastnameL25_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(emaiL25_1, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(210, 210, 210)
                        .addGroup(t25_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(emailI25_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(firstnameI25_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(adminidI25_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(lastnameI25_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)))
                    .addGroup(t25_1AddLayout.createSequentialGroup()
                        .addGap(610, 610, 610)
                        .addComponent(headingL25_1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t25_1AddLayout.createSequentialGroup()
                        .addGap(465, 465, 465)
                        .addComponent(submitB25_1)
                        .addGap(240, 240, 240)
                        .addComponent(resetB25_1)))
                .addGap(1372, 2452, Short.MAX_VALUE))
        );
        t25_1AddLayout.setVerticalGroup(
            t25_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t25_1AddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL25_1)
                .addGap(125, 125, 125)
                .addGroup(t25_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminidL25_1)
                    .addComponent(adminidI25_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addGroup(t25_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(firstnameL25_1)
                    .addComponent(firstnameI25_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addGroup(t25_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lastnameL25_1)
                    .addComponent(lastnameI25_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72)
                .addGroup(t25_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emaiL25_1)
                    .addComponent(emailI25_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(125, 125, 125)
                .addGroup(t25_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB25_1)
                    .addComponent(resetB25_1))
                .addContainerGap(941, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab50", t25_1Add);

        t25_2Update.setBackground(new java.awt.Color(255, 255, 255));

        headingL25_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL25_2.setText("Update");

        adminidL25_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        adminidL25_2.setText("Admin ID");

        firstnameL25_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        firstnameL25_2.setText("First Name");

        adminidI25_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        firstnameI25_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB25_2.setBackground(new java.awt.Color(0, 0, 0));
        submitB25_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB25_2.setForeground(new java.awt.Color(255, 255, 255));
        submitB25_2.setText("Submit");
        submitB25_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB25_2ActionPerformed(evt);
            }
        });

        resetB25_2.setBackground(new java.awt.Color(0, 0, 0));
        resetB25_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB25_2.setForeground(new java.awt.Color(255, 255, 255));
        resetB25_2.setText("Reset");
        resetB25_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB25_2ActionPerformed(evt);
            }
        });

        lastnameL25_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lastnameL25_2.setText("Last Name");

        emaiL25_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        emaiL25_2.setText("Email");

        lastnameI25_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        emailI25_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        showB25_2.setBackground(new java.awt.Color(0, 0, 0));
        showB25_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB25_2.setForeground(new java.awt.Color(255, 255, 255));
        showB25_2.setText("Show");
        showB25_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB25_2ActionPerformed(evt);
            }
        });

        hideB25_2.setBackground(new java.awt.Color(0, 0, 0));
        hideB25_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB25_2.setForeground(new java.awt.Color(255, 255, 255));
        hideB25_2.setText("Hide");
        hideB25_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB25_2ActionPerformed(evt);
            }
        });

        jTable25_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable25_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Admin ID", "First Name", "Last Name", "Email"
            }
        ));
        jTable25_2.setRowHeight(30);
        jTable25_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable25_2MouseClicked(evt);
            }
        });
        jScrollPane25_2.setViewportView(jTable25_2);

        javax.swing.GroupLayout t25_2UpdateLayout = new javax.swing.GroupLayout(t25_2Update);
        t25_2Update.setLayout(t25_2UpdateLayout);
        t25_2UpdateLayout.setHorizontalGroup(
            t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t25_2UpdateLayout.createSequentialGroup()
                .addGroup(t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t25_2UpdateLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(t25_2UpdateLayout.createSequentialGroup()
                                .addGroup(t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(adminidL25_2, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(firstnameL25_2)
                                    .addComponent(lastnameL25_2)
                                    .addComponent(emaiL25_2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 56, Short.MAX_VALUE)
                                .addGroup(t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(firstnameI25_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(adminidI25_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lastnameI25_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(emailI25_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(t25_2UpdateLayout.createSequentialGroup()
                                .addComponent(submitB25_2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(resetB25_2)
                                .addGap(18, 18, 18)
                                .addComponent(showB25_2)
                                .addGap(12, 12, 12)
                                .addComponent(hideB25_2)))
                        .addGap(160, 160, 160)
                        .addComponent(jScrollPane25_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t25_2UpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingL25_2, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(2234, Short.MAX_VALUE))
        );
        t25_2UpdateLayout.setVerticalGroup(
            t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t25_2UpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL25_2)
                .addGap(125, 125, 125)
                .addGroup(t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t25_2UpdateLayout.createSequentialGroup()
                        .addGroup(t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminidL25_2)
                            .addComponent(adminidI25_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(firstnameL25_2)
                            .addComponent(firstnameI25_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lastnameI25_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lastnameL25_2))
                        .addGap(55, 55, 55)
                        .addGroup(t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(emaiL25_2)
                            .addComponent(emailI25_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(125, 125, 125)
                        .addGroup(t25_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(submitB25_2)
                            .addComponent(resetB25_2)
                            .addComponent(showB25_2)
                            .addComponent(hideB25_2)))
                    .addComponent(jScrollPane25_2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 429, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(993, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab51", t25_2Update);

        t24_1Add.setBackground(new java.awt.Color(255, 255, 255));

        headingL24_1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL24_1.setText("Add");

        prnL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL24_1.setText("PRN");

        firstnameL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        firstnameL24_1.setText("First Name");

        prnI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        firstnameI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB24_1.setBackground(new java.awt.Color(0, 0, 0));
        submitB24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB24_1.setForeground(new java.awt.Color(255, 255, 255));
        submitB24_1.setText("Submit");
        submitB24_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB24_1ActionPerformed(evt);
            }
        });

        resetB24_1.setBackground(new java.awt.Color(0, 0, 0));
        resetB24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB24_1.setForeground(new java.awt.Color(255, 255, 255));
        resetB24_1.setText("Reset");
        resetB24_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB24_1ActionPerformed(evt);
            }
        });

        lastnameL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lastnameL24_1.setText("Last Name");

        yearL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        yearL24_1.setText("Year");

        lastnameI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        yearI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        branchidL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchidL24_1.setText("Branch ID");

        semesterL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        semesterL24_1.setText("Semester");

        dobL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        dobL24_1.setText("DOB");

        fathersnameL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        fathersnameL24_1.setText("Father's Name ");

        branchidI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        semesterI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        dobI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        fathersnameI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        emailL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        emailL24_1.setText("Email");

        streetnameL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        streetnameL24_1.setText("Street Name");

        streetnumberL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        streetnumberL24_1.setText("Street Number");

        zipcodeL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        zipcodeL24_1.setText("Zipcode");

        cityL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cityL24_1.setText("City");

        stateL24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        stateL24_1.setText("State");

        phonenumber1L24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        phonenumber1L24_1.setText("Phone Number");

        phonenumber2L24_1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        phonenumber2L24_1.setText("Phone Number 2");

        emailI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        streetnameI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        streetnumberI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        zipcodeI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        cityI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        stateI24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        phonenumber1I24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        phonenumber2I24_1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout t24_1AddLayout = new javax.swing.GroupLayout(t24_1Add);
        t24_1Add.setLayout(t24_1AddLayout);
        t24_1AddLayout.setHorizontalGroup(
            t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t24_1AddLayout.createSequentialGroup()
                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t24_1AddLayout.createSequentialGroup()
                        .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t24_1AddLayout.createSequentialGroup()
                                .addGap(150, 150, 150)
                                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(prnL24_1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(yearL24_1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dobL24_1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(branchidL24_1)
                                    .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(semesterL24_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lastnameL24_1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(firstnameL24_1)
                                    .addComponent(fathersnameL24_1))
                                .addGap(55, 55, 55)
                                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(yearI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(lastnameI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(firstnameI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(prnI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(fathersnameI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(dobI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(semesterI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(branchidI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))
                                .addGap(210, 210, 210)
                                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(cityL24_1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(stateL24_1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(streetnumberL24_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(streetnameL24_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(emailL24_1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(zipcodeL24_1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(phonenumber1L24_1)
                                    .addComponent(phonenumber2L24_1)))
                            .addGroup(t24_1AddLayout.createSequentialGroup()
                                .addGap(610, 610, 610)
                                .addComponent(headingL24_1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(55, 55, 55)
                        .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(emailI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(streetnameI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(streetnumberI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(zipcodeI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(cityI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(stateI24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(phonenumber1I24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(phonenumber2I24_1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)))
                    .addGroup(t24_1AddLayout.createSequentialGroup()
                        .addGap(260, 260, 260)
                        .addComponent(submitB24_1)
                        .addGap(527, 527, 527)
                        .addComponent(resetB24_1)))
                .addContainerGap(2210, Short.MAX_VALUE))
        );
        t24_1AddLayout.setVerticalGroup(
            t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t24_1AddLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL24_1)
                .addGap(100, 100, 100)
                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(prnL24_1)
                    .addComponent(prnI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(emailL24_1)
                    .addComponent(emailI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(t24_1AddLayout.createSequentialGroup()
                        .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(streetnumberL24_1)
                            .addComponent(streetnumberI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30))
                    .addGroup(t24_1AddLayout.createSequentialGroup()
                        .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(firstnameL24_1)
                            .addComponent(firstnameI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(streetnameL24_1)
                            .addComponent(streetnameI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35)
                        .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lastnameL24_1)
                            .addComponent(lastnameI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35)))
                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(yearL24_1)
                    .addComponent(yearI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(zipcodeL24_1)
                    .addComponent(zipcodeI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(branchidL24_1)
                    .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(branchidI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cityL24_1)
                        .addComponent(cityI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(35, 35, 35)
                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(semesterL24_1)
                    .addComponent(semesterI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stateL24_1)
                    .addComponent(stateI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dobL24_1)
                    .addComponent(dobI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(phonenumber1L24_1)
                    .addComponent(phonenumber1I24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fathersnameL24_1)
                    .addComponent(fathersnameI24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(phonenumber2L24_1)
                    .addComponent(phonenumber2I24_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(67, 67, 67)
                .addGroup(t24_1AddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB24_1)
                    .addComponent(resetB24_1))
                .addContainerGap(887, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab52", t24_1Add);

        t24_2Update.setBackground(new java.awt.Color(255, 255, 255));

        headingL24_2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        headingL24_2.setText("Update");

        prnL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        prnL24_2.setText("PRN");

        firstnameL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        firstnameL24_2.setText("First Name");

        prnI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        firstnameI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        submitB24_2.setBackground(new java.awt.Color(0, 0, 0));
        submitB24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        submitB24_2.setForeground(new java.awt.Color(255, 255, 255));
        submitB24_2.setText("Submit");
        submitB24_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitB24_2ActionPerformed(evt);
            }
        });

        resetB24_2.setBackground(new java.awt.Color(0, 0, 0));
        resetB24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        resetB24_2.setForeground(new java.awt.Color(255, 255, 255));
        resetB24_2.setText("Reset");
        resetB24_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetB24_2ActionPerformed(evt);
            }
        });

        lastnameL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lastnameL24_2.setText("Last Name");

        yearL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        yearL24_2.setText("Year");

        lastnameI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        yearI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        branchidL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchidL24_2.setText("Branch ID");

        semesterL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        semesterL24_2.setText("Semester");

        dobL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        dobL24_2.setText("DOB");

        fathersnameL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        fathersnameL24_2.setText("Father's Name ");

        branchidI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        semesterI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        dobI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        fathersnameI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        emailL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        emailL24_2.setText("Email");

        streetnameL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        streetnameL24_2.setText("Street Name");

        streetnumberL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        streetnumberL24_2.setText("Street Number");

        zipcodeL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        zipcodeL24_2.setText("Zipcode");

        cityL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cityL24_2.setText("City");

        stateL24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        stateL24_2.setText("State");

        phonenumber1L24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        phonenumber1L24_2.setText("Phone Number");

        phonenumber2L24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        phonenumber2L24_2.setText("Phone Number 2");

        emailI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        streetnameI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        streetnumberI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        zipcodeI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        cityI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        stateI24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        phonenumber1I24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        phonenumber2I24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jTable24_2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable24_2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "PRN", "First Name", "Last Name", "Year", "Branch ID", "Semester", "DOB", "Father's Name", "Email", "Street Name", "Street Number", "Zip Code", "State", "City", "Phone Number 1", "Phone Number 2"
            }
        ));
        jTable24_2.setRowHeight(30);
        jTable24_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable24_2MouseClicked(evt);
            }
        });
        jScrollPane24_2.setViewportView(jTable24_2);
        if (jTable24_2.getColumnModel().getColumnCount() > 0) {
            jTable24_2.getColumnModel().getColumn(0).setHeaderValue("PRN");
            jTable24_2.getColumnModel().getColumn(1).setHeaderValue("First Name");
            jTable24_2.getColumnModel().getColumn(2).setHeaderValue("Last Name");
            jTable24_2.getColumnModel().getColumn(3).setHeaderValue("Year");
            jTable24_2.getColumnModel().getColumn(4).setHeaderValue("Branch ID");
            jTable24_2.getColumnModel().getColumn(5).setHeaderValue("Semester");
            jTable24_2.getColumnModel().getColumn(6).setHeaderValue("DOB");
            jTable24_2.getColumnModel().getColumn(7).setHeaderValue("Father's Name");
            jTable24_2.getColumnModel().getColumn(8).setHeaderValue("Email");
            jTable24_2.getColumnModel().getColumn(9).setHeaderValue("Street Name");
            jTable24_2.getColumnModel().getColumn(10).setHeaderValue("Street Number");
            jTable24_2.getColumnModel().getColumn(11).setHeaderValue("Zip Code");
            jTable24_2.getColumnModel().getColumn(12).setHeaderValue("State");
            jTable24_2.getColumnModel().getColumn(13).setHeaderValue("City");
            jTable24_2.getColumnModel().getColumn(14).setHeaderValue("Phone Number 1");
            jTable24_2.getColumnModel().getColumn(15).setHeaderValue("Phone Number 2");
        }

        showB24_2.setBackground(new java.awt.Color(0, 0, 0));
        showB24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        showB24_2.setForeground(new java.awt.Color(255, 255, 255));
        showB24_2.setText("Show");
        showB24_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showB24_2ActionPerformed(evt);
            }
        });

        hideB24_2.setBackground(new java.awt.Color(0, 0, 0));
        hideB24_2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hideB24_2.setForeground(new java.awt.Color(255, 255, 255));
        hideB24_2.setText("Hide");
        hideB24_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hideB24_2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout t24_2UpdateLayout = new javax.swing.GroupLayout(t24_2Update);
        t24_2Update.setLayout(t24_2UpdateLayout);
        t24_2UpdateLayout.setHorizontalGroup(
            t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t24_2UpdateLayout.createSequentialGroup()
                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(t24_2UpdateLayout.createSequentialGroup()
                        .addGap(580, 580, 580)
                        .addComponent(headingL24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t24_2UpdateLayout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jScrollPane24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 1210, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(t24_2UpdateLayout.createSequentialGroup()
                        .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t24_2UpdateLayout.createSequentialGroup()
                                .addGap(140, 140, 140)
                                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(firstnameI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(t24_2UpdateLayout.createSequentialGroup()
                                        .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(prnL24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(yearL24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(dobL24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(branchidL24_2)
                                            .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(semesterL24_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(lastnameL24_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addComponent(firstnameL24_2)
                                            .addComponent(fathersnameL24_2))
                                        .addGap(80, 80, 80)
                                        .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(yearI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                            .addComponent(lastnameI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                            .addComponent(fathersnameI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                            .addComponent(dobI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                            .addComponent(semesterI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                            .addComponent(branchidI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)))
                                    .addComponent(prnI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(t24_2UpdateLayout.createSequentialGroup()
                                .addGap(196, 196, 196)
                                .addComponent(submitB24_2)
                                .addGap(165, 165, 165)
                                .addComponent(resetB24_2)))
                        .addGap(150, 150, 150)
                        .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(t24_2UpdateLayout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(showB24_2)
                                .addGap(195, 195, 195)
                                .addComponent(hideB24_2))
                            .addGroup(t24_2UpdateLayout.createSequentialGroup()
                                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(stateL24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(phonenumber1L24_2)
                                    .addComponent(phonenumber2L24_2)
                                    .addComponent(emailL24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(zipcodeL24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(streetnameL24_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(streetnumberL24_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(cityL24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(80, 80, 80)
                                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(emailI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(streetnameI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(streetnumberI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(zipcodeI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(cityI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(stateI24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(phonenumber1I24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(phonenumber2I24_2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))))))
                .addContainerGap(2117, Short.MAX_VALUE))
        );
        t24_2UpdateLayout.setVerticalGroup(
            t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(t24_2UpdateLayout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(headingL24_2)
                .addGap(40, 40, 40)
                .addComponent(jScrollPane24_2, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(prnI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(prnL24_2)
                    .addComponent(emailL24_2)
                    .addComponent(emailI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(firstnameI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(firstnameL24_2)
                    .addComponent(streetnameL24_2)
                    .addComponent(streetnameI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lastnameL24_2)
                    .addComponent(lastnameI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(streetnumberL24_2)
                    .addComponent(streetnumberI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(yearL24_2)
                    .addComponent(yearI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(zipcodeL24_2)
                    .addComponent(zipcodeI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(branchidL24_2)
                    .addComponent(branchidI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cityL24_2)
                    .addComponent(cityI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(semesterL24_2)
                    .addComponent(semesterI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stateL24_2)
                    .addComponent(stateI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dobL24_2)
                    .addComponent(dobI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(phonenumber1L24_2)
                    .addComponent(phonenumber1I24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fathersnameL24_2)
                    .addComponent(fathersnameI24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(phonenumber2L24_2)
                    .addComponent(phonenumber2I24_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addGroup(t24_2UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(submitB24_2)
                    .addComponent(resetB24_2)
                    .addComponent(showB24_2)
                    .addComponent(hideB24_2))
                .addContainerGap(896, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab53", t24_2Update);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(268, -69, 3360, 1750));

        jTabbedPane2.setBackground(new java.awt.Color(255, 255, 255));

        st1.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout st1Layout = new javax.swing.GroupLayout(st1);
        st1.setLayout(st1Layout);
        st1Layout.setHorizontalGroup(
            st1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 240, Short.MAX_VALUE)
        );
        st1Layout.setVerticalGroup(
            st1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1395, Short.MAX_VALUE)
        );

        jTabbedPane2.addTab("tab1", st1);

        st2.setBackground(new java.awt.Color(0, 0, 0));

        timetableBst2.setBackground(new java.awt.Color(0, 0, 0));
        timetableBst2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        timetableBst2.setForeground(new java.awt.Color(255, 255, 255));
        timetableBst2.setText("Time-Table");
        timetableBst2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timetableBst2ActionPerformed(evt);
            }
        });

        hostelBst2.setBackground(new java.awt.Color(0, 0, 0));
        hostelBst2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hostelBst2.setForeground(new java.awt.Color(255, 255, 255));
        hostelBst2.setText("Hostel");
        hostelBst2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hostelBst2ActionPerformed(evt);
            }
        });

        courseBst2.setBackground(new java.awt.Color(0, 0, 0));
        courseBst2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        courseBst2.setForeground(new java.awt.Color(255, 255, 255));
        courseBst2.setText("Course");
        courseBst2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                courseBst2ActionPerformed(evt);
            }
        });

        feesBst2.setBackground(new java.awt.Color(0, 0, 0));
        feesBst2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        feesBst2.setForeground(new java.awt.Color(255, 255, 255));
        feesBst2.setText("Fees");
        feesBst2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                feesBst2ActionPerformed(evt);
            }
        });

        libraryBst2.setBackground(new java.awt.Color(0, 0, 0));
        libraryBst2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        libraryBst2.setForeground(new java.awt.Color(255, 255, 255));
        libraryBst2.setText("Library");
        libraryBst2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                libraryBst2ActionPerformed(evt);
            }
        });

        gradesBst2.setBackground(new java.awt.Color(0, 0, 0));
        gradesBst2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        gradesBst2.setForeground(new java.awt.Color(255, 255, 255));
        gradesBst2.setText("Grades");
        gradesBst2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gradesBst2ActionPerformed(evt);
            }
        });

        attendanceBst2.setBackground(new java.awt.Color(0, 0, 0));
        attendanceBst2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        attendanceBst2.setForeground(new java.awt.Color(255, 255, 255));
        attendanceBst2.setText("Attendance");
        attendanceBst2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attendanceBst2ActionPerformed(evt);
            }
        });

        logoutBst2.setBackground(new java.awt.Color(0, 0, 0));
        logoutBst2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        logoutBst2.setForeground(new java.awt.Color(255, 255, 255));
        logoutBst2.setText("Logout");
        logoutBst2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutBst2ActionPerformed(evt);
            }
        });

        profileBst2.setBackground(new java.awt.Color(0, 0, 0));
        profileBst2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        profileBst2.setForeground(new java.awt.Color(255, 255, 255));
        profileBst2.setText("Profile");
        profileBst2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                profileBst2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout st2Layout = new javax.swing.GroupLayout(st2);
        st2.setLayout(st2Layout);
        st2Layout.setHorizontalGroup(
            st2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoutBst2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(timetableBst2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
            .addComponent(hostelBst2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(courseBst2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(feesBst2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(libraryBst2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(gradesBst2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(attendanceBst2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(profileBst2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        st2Layout.setVerticalGroup(
            st2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(st2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(logoutBst2)
                .addGap(109, 109, 109)
                .addComponent(profileBst2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timetableBst2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(hostelBst2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(courseBst2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(feesBst2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(libraryBst2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(attendanceBst2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(gradesBst2)
                .addContainerGap(938, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("tab2", st2);

        st3.setBackground(new java.awt.Color(0, 0, 0));

        facultyBst3.setBackground(new java.awt.Color(0, 0, 0));
        facultyBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        facultyBst3.setForeground(new java.awt.Color(255, 255, 255));
        facultyBst3.setText("Faculty");
        facultyBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                facultyBst3ActionPerformed(evt);
            }
        });

        hostelBst3.setBackground(new java.awt.Color(0, 0, 0));
        hostelBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        hostelBst3.setForeground(new java.awt.Color(255, 255, 255));
        hostelBst3.setText("Hostel");
        hostelBst3.setBorderPainted(false);
        hostelBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hostelBst3ActionPerformed(evt);
            }
        });

        profileBst3.setBackground(new java.awt.Color(0, 0, 0));
        profileBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        profileBst3.setForeground(new java.awt.Color(255, 255, 255));
        profileBst3.setText("Profile");
        profileBst3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        profileBst3.setBorderPainted(false);
        profileBst3.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        profileBst3.setOpaque(true);
        profileBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                profileBst3ActionPerformed(evt);
            }
        });

        libraryBst3.setBackground(new java.awt.Color(0, 0, 0));
        libraryBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        libraryBst3.setForeground(new java.awt.Color(255, 255, 255));
        libraryBst3.setText("Library");
        libraryBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                libraryBst3ActionPerformed(evt);
            }
        });

        courseBst3.setBackground(new java.awt.Color(0, 0, 0));
        courseBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        courseBst3.setForeground(new java.awt.Color(255, 255, 255));
        courseBst3.setText("Course");
        courseBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                courseBst3ActionPerformed(evt);
            }
        });

        feesBst3.setBackground(new java.awt.Color(0, 0, 0));
        feesBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        feesBst3.setForeground(new java.awt.Color(255, 255, 255));
        feesBst3.setText("Fees");
        feesBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                feesBst3ActionPerformed(evt);
            }
        });

        gradesBst3.setBackground(new java.awt.Color(0, 0, 0));
        gradesBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        gradesBst3.setForeground(new java.awt.Color(255, 255, 255));
        gradesBst3.setText("Grades");
        gradesBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gradesBst3ActionPerformed(evt);
            }
        });

        attendanceBst3.setBackground(new java.awt.Color(0, 0, 0));
        attendanceBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        attendanceBst3.setForeground(new java.awt.Color(255, 255, 255));
        attendanceBst3.setText("Attendance");
        attendanceBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attendanceBst3ActionPerformed(evt);
            }
        });

        studentloginBst3.setBackground(new java.awt.Color(0, 0, 0));
        studentloginBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        studentloginBst3.setForeground(new java.awt.Color(255, 255, 255));
        studentloginBst3.setText("Student Login Details");
        studentloginBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentloginBst3ActionPerformed(evt);
            }
        });

        adminloginBst3.setBackground(new java.awt.Color(0, 0, 0));
        adminloginBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        adminloginBst3.setForeground(new java.awt.Color(255, 255, 255));
        adminloginBst3.setText("Admin Login Details");
        adminloginBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminloginBst3ActionPerformed(evt);
            }
        });

        backBst3.setBackground(new java.awt.Color(0, 0, 0));
        backBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        backBst3.setForeground(new java.awt.Color(255, 255, 255));
        backBst3.setText("Logout");
        backBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBst3ActionPerformed(evt);
            }
        });

        timetableBst3.setBackground(new java.awt.Color(0, 0, 0));
        timetableBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        timetableBst3.setForeground(new java.awt.Color(255, 255, 255));
        timetableBst3.setText("Time-Table");
        timetableBst3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        timetableBst3.setBorderPainted(false);
        timetableBst3.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        timetableBst3.setOpaque(true);
        timetableBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timetableBst3ActionPerformed(evt);
            }
        });

        branchBst3.setBackground(new java.awt.Color(0, 0, 0));
        branchBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        branchBst3.setForeground(new java.awt.Color(255, 255, 255));
        branchBst3.setText("Branch");
        branchBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                branchBst3ActionPerformed(evt);
            }
        });

        studentdetailsBst3.setBackground(new java.awt.Color(0, 0, 0));
        studentdetailsBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        studentdetailsBst3.setForeground(new java.awt.Color(255, 255, 255));
        studentdetailsBst3.setText("Student Details");
        studentdetailsBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentdetailsBst3ActionPerformed(evt);
            }
        });

        admindetailsBst3.setBackground(new java.awt.Color(0, 0, 0));
        admindetailsBst3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        admindetailsBst3.setForeground(new java.awt.Color(255, 255, 255));
        admindetailsBst3.setText("Admin Details");
        admindetailsBst3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                admindetailsBst3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout st3Layout = new javax.swing.GroupLayout(st3);
        st3.setLayout(st3Layout);
        st3Layout.setHorizontalGroup(
            st3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(hostelBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(courseBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(feesBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(facultyBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(libraryBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(attendanceBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(gradesBst3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(studentloginBst3, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
            .addComponent(backBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(profileBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(timetableBst3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(branchBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(studentdetailsBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(admindetailsBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(adminloginBst3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        st3Layout.setVerticalGroup(
            st3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(st3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(backBst3)
                .addGap(69, 69, 69)
                .addComponent(profileBst3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timetableBst3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(hostelBst3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(courseBst3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(feesBst3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(libraryBst3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(attendanceBst3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(facultyBst3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(gradesBst3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(branchBst3)
                .addGap(9, 9, 9)
                .addComponent(studentdetailsBst3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(admindetailsBst3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(studentloginBst3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(adminloginBst3)
                .addContainerGap(752, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("tab3", st3);

        st4.setBackground(new java.awt.Color(0, 0, 0));

        homeBst4.setBackground(new java.awt.Color(0, 0, 0));
        homeBst4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        homeBst4.setForeground(new java.awt.Color(255, 255, 255));
        homeBst4.setText("Home");
        homeBst4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeBst4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout st4Layout = new javax.swing.GroupLayout(st4);
        st4.setLayout(st4Layout);
        st4Layout.setHorizontalGroup(
            st4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeBst4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
        );
        st4Layout.setVerticalGroup(
            st4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(st4Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(homeBst4)
                .addContainerGap(1344, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("tab4", st4);

        st5.setBackground(new java.awt.Color(0, 0, 0));

        homeBst5.setBackground(new java.awt.Color(0, 0, 0));
        homeBst5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        homeBst5.setForeground(new java.awt.Color(255, 255, 255));
        homeBst5.setText("Home");
        homeBst5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeBst5ActionPerformed(evt);
            }
        });

        backBst5.setBackground(new java.awt.Color(0, 0, 0));
        backBst5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        backBst5.setForeground(new java.awt.Color(255, 255, 255));
        backBst5.setText("Back");
        backBst5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBst5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout st5Layout = new javax.swing.GroupLayout(st5);
        st5.setLayout(st5Layout);
        st5Layout.setHorizontalGroup(
            st5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(backBst5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
            .addComponent(homeBst5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        st5Layout.setVerticalGroup(
            st5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(st5Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(backBst5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(homeBst5)
                .addContainerGap(1306, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("tab5", st5);

        getContentPane().add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -38, -1, 1430));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void useDB(){
        try {
            String query1 = "USE gui";
            PreparedStatement stmt2 = conn.prepareStatement(query1);
            stmt2.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Use Database Failed");
            System.out.println(e);
        }
    }
    public void allDetailsadmin(JTable tablename) {
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Adminlogin";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) tablename.getModel();
            tb1Model.setRowCount(0);
            //Iterate to all Rows one by one and store the values in table
            while (rs.next()) {
                String adminidstrall = rs.getString("AdminID");
                String adpasswordall = rs.getString("AdminPassword");
                String tb1Data[] = {adminidstrall, adpasswordall};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }

    public void allDetailsstu(JTable tablename) {
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Studentlogin";
            rs = stmt.executeQuery(query);
            DefaultTableModel tb1Model = (DefaultTableModel) tablename.getModel();
            tb1Model.setRowCount(0);
            while (rs.next()) {
                String stupasswordall = rs.getString("StudentPassword");
                String prnstrall = rs.getString("PRN");
                String tb1Data[] = {prnstrall, stupasswordall};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
        }
    }
    private void timetableBst2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timetableBst2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(27);

        try {

            stmt = conn.createStatement();
            String query0 = "SELECT * FROM Student s INNER JOIN Branch b on s.BranchID=b.BranchID";
            rs = stmt.executeQuery(query0);
            String branch = "";
            String branchid = "";
            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    branch = rs.getString("BranchName");
                    branchid = rs.getString("BranchID");
                    branchI22.setText(branch);
                }
            }
            String query = "SELECT * FROM Timetable t INNER JOIN Course c ON t.CourseID=c.CourseID INNER JOIN Faculty f ON c.BranchID=f.BranchID";
            rs = stmt.executeQuery(query);
            DefaultTableModel tb1Model = (DefaultTableModel) jTable22.getModel();
            tb1Model.setRowCount(0);
            while (rs.next()) {
                if (branchid.equals(rs.getString("BranchID"))) {
                    String courseid = rs.getString("CourseID");
                    String coursename = rs.getString("CourseName");
                    String facultyid = rs.getString("FacultyID");
                    String facultyname = rs.getString("FacultyName");
                    String room = rs.getString("RoomNumber");
                    String timing = rs.getString("Timing");
                    String tb1Data[] = {courseid, coursename, facultyid, facultyname, room, timing};
                    tb1Model.addRow(tb1Data);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }

    }//GEN-LAST:event_timetableBst2ActionPerformed

    private void hostelBst2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hostelBst2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(26);

        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Hostel";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    String gender = rs.getString("Gender");
                    String simple = rs.getString("SimpleRoom");
                    String luxury = rs.getString("LuxuryRoom");
                    prnI21.setText(prnstr);
                    genderI21.setText(gender);
                    if (simple.equals("No") && luxury.equals("No")) {
                        roomtypeI21.setText("NONE");
                    } else if (simple.equals("No")) {
                        roomtypeI21.setText("Luxury");
                    } else if (luxury.equals("No")) {
                        roomtypeI21.setText("Simple");
                    } else {
                        roomtypeI21.setText("Error Found");
                    }

                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }


    }//GEN-LAST:event_hostelBst2ActionPerformed

    private void courseBst2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_courseBst2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(25);

        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Course c INNER JOIN Student s ON c.BranchID=s.BranchID INNER JOIN Branch b ON s.BranchID=b.BranchID";
            rs = stmt.executeQuery(query);
            DefaultTableModel tb1Model = (DefaultTableModel) jTable20.getModel();
            tb1Model.setRowCount(0);
            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    String branch = rs.getString("BranchName");
                    branchI20.setText(branch);
                    String courseid = rs.getString("CourseID");
                    String coursename = rs.getString("CourseName");
                    String duration = rs.getString("Duration");
                    String tb1Data[] = {courseid, coursename, duration};
                    tb1Model.addRow(tb1Data);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }


    }//GEN-LAST:event_courseBst2ActionPerformed

    private void libraryBst2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_libraryBst2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(23);

        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Library l INNER JOIN Student s ON l.LibraryID=s.PRN";
            rs = stmt.executeQuery(query);
            DefaultTableModel tb1Model = (DefaultTableModel) jTable18.getModel();
            tb1Model.setRowCount(0);
            while (rs.next()) {
                if (prnstr.equals(rs.getString("LibraryID"))) {
                    String libraryID = rs.getString("LibraryID");
                    libraryidI18.setText(libraryID);
                    String category = rs.getString("Category");
                    String issue = rs.getString("Issue");
                    String return1 = rs.getString("Return1");
                    String tb1Data[] = {category, issue, return1};
                    tb1Model.addRow(tb1Data);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }

    }//GEN-LAST:event_libraryBst2ActionPerformed

    private void attendanceBst2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attendanceBst2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(22);

        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Attendance";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    String percentage = rs.getString("Percentage");
                    String date = rs.getString("Date1");
                    prnI17.setText(prnstr);
                    percentageI17.setText(percentage);
                    dateI17.setText(date);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }

    }//GEN-LAST:event_attendanceBst2ActionPerformed

    private void gradesBst2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gradesBst2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(21);

        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Grades";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    String midsem = rs.getString("MidSem");
                    String endsem = rs.getString("EndSem");
                    prnI16.setText(prnstr);
                    midsemI16.setText(midsem);
                    endsemI16.setText(endsem);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }

    }//GEN-LAST:event_gradesBst2ActionPerformed

    private void feesBst2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_feesBst2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(24);

        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Fees f INNER JOIN Student s ON f.prn=s.prn INNER JOIN Branch b ON s.branchid=b.branchid ";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    String branch = rs.getString("BranchName");
                    String paidunpaid = rs.getString("PaidUnpaid");
                    String fine = rs.getString("Fine");
                    prnI19.setText(prnstr);
                    branchI19.setText(branch);
                    paidunpaidI19.setText(paidunpaid);
                    fineI19.setText(fine);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }


    }//GEN-LAST:event_feesBst2ActionPerformed

    private void facultyBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_facultyBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(14);
        showB9ActionPerformed(evt);

    }//GEN-LAST:event_facultyBst3ActionPerformed

    private void hostelBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hostelBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(19);
        showB14ActionPerformed(evt);

    }//GEN-LAST:event_hostelBst3ActionPerformed

    private void profileBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_profileBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(4);
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Admin";
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (adminidstr.equals(rs.getString("AdminID"))) {
                    String firstname = rs.getString("FirstName");
                    String lastname = rs.getString("LastName");
                    String email = rs.getString("email");
                    adminidI5.setText(adminidstr);
                    firstnameI5.setText(firstname);
                    lastnameI5.setText(lastname);
                    emailI5.setText(email);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }


    }//GEN-LAST:event_profileBst3ActionPerformed

    private void libraryBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_libraryBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(16);
        showB11ActionPerformed(evt);

    }//GEN-LAST:event_libraryBst3ActionPerformed

    private void courseBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_courseBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(18);
        showB13ActionPerformed(evt);

    }//GEN-LAST:event_courseBst3ActionPerformed

    private void feesBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_feesBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(17);
        showB12ActionPerformed(evt);

    }//GEN-LAST:event_feesBst3ActionPerformed

    private void gradesBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gradesBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(13);
        showB8ActionPerformed(evt);

    }//GEN-LAST:event_gradesBst3ActionPerformed

    private void attendanceBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attendanceBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(15);
        showB10ActionPerformed(evt);

    }//GEN-LAST:event_attendanceBst3ActionPerformed

    private void studentloginBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentloginBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(9);
        allDetailsstu(jTable7);

    }//GEN-LAST:event_studentloginBst3ActionPerformed

    private void adminloginBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminloginBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(5);
        allDetailsadmin(adminTABt6);
    }//GEN-LAST:event_adminloginBst3ActionPerformed


    private void backBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
        jTabbedPane2.setSelectedIndex(3);
        adminidIt3.setText("");
        passwordIt3.setText("");

    }//GEN-LAST:event_backBst3ActionPerformed

    private void logoutBst2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutBst2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
        jTabbedPane2.setSelectedIndex(3);
        prnIt2.setText("");
        passwordIt2.setText("");


    }//GEN-LAST:event_logoutBst2ActionPerformed

    private void homeBst4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeBst4ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(0);
        jTabbedPane2.setSelectedIndex(0);

    }//GEN-LAST:event_homeBst4ActionPerformed

    private void homeBst5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeBst5ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(0);
        jTabbedPane2.setSelectedIndex(0);
    }//GEN-LAST:event_homeBst5ActionPerformed

    private void backBst5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBst5ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(temp);
        jTabbedPane2.setSelectedIndex(temp1);
    }//GEN-LAST:event_backBst5ActionPerformed

    private void timetableBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timetableBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(20);
        showB15ActionPerformed(evt);
    }//GEN-LAST:event_timetableBst3ActionPerformed

    private void profileBst2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_profileBst2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(3);

    }//GEN-LAST:event_profileBst2ActionPerformed

    private void fineI19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fineI19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fineI19ActionPerformed

    private void branchI19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_branchI19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_branchI19ActionPerformed

    private void prnI19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prnI19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prnI19ActionPerformed

    private void deleteI15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteI15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteI15ActionPerformed

    private void deleteI15FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_deleteI15FocusGained
        // TODO add your handling code here:
        deleteI15.setText("");
        deleteI15.setForeground(Color.black);
    }//GEN-LAST:event_deleteI15FocusGained

    private void findB15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB15ActionPerformed
        // TODO add your handling code here:
        try {

            String timetableidstr = findI15.getText();

            if (timetableidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int timetableid = Integer.parseInt(timetableidstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable15.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Timetable WHERE timetableid ='" + timetableid + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB15ActionPerformed(evt);
                findI15.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (timetableidstr.equals(rs.getString("timetableid"))) {

                    String courseid = rs.getString("CourseID");
                    String facultyid = rs.getString("FacultyID");
                    String roomnumber = rs.getString("RoomNumber");
                    String timing = rs.getString("Timing");
                    String tb1Data[] = {timetableidstr, courseid, facultyid, roomnumber, timing};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable15.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }
            findI15.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB15ActionPerformed

    private void hideB15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB15ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable15.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB15ActionPerformed

    private void showB15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB15ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Timetable";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable15.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String timetableid = rs.getString("TimetableID");
                String courseid = rs.getString("CourseID");
                String facultyid = rs.getString("FacultyID");
                String roomnumber = rs.getString("RoomNumber");
                String timing = rs.getString("Timing");
                String tb1Data[] = {timetableid, courseid, facultyid, roomnumber, timing};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB15ActionPerformed

    private void deleteB15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteB15ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String timetableidstr = deleteI15.getText();
            if (timetableidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something!");
                return;
            }
            int timetableid = Integer.parseInt(timetableidstr);

            String query0 = "SELECT * FROM Timetable WHERE timetableid ='" + timetableid + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Does not Exists");
                deleteI15.setText("");
                return;

            }
            rs = stmt.executeQuery(query0);
            rs.next();
            if (timetableidstr.equals(rs.getString("timetableid"))) {
                String query1 = "DELETE FROM Timetable WHERE timetableid ='" + timetableid + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Deleted!");
            }
            deleteI15.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "First Delete the entry from Parent Table");
            System.out.println(e);
        }

        showB15ActionPerformed(evt);
    }//GEN-LAST:event_deleteB15ActionPerformed

    private void findB14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB14ActionPerformed
        // TODO add your handling code here:
        try {

            prnstr = findI14.getText();

            //If username is Empty
            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            //Empty the table before showing the result
            DefaultTableModel tb1Model = (DefaultTableModel) jTable14.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Hostel WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query);

            //Username not found
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB14ActionPerformed(evt);
                findI14.setText("");
                return;
            }

            //Refreshing rs
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    String gender = rs.getString("Gender");
                    String simpleroom = rs.getString("SimpleRoom");
                    String luxuryroom = rs.getString("LuxuryRoom");
                    String tb1Data[] = {prnstr, gender, simpleroom, luxuryroom};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable14.getModel();
                    tb1Model2.addRow(tb1Data);

                }
            }
            findI14.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB14ActionPerformed

    private void hideB14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB14ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable14.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB14ActionPerformed

    private void showB14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB14ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Hostel";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable14.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String prn = rs.getString("PRN");
                String gender = rs.getString("Gender");
                String simpleroom = rs.getString("SimpleRoom");
                String luxuryroom = rs.getString("LuxuryRoom");
                String tb1Data[] = {prn, gender, simpleroom, luxuryroom};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB14ActionPerformed

    private void deleteB14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteB14ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prnstr = deleteI14.getText();
            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something!");
                return;
            }
            prn = Integer.parseInt(prnstr);

            String query0 = "SELECT * FROM Hostel WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Does not Exists");
                deleteI14.setText("");
                return;

            }
            rs = stmt.executeQuery(query0);
            rs.next();
            if (prnstr.equals(rs.getString("PRN"))) {
                String query1 = "DELETE FROM Hostel WHERE PRN ='" + prn + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Deleted!");

            }
            deleteI14.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "First Delete the entry from Parent Table");
            System.out.println(e);
        }

        showB14ActionPerformed(evt);
    }//GEN-LAST:event_deleteB14ActionPerformed

    private void deleteI13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteI13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteI13ActionPerformed

    private void findB13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB13ActionPerformed
        // TODO add your handling code here:
        try {

            String courseidstr = findI13.getText();

            if (courseidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int courseid = Integer.parseInt(courseidstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable13.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Course WHERE courseid ='" + courseid + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB13ActionPerformed(evt);
                findI13.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (courseidstr.equals(rs.getString("courseid"))) {
                    String coursename = rs.getString("CourseName");
                    String duration = rs.getString("Duration");
                    String branchID = rs.getString("BranchID");
                    String tb1Data[] = {courseidstr, coursename, duration, branchID};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable13.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }
            findI13.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB13ActionPerformed

    private void hideB13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB13ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable13.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB13ActionPerformed

    private void showB13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB13ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Course";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable13.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String courseID = rs.getString("CourseID");
                String coursename = rs.getString("CourseName");
                String duration = rs.getString("Duration");
                String branchID = rs.getString("BranchID");
                String tb1Data[] = {courseID, coursename, duration, branchID};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB13ActionPerformed

    private void deleteB13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteB13ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String courseidstr = deleteI13.getText();
            if (courseidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something!");
                return;
            }
            int courseid = Integer.parseInt(courseidstr);

            String query0 = "SELECT * FROM Course WHERE courseid ='" + courseid + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Does not Exists");
                deleteI13.setText("");
                return;

            }
            rs = stmt.executeQuery(query0);
            rs.next();
            if (courseidstr.equals(rs.getString("courseid"))) {
                String query1 = "DELETE FROM Course WHERE courseid ='" + courseid + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Deleted!");
            }
            deleteI13.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "First Delete the entry from Time Table");
            System.out.println(e);
        }

        showB13ActionPerformed(evt);
    }//GEN-LAST:event_deleteB13ActionPerformed

    private void findB12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB12ActionPerformed
        // TODO add your handling code here:
        try {

            prnstr = findI12.getText();

            //If username is Empty
            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            //Empty the table before showing the result
            DefaultTableModel tb1Model = (DefaultTableModel) jTable12.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Fees WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query);

            //Username not found
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB12ActionPerformed(evt);
                findI12.setText("");
                return;
            }

            //Refreshing rs
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    String paidunpaid = rs.getString("PaidUnpaid");
                    String fine = rs.getString("Fine");
                    String tb1Data[] = {prnstr, paidunpaid, fine};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable12.getModel();
                    tb1Model2.addRow(tb1Data);

                }
            }
            findI12.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB12ActionPerformed

    private void hideB12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB12ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable12.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB12ActionPerformed

    private void showB12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB12ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Fees";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable12.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String prn = rs.getString("PRN");
                String paidunpaid = rs.getString("PaidUnpaid");
                String fine = rs.getString("Fine");
                String tb1Data[] = {prn, paidunpaid, fine};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB12ActionPerformed

    private void deleteB12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteB12ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prnstr = deleteI12.getText();

            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something!");
                return;
            }

            prn = Integer.parseInt(prnstr);

            String query0 = "SELECT * FROM Fees WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Does not Exists");
                deleteI12.setText("");
                return;

            }
            rs = stmt.executeQuery(query0);
            rs.next();
            if (prnstr.equals(rs.getString("PRN"))) {
                String query1 = "DELETE FROM Fees WHERE PRN ='" + prn + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Deleted!");

            }
            deleteI12.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "First Delete the entry from Parent Table");
            System.out.println(e);
        }
        showB12ActionPerformed(evt);
    }//GEN-LAST:event_deleteB12ActionPerformed

    private void addB12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addB12ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(28);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addB12ActionPerformed

    private void deleteI11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteI11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteI11ActionPerformed

    private void findB11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB11ActionPerformed
        // TODO add your handling code here:

        try {

            String libraryidstr = findI11.getText();

            if (libraryidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int libraryid = Integer.parseInt(libraryidstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable11.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Library WHERE libraryid ='" + libraryid + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");
                showB11ActionPerformed(evt);
                findI11.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (libraryidstr.equals(rs.getString("libraryid"))) {

                    String category = rs.getString("Category");
                    String issuedate = rs.getString("Issue");
                    String returndate = rs.getString("Return1");
                    String tb1Data[] = {libraryidstr, category, issuedate, returndate};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable11.getModel();
                    tb1Model2.addRow(tb1Data);

                }
            }
            findI11.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB11ActionPerformed

    private void hideB11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB11ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable11.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB11ActionPerformed

    private void showB11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB11ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Library";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable11.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String libid = rs.getString("LibraryID");
                String category = rs.getString("Category");
                String issuedate = rs.getString("Issue");
                String returndate = rs.getString("Return1");
                String tb1Data[] = {libid, category, issuedate, returndate};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB11ActionPerformed

    private void deleteB11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteB11ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String libraryidstr = deleteI11.getText();
            String issuedate = deleteissueI11.getText();
            if (libraryidstr.isEmpty() || issuedate.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something!");
                return;
            }
            int libraryid = Integer.parseInt(libraryidstr);

            String query0 = "SELECT * FROM Library WHERE libraryid ='" + libraryid + "' and issue = '" + issuedate + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Does not Exists");
                deleteI11.setText("");
                deleteissueI11.setText("");
                return;

            }
            rs = stmt.executeQuery(query0);
            rs.next();
            if (libraryidstr.equals(rs.getString("libraryid"))) {
                String query1 = "DELETE FROM Library WHERE libraryid ='" + libraryid + "' and issue = '" + issuedate + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Deleted!");
            }
            deleteI11.setText("");
            deleteissueI11.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "First Delete the entry from Parent Table");
            System.out.println(e);
        }
        showB11ActionPerformed(evt);
    }//GEN-LAST:event_deleteB11ActionPerformed

    private void findB10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB10ActionPerformed
        // TODO add your handling code here:
        try {

            prnstr = findI10.getText();

            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable10.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Attendance WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB10ActionPerformed(evt);
                findI10.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {

                    String percentage = rs.getString("Percentage");
                    String date = rs.getString("Date1");
                    String tb1Data[] = {prnstr, percentage, date};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable10.getModel();
                    tb1Model2.addRow(tb1Data);

                }
            }
            findI10.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB10ActionPerformed

    private void hideB10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB10ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable10.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB10ActionPerformed

    private void showB10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB10ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Attendance";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable10.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String prn = rs.getString("PRN");
                String percentage = rs.getString("Percentage");
                String date = rs.getString("Date1");
                String tb1Data[] = {prn, percentage, date};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB10ActionPerformed

    private void deleteB10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteB10ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prnstr = deleteI10.getText();

            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something!");
                return;
            }
            prn = Integer.parseInt(prnstr);

            String query0 = "SELECT * FROM Attendance WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Does not Exists");
                deleteI10.setText("");
                return;

            }
            rs = stmt.executeQuery(query0);
            rs.next();
            if (prnstr.equals(rs.getString("PRN"))) {
                String query1 = "DELETE FROM Attendance WHERE PRN ='" + prn + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Deleted!");

            }
            deleteI10.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "First Delete the entry from Parent Table");
            System.out.println(e);
        }
        showB10ActionPerformed(evt);
    }//GEN-LAST:event_deleteB10ActionPerformed

    private void addB10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addB10ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(36);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addB10ActionPerformed

    private void findB9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB9ActionPerformed
        // TODO add your handling code here:
        try {

            String facultyidstr = findI9.getText();

            if (facultyidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int facultyid = Integer.parseInt(facultyidstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable9.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Faculty WHERE facultyid ='" + facultyid + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB9ActionPerformed(evt);
                findI9.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (facultyidstr.equals(rs.getString("facultyid"))) {
                    String facultyname = rs.getString("FacultyName");
                    String branchid = rs.getString("branchID");
                    String tb1Data[] = {facultyidstr, facultyname, branchid};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable9.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }
            findI9.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB9ActionPerformed

    private void hideB9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB9ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable9.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB9ActionPerformed

    private void showB9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB9ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Faculty";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable9.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String facultyid = rs.getString("FacultyID");
                String facultyname = rs.getString("FacultyName");
                String branchid = rs.getString("branchID");
                String tb1Data[] = {facultyid, facultyname, branchid};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB9ActionPerformed

    private void deleteB9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteB9ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String facultyidstr = deleteI9.getText();
            if (facultyidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something!");
                return;
            }
            int facultyid = Integer.parseInt(facultyidstr);

            String query0 = "SELECT * FROM Faculty WHERE facultyid ='" + facultyid + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "User does not Exists");
                deleteI9.setText("");
                return;

            }
            rs = stmt.executeQuery(query0);
            rs.next();
            if (facultyidstr.equals(rs.getString("facultyid"))) {
                String query1 = "DELETE FROM Faculty WHERE facultyid ='" + facultyid + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "User Deleted!");
            }
            deleteI9.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "First Delete the Profile of this User");
            System.out.println(e);
        }
        showB9ActionPerformed(evt);
    }//GEN-LAST:event_deleteB9ActionPerformed

    private void deleteI8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteI8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteI8ActionPerformed

    private void findB8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB8ActionPerformed
        // TODO add your handling code here:

        try {

            prnstr = findI8.getText();

            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable8.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Grades WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");
                showB8ActionPerformed(evt);
                findI8.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    String midsem = rs.getString("MidSem");
                    String endsem = rs.getString("EndSem");
                    String tb1Data[] = {prnstr, midsem, endsem};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable8.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }
            findI8.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB8ActionPerformed

    private void hideB8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB8ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable8.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB8ActionPerformed

    private void showB8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB8ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Grades";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable8.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String prn = rs.getString("PRN");
                String midsem = rs.getString("MidSem");
                String endsem = rs.getString("EndSem");
                String tb1Data[] = {prn, midsem, endsem};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB8ActionPerformed

    private void deleteB8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteB8ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prnstr = deleteI8.getText();

            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something!");
                return;
            }
            prn = Integer.parseInt(prnstr);

            String query0 = "SELECT * FROM Grades WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "User does not Exists");
                deleteI8.setText("");
                return;

            }
            rs = stmt.executeQuery(query0);
            rs.next();
            if (prnstr.equals(rs.getString("PRN"))) {
                String query1 = "DELETE FROM Grades WHERE PRN ='" + prn + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();
                JOptionPane.showMessageDialog(rootPane, "User Deleted!");

            }
            deleteI8.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "First Delete the Profile of this User");
            System.out.println(e);
        }
        showB8ActionPerformed(evt);
    }//GEN-LAST:event_deleteB8ActionPerformed

    private void submitBt7_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBt7_3ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prn = Integer.parseInt(prnIt7_3.getText());
            stupassword = new String(passwordIt7_3.getPassword());

            String query0 = "SELECT * FROM Student WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Student does not Exists");
                return;

            }

            String query = "SELECT * FROM Studentlogin WHERE PRN='" + prn + "';";
            rs = stmt.executeQuery(query);
            rs.next();
            if (stupassword.equals(rs.getString("StudentPassword"))) {
                String query1 = "DELETE FROM Studentlogin WHERE PRN='" + prn + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Student Deleted!");
                prnIt7_3.setText("");
                passwordIt7_3.setText("");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Wrong Password!");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Student does not Exists");
        }
    }//GEN-LAST:event_submitBt7_3ActionPerformed

    private void resetBt7_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBt7_3ActionPerformed
        // TODO add your handling code here:
        prnIt7_3.setText("");
        passwordIt7_3.setText("");
    }//GEN-LAST:event_resetBt7_3ActionPerformed

    private void passwordIt7_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordIt7_3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordIt7_3ActionPerformed

    private void prnIt7_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prnIt7_3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prnIt7_3ActionPerformed

    private void resetBt7_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBt7_2ActionPerformed
        // TODO add your handling code here:
        prnIt7_2.setText("");
        passwordIt7_2.setText("");
    }//GEN-LAST:event_resetBt7_2ActionPerformed

    private void submitBt7_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBt7_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prnstr = prnIt7_2.getText();
            stupassword = new String(passwordIt7_2.getPassword());
            //If username or pass is Empty
            if (prnstr.isEmpty() || stupassword.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);
            String query = "SELECT * FROM Student where PRN='" + prn + "'";
            rs = stmt.executeQuery(query);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Add Student Details First !");
                return;
            }

            String query1 = "SELECT * FROM Studentlogin where prn='" + prn + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Studentlogin VALUES('" + prn + "','" + stupassword + "')";
                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Student Added!");
                prnIt7_2.setText("");
                passwordIt7_2.setText("");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Student already Exists !");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitBt7_2ActionPerformed

    private void passwordIt7_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordIt7_2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordIt7_2ActionPerformed

    private void prnIt7_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prnIt7_2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prnIt7_2ActionPerformed

    private void resetBt7_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBt7_1ActionPerformed
        // TODO add your handling code here:
        prnIt7_1.setText("");
        passwordIt7_1.setText("");
        allDetailsstu(jTable7_1);
    }//GEN-LAST:event_resetBt7_1ActionPerformed

    private void hideBt7_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideBt7_1ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable7_1.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideBt7_1ActionPerformed

    private void showBt7_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showBt7_1ActionPerformed
        // TODO add your handling code here:
        allDetailsstu(jTable7_1);

    }//GEN-LAST:event_showBt7_1ActionPerformed

    private void updateBt7_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBt7_1ActionPerformed
        // TODO add your handling code here:
        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable7_1.getModel();
            if (jTable7_1.getSelectedRowCount() == 1) {
                prnstr = prnIt7_1.getText();
                stupassword = passwordIt7_1.getText();

                //If username or pass is Empty
                if (prnstr.isEmpty() || stupassword.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                prn = Integer.parseInt(prnstr);

                String query0 = "SELECT * FROM Studentlogin where PRN='" + prn + "'";
                rs = stmt.executeQuery(query0);
                //If PRN does not exists in Student Table
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(rootPane, "Add Student Details First !");
                    return;
                }

                String query1 = "UPDATE Studentlogin SET StudentPassword = '" + stupassword + "' WHERE PRN = '" + prn + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                allDetailsstu(jTable7_1);

            } else {
                if (jTable7_1.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable7_1.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "User does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_updateBt7_1ActionPerformed

    private void jTable7_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable7_1MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable7_1.getModel();
        prnstr = tb1Model.getValueAt(jTable7_1.getSelectedRow(), 0).toString();
        stupassword = tb1Model.getValueAt(jTable7_1.getSelectedRow(), 1).toString();

        prnIt7_1.setText(prnstr);
        passwordIt7_1.setText(stupassword);
    }//GEN-LAST:event_jTable7_1MouseClicked

    private void prnIt7_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_prnIt7_1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_prnIt7_1MouseClicked

    private void findBt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findBt7ActionPerformed
        // TODO add your handling code here:
        try {
            prnstr = findIt7.getText();

            //If username is Empty
            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            //Empty the table before showing the result
            DefaultTableModel tb1Model = (DefaultTableModel) jTable7.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Studentlogin WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query);

            //Username not found
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "User Not Found");
                allDetailsstu(jTable7);
                return;
            }

            //Refreshing rs
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {

                    stupassword = rs.getString("StudentPassword");
                    String tb1Data[] = {prnstr, stupassword};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable7.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "User does not Exists");
        }
    }//GEN-LAST:event_findBt7ActionPerformed

    private void hideBt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideBt7ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable7.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideBt7ActionPerformed

    private void showBt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showBt7ActionPerformed
        // TODO add your handling code here:
        allDetailsstu(jTable7);
    }//GEN-LAST:event_showBt7ActionPerformed

    private void updateBt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBt7ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(10);
        jTabbedPane2.setSelectedIndex(4);
        allDetailsstu(jTable7_1);
    }//GEN-LAST:event_updateBt7ActionPerformed

    private void addBt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBt7ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(11);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addBt7ActionPerformed

    private void deleteBt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBt7ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(12);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_deleteBt7ActionPerformed

    private void submitBt6_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBt6_3ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            adminid = Integer.parseInt(adminidIt6_3.getText());
            adpassword = new String(passwordIt6_3.getPassword());

            String query0 = "SELECT * FROM Admin WHERE AdminID ='" + adminid + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Admin does not Exists");
                return;

            }
            String query = "SELECT * FROM Adminlogin WHERE AdminID ='" + adminid + "';";
            rs = stmt.executeQuery(query);
            rs.next();
            if (adpassword.equals(rs.getString("AdminPassword"))) {
                String query1 = "DELETE FROM Adminlogin WHERE AdminID ='" + adminid + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Admin Deleted!");
                adminidIt6_3.setText("");
                passwordIt6_3.setText("");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Wrong Password!");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_submitBt6_3ActionPerformed

    private void resetBt6_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBt6_3ActionPerformed
        // TODO add your handling code here:
        adminidIt6_3.setText("");
        passwordIt6_3.setText("");
    }//GEN-LAST:event_resetBt6_3ActionPerformed

    private void passwordIt6_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordIt6_3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordIt6_3ActionPerformed

    private void adminidIt6_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminidIt6_3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminidIt6_3ActionPerformed

    private void passwordIt6_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordIt6_2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordIt6_2ActionPerformed

    private void adminidIt6_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminidIt6_2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminidIt6_2ActionPerformed

    private void resetBt6_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBt6_2ActionPerformed
        // TODO add your handling code here:
        adminidIt6_2.setText("");
        passwordIt6_2.setText("");
    }//GEN-LAST:event_resetBt6_2ActionPerformed

    private void submitBt6_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBt6_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            adminidstr = adminidIt6_2.getText();
            adpassword = new String(passwordIt6_2.getPassword());

            //If username or pass is Empty
            if (adminidstr.isEmpty() || adpassword.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            adminid = Integer.parseInt(adminidstr);
            String query = "SELECT * FROM Admin WHERE AdminID='" + adminid + "'";
            rs = stmt.executeQuery(query);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Add Admin Details First !");
                return;
            }

            String query1 = "SELECT * FROM Adminlogin where AdminID='" + adminid + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Adminlogin VALUES('" + adminid + "','" + adpassword + "')";
                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Admin Added!");
                adminidIt6_2.setText("");
                passwordIt6_2.setText("");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Admin already Exists !");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitBt6_2ActionPerformed

    private void resetBt6_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBt6_1ActionPerformed
        // TODO add your handling code here:
        adminidIt6_1.setText("");
        passwordoldIt6_1.setText("");
        passwordnewIt6_1.setText("");
    }//GEN-LAST:event_resetBt6_1ActionPerformed

    private void submitBt6_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBt6_1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            //            String querybrute = "SET FOREIGN_KEY_CHECKS=0";
            //            PreparedStatement stmtbrute = conn.prepareStatement(querybrute);
            //            stmtbrute.executeUpdate();
            adminidstr = adminidIt6_1.getText();
            adoldpassword = new String(passwordoldIt6_1.getPassword());
            adpassword = new String(passwordnewIt6_1.getPassword());

            //If username or pass is Empty
            if (adminidstr.isEmpty() || adpassword.isEmpty() || adoldpassword.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            adminid = Integer.parseInt(adminidstr);

            String query = "SELECT * FROM Adminlogin WHERE AdminID = '" + adminid + "'";
            rs = stmt.executeQuery(query);
            rs.next();

            if (!adminidstr.equals(rs.getString("AdminID"))) {
                JOptionPane.showMessageDialog(rootPane, "Add Admin Details First !");
                return;
            }
            if (adoldpassword.equals(rs.getString("AdminPassword"))) {
                String query1 = "UPDATE Adminlogin SET AdminPassword = '" + adpassword + "' WHERE AdminID = '" + adminid + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();
                JOptionPane.showMessageDialog(rootPane, "Updated!");
                adminidIt6_1.setText("");
                passwordoldIt6_1.setText("");
                passwordnewIt6_1.setText("");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Wrong Password !");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "User does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitBt6_1ActionPerformed

    private void passwordnewIt6_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordnewIt6_1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordnewIt6_1ActionPerformed

    private void passwordoldIt6_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordoldIt6_1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordoldIt6_1ActionPerformed

    private void adminidIt6_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminidIt6_1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminidIt6_1ActionPerformed

    private void findIt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findIt6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_findIt6ActionPerformed

    private void findBt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findBt6ActionPerformed
        // TODO add your handling code here:

        try {

            adminidstr = findIt6.getText();

            //If username is Empty
            if (adminidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int adminidint = Integer.parseInt(adminidstr);

            //Empty the table before showing the result
            DefaultTableModel tb1Model = (DefaultTableModel) adminTABt6.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Adminlogin WHERE AdminID ='" + adminidint + "';";
            rs = stmt.executeQuery(query);

            //Username not found
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "User Not Found");

                allDetailsadmin(adminTABt6);
                return;
            }

            //Refreshing rs
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (adminidstr.equals(rs.getString("AdminID"))) {

                    adpassword = rs.getString("AdminPassword");

                    String tb1Data[] = {adminidstr, adpassword};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) adminTABt6.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "User does not Exists");
        }
    }//GEN-LAST:event_findBt6ActionPerformed

    private void hideBt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideBt6ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) adminTABt6.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideBt6ActionPerformed

    private void showBt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showBt6ActionPerformed
        // TODO add your handling code here:
        allDetailsadmin(adminTABt6);
    }//GEN-LAST:event_showBt6ActionPerformed

    private void updateBt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBt6ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(6);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_updateBt6ActionPerformed

    private void addBt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBt6ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(7);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addBt6ActionPerformed

    private void deleteBt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBt6ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(8);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_deleteBt6ActionPerformed

    private void resetBt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBt3ActionPerformed
        // TODO add your handling code here:
        adminidIt3.setText("");
        passwordIt3.setText("");
    }//GEN-LAST:event_resetBt3ActionPerformed

    private void submitBt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBt3ActionPerformed
        // TODO add your handling code here:
        try {

            stmt = conn.createStatement();
            adminidstr = adminidIt3.getText();
            adpassword = new String(passwordIt3.getPassword());
            if (adminidstr.isBlank() || adpassword.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something !");
                return;
            }
            adminid = Integer.parseInt(adminidstr);

            String query = "SELECT * FROM Adminlogin WHERE AdminID ='" + adminid + "';";
            rs = stmt.executeQuery(query);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Admin does not Exist !");
                return;
            }
            if (adpassword.equals(rs.getString("AdminPassword"))) {
                jTabbedPane1.setSelectedIndex(4);
                jTabbedPane2.setSelectedIndex(2);
                try {
                    stmt = conn.createStatement();

                    String query1 = "SELECT * FROM Admin";
                    rs = stmt.executeQuery(query1);

                    while (rs.next()) {
                        if (adminidstr.equals(rs.getString("AdminID"))) {
                            String firstname = rs.getString("FirstName");
                            String lastname = rs.getString("LastName");
                            String email = rs.getString("email");
                            adminidI5.setText(adminidstr);
                            firstnameI5.setText(firstname);
                            lastnameI5.setText(lastname);
                            emailI5.setText(email);
                        }
                    }

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Error Occurred");
                    System.out.println(e);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Wrong Password !");
            }
            adminidIt3.setText("");
            passwordIt3.setText("");
        } catch (Exception e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_submitBt3ActionPerformed

    private void passwordIt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordIt3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordIt3ActionPerformed

    private void adminidIt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminidIt3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminidIt3ActionPerformed

    private void resetBt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBt2ActionPerformed
        // TODO add your handling code here:
        prnIt2.setText("");
        passwordIt2.setText("");
    }//GEN-LAST:event_resetBt2ActionPerformed

    private void submitBt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBt2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();
            prnstr = prnIt2.getText();
            stupassword = new String(passwordIt2.getPassword());

            if (prnstr.isBlank() || stupassword.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something !");
                return;
            }
            prn = Integer.parseInt(prnstr);

            String query = "SELECT * FROM Studentlogin WHERE prn ='" + prn + "';";
            rs = stmt.executeQuery(query);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Student does not Exist !");
            }
            //            if(pass.equals(rs.getString(2)))
            if (stupassword.equals(rs.getString("StudentPassword"))) {
                jTabbedPane1.setSelectedIndex(3);
                jTabbedPane2.setSelectedIndex(1);
                try {
                    stmt = conn.createStatement();

                    String query1 = "SELECT * FROM Student s INNER JOIN Phonenumber p ON s.PRN=p.PRN INNER JOIN Branch b ON s.branchid=b.branchid";
                    rs = stmt.executeQuery(query1);
                    while (rs.next()) {
                        if (prnstr.equals(rs.getString("PRN"))) {

                            String firstname = rs.getString("FirstName");
                            String lastname = rs.getString("LastName");
                            String year = rs.getString("Year");
                            String branch = rs.getString("BranchName");
                            String semester = rs.getString("Semester");
                            String dob = rs.getString("DOB");
                            String fathername = rs.getString("FathersName");
                            String email = rs.getString("Email");
                            String phonenumber1 = rs.getString("PhoneNumber1");
                            String phonenumber2 = rs.getString("PhoneNumber2");
                            String address1 = rs.getString("AddressStreetName") + " " + rs.getString("AddressStreetNumber");
                            String address2 = rs.getString("AddressCity") + "  " + rs.getString("AddressState");
                            String address3 = rs.getString("AddressZipCode");

                            prnI4.setText(prnstr);
                            firstnameI4.setText(firstname);
                            lastnameI4.setText(lastname);
                            yearI4.setText(year);
                            branchidI4.setText(branch);
                            semesterI4.setText(semester);
                            dobI4.setText(dob);
                            fathernameI4.setText(fathername);
                            emailI4.setText(email);
                            phonenumber1I4.setText(phonenumber1);
                            phonenumber2I4.setText(phonenumber2);
                            address1I4.setText(address1);
                            address2I4.setText(address2);
                            address3I4.setText(address3);

                        }
                    }

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(rootPane, "Error Occurred");
                    System.out.println(e);
                }

            } else {
                JOptionPane.showMessageDialog(rootPane, "Wrong Password !");
            }
            prnIt2.setText("");
            passwordIt2.setText("");

        } catch (Exception e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_submitBt2ActionPerformed

    private void passwordIt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordIt2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordIt2ActionPerformed

    private void prnIt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prnIt2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prnIt2ActionPerformed

    private void adminBt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminBt1ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
        jTabbedPane2.setSelectedIndex(3);
    }//GEN-LAST:event_adminBt1ActionPerformed

    private void studentBt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentBt1ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
        jTabbedPane2.setSelectedIndex(3);
    }//GEN-LAST:event_studentBt1ActionPerformed

    private void submitB12_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB12_1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prnstr = prnI12_1.getText();
            String paidunpaid = paidunpaidI12_1.getText();
            String fine = fineI12_1.getText();

            if (prnstr.isEmpty() || paidunpaid.isEmpty() || fine.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);
            String query = "SELECT * FROM Student where PRN='" + prn + "'";
            rs = stmt.executeQuery(query);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Add Student Details First !");
                return;
            }

            String query1 = "SELECT * FROM Fees where PRN='" + prn + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                System.out.println(prnstr);
                String query2 = "INSERT INTO Fees VALUES('" + prn + "','" + paidunpaid + "','" + fine + "')";
                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Added!");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Already Exists !");
            }
            prnI12_1.setText("");
            paidunpaidI12_1.setText("");
            fineI12_1.setText("");
            showB12ActionPerformed(evt);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB12_1ActionPerformed

    private void submitB12_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB12_2ActionPerformed
        // TODO add your handling code here:
        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable12_2.getModel();
            if (jTable12_2.getSelectedRowCount() == 1) {
                prnstr = prnI12_2.getText();
                String paidunpaid = paidunpaidI12_2.getText();
                String fine = fineI12_2.getText();

                //If Empty
                if (prnstr.isEmpty() || paidunpaid.isEmpty() || fine.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                prn = Integer.parseInt(prnstr);

                String query0 = "SELECT * FROM Fees where PRN='" + prn + "'";
                rs = stmt.executeQuery(query0);
                //If PRN does not exists in Main Table
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(rootPane, "Add Student Details First !");
                    return;
                }

                String query2 = "UPDATE Fees SET paidunpaid = '" + paidunpaid + "' WHERE PRN = '" + prn + "'";
                PreparedStatement stmt2 = conn.prepareStatement(query2);
                stmt2.executeUpdate();
                String query3 = "UPDATE Fees SET fine = '" + fine + "' WHERE PRN = '" + prn + "'";
                PreparedStatement stmt3 = conn.prepareStatement(query3);
                stmt3.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                showB12_2ActionPerformed(evt);

            } else {
                if (jTable12_2.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable12_2.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
            showB12ActionPerformed(evt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB12_2ActionPerformed

    private void updateB12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateB12ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(29);
        jTabbedPane2.setSelectedIndex(4);
        showB12_2ActionPerformed(evt);
    }//GEN-LAST:event_updateB12ActionPerformed

    private void jTable12_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable12_2MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable12_2.getModel();
        prnstr = tb1Model.getValueAt(jTable12_2.getSelectedRow(), 0).toString();
        String branchid = tb1Model.getValueAt(jTable12_2.getSelectedRow(), 1).toString();
        String paidunpaid = tb1Model.getValueAt(jTable12_2.getSelectedRow(), 2).toString();
        String fine = tb1Model.getValueAt(jTable12_2.getSelectedRow(), 3).toString();

        prnI12_2.setText(prnstr);
        paidunpaidI12_2.setText(paidunpaid);
        fineI12_2.setText(fine);
    }//GEN-LAST:event_jTable12_2MouseClicked

    private void resetB12_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB12_2ActionPerformed
        // TODO add your handling code here:
        prnI12_2.setText("");
        paidunpaidI12_2.setText("");
        fineI12_2.setText("");
        showB12_2ActionPerformed(evt);
    }//GEN-LAST:event_resetB12_2ActionPerformed

    private void hideB12_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB12_2ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable12_2.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB12_2ActionPerformed

    private void showB12_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB12_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Fees";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable12_2.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String prn = rs.getString("PRN");
                String paidunpaid = rs.getString("PaidUnpaid");
                String fine = rs.getString("Fine");
                String tb1Data[] = {prn, paidunpaid, fine};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB12_2ActionPerformed

    private void submitB13_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB13_1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String courseid = courseidI13_1.getText();
            String branchid = branchidI13_1.getText();
            String coursename = coursenameI13_1.getText();
            String duration = durationI13_1.getText();

            if (courseid.isEmpty() || branchid.isEmpty() || coursename.isEmpty() || duration.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int courseidint = Integer.parseInt(courseid);
            int branchidint = Integer.parseInt(branchid);
            String query = "SELECT * FROM Branch where branchid='" + branchid + "'";
            rs = stmt.executeQuery(query);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Add Branch Details First !");
                return;
            }

            String query1 = "SELECT * FROM Course where courseid='" + courseidint + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Course VALUES('" + courseid + "','" + coursename + "','" + duration + "','" + branchid + "')";

                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Added!");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Already Exists !");
            }

            courseidI13_1.setText("");
            branchidI13_1.setText("");
            coursenameI13_1.setText("");
            durationI13_1.setText("");
            showB13ActionPerformed(evt);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB13_1ActionPerformed

    private void updateB13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateB13ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(31);
        jTabbedPane2.setSelectedIndex(4);
        showB13_2ActionPerformed(evt);

    }//GEN-LAST:event_updateB13ActionPerformed

    private void addB13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addB13ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(30);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addB13ActionPerformed

    private void updateB15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateB15ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(43);
        jTabbedPane2.setSelectedIndex(4);
        showB15_2ActionPerformed(evt);
    }//GEN-LAST:event_updateB15ActionPerformed

    private void submitB13_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB13_2ActionPerformed
        // TODO add your handling code here:

        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable13_2.getModel();
            if (jTable13_2.getSelectedRowCount() == 1) {
                String courseid = courseidI13_2.getText();
                String branchid = branchidI13_2.getText();
                String coursename = coursenameI13_2.getText();
                String duration = durationI13_2.getText();

                //If Empty
                if (courseid.isEmpty() || branchid.isEmpty() || coursename.isEmpty() || duration.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                int branchidint = Integer.parseInt(branchid);

                String query0 = "SELECT * FROM Branch where branchid='" + branchidint + "'";
                rs = stmt.executeQuery(query0);
                //If branchid does not exists in Main Table
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(rootPane, "Add Branch Details First !");
                    return;
                }

                String query1 = "UPDATE Course SET coursename = '" + coursename + "' WHERE courseid = '" + courseid + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();
                String query2 = "UPDATE Course SET duration = '" + duration + "' WHERE courseid = '" + courseid + "'";
                PreparedStatement stmt2 = conn.prepareStatement(query2);
                stmt2.executeUpdate();
                String query3 = "UPDATE Course SET branchid = '" + branchid + "' WHERE courseid = '" + courseid + "'";
                PreparedStatement stmt3 = conn.prepareStatement(query3);
                stmt3.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                showB13_2ActionPerformed(evt);

            } else {
                if (jTable13_2.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable13_2.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
            showB13ActionPerformed(evt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB13_2ActionPerformed

    private void hideB13_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB13_2ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable13_2.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB13_2ActionPerformed

    private void showB13_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB13_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Course";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable13_2.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String courseID = rs.getString("CourseID");
                String coursename = rs.getString("CourseName");
                String duration = rs.getString("Duration");
                String branchID = rs.getString("BranchID");
                String tb1Data[] = {courseID, coursename, duration, branchID};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB13_2ActionPerformed

    private void resetB13_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB13_2ActionPerformed
        // TODO add your handling code here:
        courseidI13_2.setText("");
        branchidI13_2.setText("");
        coursenameI13_2.setText("");
        durationI13_2.setText("");
        showB13_2ActionPerformed(evt);
    }//GEN-LAST:event_resetB13_2ActionPerformed

    private void jTable13_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable13_2MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable13_2.getModel();
        String courseid = tb1Model.getValueAt(jTable13_2.getSelectedRow(), 0).toString();
        String coursename = tb1Model.getValueAt(jTable13_2.getSelectedRow(), 1).toString();
        String duration = tb1Model.getValueAt(jTable13_2.getSelectedRow(), 2).toString();
        String branchid = tb1Model.getValueAt(jTable13_2.getSelectedRow(), 3).toString();

        courseidI13_2.setText(courseid);
        branchidI13_2.setText(branchid);
        coursenameI13_2.setText(coursename);
        durationI13_2.setText(duration);
    }//GEN-LAST:event_jTable13_2MouseClicked

    private void submitB8_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB8_1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prnstr = prnI8_1.getText();
            String endsem = endsemI8_1.getText();
            String midsem = midsemI8_1.getText();

            if (prnstr.isEmpty() || endsem.isEmpty() || midsem.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);
            String query = "SELECT * FROM Student where prn='" + prn + "'";
            rs = stmt.executeQuery(query);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Add Student Details First !");
                return;
            }

            String query1 = "SELECT * FROM Grades where prn='" + prn + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Grades VALUES('" + prn + "','" + midsem + "','" + endsem + "')";

                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Added!");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Already Exists !");
            }
            prnI8_1.setText("");
            midsemI8_1.setText("");
            endsemI8_1.setText("");

            showB8ActionPerformed(evt);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB8_1ActionPerformed

    private void resetB13_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB13_1ActionPerformed
        // TODO add your handling code here:
        courseidI13_1.setText("");
        branchidI13_1.setText("");
        coursenameI13_1.setText("");
        durationI13_1.setText("");
    }//GEN-LAST:event_resetB13_1ActionPerformed

    private void resetB12_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB12_1ActionPerformed
        // TODO add your handling code here:
        prnI12_1.setText("");
        paidunpaidI12_1.setText("");
        fineI12_1.setText("");

    }//GEN-LAST:event_resetB12_1ActionPerformed

    private void resetB8_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB8_1ActionPerformed
        // TODO add your handling code here:
        prnI8_1.setText("");
        endsemI8_1.setText("");
        midsemI8_1.setText("");
    }//GEN-LAST:event_resetB8_1ActionPerformed

    private void submitB8_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB8_2ActionPerformed
        // TODO add your handling code here:
        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable8_2.getModel();
            if (jTable8_2.getSelectedRowCount() == 1) {
                prnstr = prnI8_2.getText();
                String midsem = midsemI8_2.getText();
                String endsem = endsemI8_2.getText();

                //If Empty
                if (prnstr.isEmpty() || midsem.isEmpty() || endsem.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                prn = Integer.parseInt(prnstr);

                String query0 = "SELECT * FROM Student where prn='" + prn + "'";
                rs = stmt.executeQuery(query0);
                //If branchid does not exists in Main Table
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(rootPane, "Add Student Details First !");
                    return;
                }

                String query1 = "UPDATE Grades SET midsem = '" + midsem + "' WHERE prn = '" + prn + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();
                String query2 = "UPDATE Grades SET endsem = '" + endsem + "' WHERE prn = '" + prn + "'";
                PreparedStatement stmt2 = conn.prepareStatement(query2);
                stmt2.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                showB8_2ActionPerformed(evt);

            } else {
                if (jTable8_2.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable8_2.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
            showB8ActionPerformed(evt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB8_2ActionPerformed

    private void resetB8_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB8_2ActionPerformed
        // TODO add your handling code here:
        prnI8_2.setText("");
        midsemI8_2.setText("");
        endsemI8_2.setText("");
        showB8_2ActionPerformed(evt);
    }//GEN-LAST:event_resetB8_2ActionPerformed

    private void hideB8_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB8_2ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable8_2.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB8_2ActionPerformed

    private void showB8_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB8_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Grades";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable8_2.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String prn = rs.getString("PRN");
                String midsem = rs.getString("MidSem");
                String endsem = rs.getString("EndSem");
                String tb1Data[] = {prn, midsem, endsem};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB8_2ActionPerformed

    private void jTable8_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable8_2MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable8_2.getModel();
        prnstr = tb1Model.getValueAt(jTable8_2.getSelectedRow(), 0).toString();
        String midsem = tb1Model.getValueAt(jTable8_2.getSelectedRow(), 1).toString();
        String endsem = tb1Model.getValueAt(jTable8_2.getSelectedRow(), 2).toString();

        prnI8_2.setText(prnstr);
        midsemI8_2.setText(midsem);
        endsemI8_2.setText(endsem);
    }//GEN-LAST:event_jTable8_2MouseClicked

    private void addB8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addB8ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(32);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addB8ActionPerformed

    private void updateB8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateB8ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(33);
        jTabbedPane2.setSelectedIndex(4);
        showB8_2ActionPerformed(evt);
    }//GEN-LAST:event_updateB8ActionPerformed

    private void submitB9_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB9_1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String facultyid = facultyidI9_1.getText();
            String facultyname = facultynameI9_1.getText();
            String branchid = branchidI9_1.getText();

            if (facultyid.isEmpty() || facultyname.isEmpty() || branchid.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int facultyidint = Integer.parseInt(facultyid);
            int branchidint = Integer.parseInt(branchid);
            String query = "SELECT * FROM Branch where branchid='" + branchidint + "'";
            rs = stmt.executeQuery(query);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Add Branch Details First !");
                return;
            }

            String query1 = "SELECT * FROM Faculty where facultyid='" + facultyid + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Faculty VALUES('" + facultyidint + "','" + facultyname + "','" + branchidint + "')";

                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Added!");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Already Exists !");
            }
            facultyidI9_1.setText("");
            facultynameI9_1.setText("");
            branchidI9_1.setText("");
            showB9ActionPerformed(evt);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB9_1ActionPerformed

    private void resetB9_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB9_1ActionPerformed
        // TODO add your handling code here:
        facultyidI9_1.setText("");
        facultynameI9_1.setText("");
        branchidI9_1.setText("");
    }//GEN-LAST:event_resetB9_1ActionPerformed

    private void submitB9_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB9_2ActionPerformed
        // TODO add your handling code here:
        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable9_2.getModel();
            if (jTable9_2.getSelectedRowCount() == 1) {
                String facultyid = facultyidI9_2.getText();
                String facultyname = facultynameI9_2.getText();
                String branchid = branchidI9_2.getText();

                //If Empty
                if (facultyid.isEmpty() || facultyname.isEmpty() || branchid.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                int facultyidint = Integer.parseInt(facultyid);
                int branchidint = Integer.parseInt(branchid);

                String query0 = "SELECT * FROM Branch where branchid='" + branchidint + "'";
                rs = stmt.executeQuery(query0);
                //If branchid does not exists in Main Table
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(rootPane, "Add Branch Details First !");
                    return;
                }

                String query1 = "UPDATE Faculty SET facultyname = '" + facultyname + "' WHERE facultyid = '" + facultyidint + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();
                String query2 = "UPDATE Faculty SET branchid = '" + branchidint + "' WHERE facultyid = '" + facultyidint + "'";
                PreparedStatement stmt2 = conn.prepareStatement(query2);
                stmt2.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                showB9_2ActionPerformed(evt);

            } else {
                if (jTable9_2.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable9_2.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
            showB9ActionPerformed(evt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB9_2ActionPerformed

    private void resetB9_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB9_2ActionPerformed
        // TODO add your handling code here:
        facultyidI9_2.setText("");
        facultynameI9_2.setText("");
        branchidI9_2.setText("");
        showB9_2ActionPerformed(evt);
    }//GEN-LAST:event_resetB9_2ActionPerformed

    private void hideB9_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB9_2ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable9_2.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB9_2ActionPerformed

    private void showB9_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB9_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Faculty";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable9_2.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String facultyid = rs.getString("FacultyID");
                String facultyname = rs.getString("FacultyName");
                String branchid = rs.getString("branchID");
                String tb1Data[] = {facultyid, facultyname, branchid};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB9_2ActionPerformed

    private void jTable9_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable9_2MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable9_2.getModel();
        String facultyid = tb1Model.getValueAt(jTable9_2.getSelectedRow(), 0).toString();
        String facultyname = tb1Model.getValueAt(jTable9_2.getSelectedRow(), 1).toString();
        String branchid = tb1Model.getValueAt(jTable9_2.getSelectedRow(), 2).toString();

        facultyidI9_2.setText(facultyid);
        facultynameI9_2.setText(facultyname);
        branchidI9_2.setText(branchid);
    }//GEN-LAST:event_jTable9_2MouseClicked

    private void addB9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addB9ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(34);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addB9ActionPerformed

    private void updateB9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateB9ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(35);
        jTabbedPane2.setSelectedIndex(4);
        showB9_2ActionPerformed(evt);
    }//GEN-LAST:event_updateB9ActionPerformed

    private void submitB10_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB10_1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prnstr = prnI10_1.getText();
            String percentage = percentageI10_1.getText();
            String date = dateI10_1.getText();

            if (prnstr.isEmpty() || percentage.isEmpty() || date.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);
            String query = "SELECT * FROM Student where prn='" + prn + "'";
            rs = stmt.executeQuery(query);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Add Student Details First !");
                return;
            }

            String query1 = "SELECT * FROM Attendance where prn='" + prn + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Attendance VALUES('" + prn + "','" + percentage + "','" + date + "')";

                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Added!");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Already Exists !");
            }
            prnI10_1.setText("");
            percentageI10_1.setText("");
            dateI10_1.setText("");
            showB10ActionPerformed(evt);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB10_1ActionPerformed

    private void resetB10_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB10_1ActionPerformed
        // TODO add your handling code here:
        prnI10_1.setText("");
        percentageI10_1.setText("");
        dateI10_1.setText("");
    }//GEN-LAST:event_resetB10_1ActionPerformed

    private void submitB10_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB10_2ActionPerformed
        // TODO add your handling code here:
        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable10_2.getModel();
            if (jTable10_2.getSelectedRowCount() == 1) {
                prnstr = prnI10_2.getText();
                String percentage = percentageI10_2.getText();
                String date = dateI10_2.getText();

                //If Empty
                if (prnstr.isEmpty() || percentage.isEmpty() || date.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                prn = Integer.parseInt(prnstr);

                String query0 = "SELECT * FROM Student where prn='" + prn + "'";
                rs = stmt.executeQuery(query0);
                //If prn does not exists in Main Table
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(rootPane, "Add Student Details First !");
                    return;
                }

                String query1 = "UPDATE Attendance SET percentage = '" + percentage + "' WHERE prn = '" + prn + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();
                String query2 = "UPDATE Attendance SET date1 = '" + date + "' WHERE prn = '" + prn + "'";
                PreparedStatement stmt2 = conn.prepareStatement(query2);
                stmt2.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                showB10_2ActionPerformed(evt);

            } else {
                if (jTable10_2.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable10_2.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
            showB10ActionPerformed(evt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB10_2ActionPerformed

    private void resetB10_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB10_2ActionPerformed
        // TODO add your handling code here:
        prnI10_2.setText("");
        dateI10_2.setText("");
        percentageI10_2.setText("");
        showB10_2ActionPerformed(evt);
    }//GEN-LAST:event_resetB10_2ActionPerformed

    private void hideB10_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB10_2ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable10_2.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB10_2ActionPerformed

    private void showB10_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB10_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Attendance";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable10_2.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String prn = rs.getString("PRN");
                String percentage = rs.getString("Percentage");
                String date = rs.getString("Date1");
                String tb1Data[] = {prn, percentage, date};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB10_2ActionPerformed

    private void jTable10_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable10_2MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable10_2.getModel();
        prnstr = tb1Model.getValueAt(jTable10_2.getSelectedRow(), 0).toString();
        String percentage = tb1Model.getValueAt(jTable10_2.getSelectedRow(), 1).toString();
        String date = tb1Model.getValueAt(jTable10_2.getSelectedRow(), 2).toString();

        prnI10_2.setText(prnstr);
        percentageI10_2.setText(percentage);
        dateI10_2.setText(date);
    }//GEN-LAST:event_jTable10_2MouseClicked

    private void updateB10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateB10ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(37);
        jTabbedPane2.setSelectedIndex(4);
        showB10_2ActionPerformed(evt);
    }//GEN-LAST:event_updateB10ActionPerformed

    private void submitB11_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB11_1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String libraryid = libraryidI11_1.getText();
            String category = categoryI11_1.getText();
            String issuedate = issuedateI11_1.getText();
            String returndate = returndateI11_1.getText();

            if (libraryid.isEmpty() || category.isEmpty() || issuedate.isEmpty() || returndate.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int libraryidint = Integer.parseInt(libraryid);

            String query1 = "SELECT * FROM Library where libraryid='" + libraryidint + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Library VALUES('" + libraryidint + "','" + category + "','" + issuedate + "','" + returndate + "')";

                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Added!");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Already Exists !");
            }
            libraryidI11_1.setText("");
            categoryI11_1.setText("");
            issuedateI11_1.setText("");
            returndateI11_1.setText("");
            showB11ActionPerformed(evt);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB11_1ActionPerformed

    private void resetB11_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB11_1ActionPerformed
        // TODO add your handling code here:
        libraryidI11_1.setText("");
        categoryI11_1.setText("");
        issuedateI11_1.setText("");
        returndateI11_1.setText("");
    }//GEN-LAST:event_resetB11_1ActionPerformed

    private void submitB11_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB11_2ActionPerformed
        // TODO add your handling code here:
        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable11_2.getModel();
            if (jTable11_2.getSelectedRowCount() == 1) {
                String libraryid = libraryidI11_2.getText();
                String category = categoryI11_2.getText();
                String issuedate = issuedateI11_2.getText();
                String returndate = returndateI11_2.getText();

                //If Empty
                if (libraryid.isEmpty() || category.isEmpty() || issuedate.isEmpty() || returndate.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                int libraryidint = Integer.parseInt(libraryid);

                String query1 = "UPDATE Library SET category = '" + category + "' WHERE libraryid = '" + libraryidint + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();
                String query2 = "UPDATE Library SET issue = '" + issuedate + "' WHERE libraryid = '" + libraryidint + "'";
                PreparedStatement stmt2 = conn.prepareStatement(query2);
                stmt2.executeUpdate();
                String query3 = "UPDATE Library SET return1 = '" + returndate + "' WHERE libraryid = '" + libraryidint + "'";
                PreparedStatement stmt3 = conn.prepareStatement(query3);
                stmt3.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                showB11_2ActionPerformed(evt);

            } else {
                if (jTable11_2.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable11_2.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
            showB11ActionPerformed(evt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB11_2ActionPerformed

    private void resetB11_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB11_2ActionPerformed
        // TODO add your handling code here:
        libraryidI11_2.setText("");
        issuedateI11_2.setText("");
        returndateI11_2.setText("");
        categoryI11_2.setText("");
        showB11_2ActionPerformed(evt);
    }//GEN-LAST:event_resetB11_2ActionPerformed

    private void hideB11_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB11_2ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable11_2.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB11_2ActionPerformed

    private void showB11_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB11_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Library";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable11_2.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String libid = rs.getString("LibraryID");
                String category = rs.getString("Category");
                String issuedate = rs.getString("Issue");
                String returndate = rs.getString("Return1");
                String tb1Data[] = {libid, category, issuedate, returndate};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB11_2ActionPerformed

    private void jTable11_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable11_2MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable11_2.getModel();
        String libraryid = tb1Model.getValueAt(jTable11_2.getSelectedRow(), 0).toString();
        String category = tb1Model.getValueAt(jTable11_2.getSelectedRow(), 1).toString();
        String issuedate = tb1Model.getValueAt(jTable11_2.getSelectedRow(), 2).toString();
        String returndate = tb1Model.getValueAt(jTable11_2.getSelectedRow(), 3).toString();

        libraryidI11_2.setText(libraryid);
        categoryI11_2.setText(category);
        issuedateI11_2.setText(issuedate);
        returndateI11_2.setText(returndate);
    }//GEN-LAST:event_jTable11_2MouseClicked

    private void addB11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addB11ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(38);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addB11ActionPerformed

    private void updateB11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateB11ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(39);
        jTabbedPane2.setSelectedIndex(4);
        showB11_2ActionPerformed(evt);
    }//GEN-LAST:event_updateB11ActionPerformed

    private void submitB14_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB14_1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prnstr = prnI14_1.getText();
            String gender = genderI14_1.getText();
            String simpleroom = simpleroomI14_1.getText();
            String luxuryroom = luxuryroomI14_1.getText();

            if (prnstr.isEmpty() || gender.isEmpty() || simpleroom.isEmpty() || luxuryroom.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);
            String query = "SELECT * FROM Student where prn='" + prn + "'";
            rs = stmt.executeQuery(query);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Add Student Details First !");
                return;
            }

            String query1 = "SELECT * FROM Hostel where prn='" + prn + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Hostel VALUES('" + prn + "','" + gender + "','" + simpleroom + "','" + luxuryroom + "')";

                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Added!");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Already Exists !");
            }
            prnI14_1.setText("");
            genderI14_1.setText("");
            simpleroomI14_1.setText("");
            luxuryroomI14_1.setText("");
            showB14ActionPerformed(evt);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB14_1ActionPerformed

    private void resetB14_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB14_1ActionPerformed
        // TODO add your handling code here:
        prnI14_1.setText("");
        genderI14_1.setText("");
        simpleroomI14_1.setText("");
        luxuryroomI14_1.setText("");
    }//GEN-LAST:event_resetB14_1ActionPerformed

    private void submitB14_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB14_2ActionPerformed
        // TODO add your handling code here:
        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable14_2.getModel();
            if (jTable14_2.getSelectedRowCount() == 1) {
                prnstr = prnI14_2.getText();
                String gender = genderI14_2.getText();
                String simpleroom = simpleroomI14_2.getText();
                String luxuryroom = luxuryroomI14_2.getText();

                //If Empty
                if (prnstr.isEmpty() || gender.isEmpty() || simpleroom.isEmpty() || luxuryroom.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                prn = Integer.parseInt(prnstr);

                String query0 = "SELECT * FROM Student where prn='" + prn + "'";
                rs = stmt.executeQuery(query0);
                //If prn does not exists in Main Table
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(rootPane, "Add Student Details First !");
                    return;
                }

                String query1 = "UPDATE Hostel SET gender = '" + gender + "' WHERE prn = '" + prn + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();
                String query2 = "UPDATE Hostel SET simpleroom = '" + simpleroom + "' WHERE prn = '" + prn + "'";
                PreparedStatement stmt2 = conn.prepareStatement(query2);
                stmt2.executeUpdate();
                String query3 = "UPDATE Hostel SET luxuryroom = '" + luxuryroom + "' WHERE prn = '" + prn + "'";
                PreparedStatement stmt3 = conn.prepareStatement(query3);
                stmt3.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                showB14_2ActionPerformed(evt);

            } else {
                if (jTable14_2.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable14_2.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
            showB14ActionPerformed(evt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB14_2ActionPerformed

    private void resetB14_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB14_2ActionPerformed
        // TODO add your handling code here:
        prnI14_2.setText("");
        genderI14_2.setText("");
        simpleroomI14_2.setText("");
        luxuryroomI14_2.setText("");
        showB14_2ActionPerformed(evt);
    }//GEN-LAST:event_resetB14_2ActionPerformed

    private void hideB14_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB14_2ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable14_2.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB14_2ActionPerformed

    private void showB14_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB14_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Hostel";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable14_2.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String prn = rs.getString("PRN");
                String gender = rs.getString("Gender");
                String simpleroom = rs.getString("SimpleRoom");
                String luxuryroom = rs.getString("LuxuryRoom");
                String tb1Data[] = {prn, gender, simpleroom, luxuryroom};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB14_2ActionPerformed

    private void jTable14_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable14_2MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable14_2.getModel();
        prnstr = tb1Model.getValueAt(jTable14_2.getSelectedRow(), 0).toString();
        String gender = tb1Model.getValueAt(jTable14_2.getSelectedRow(), 1).toString();
        String simpleroom = tb1Model.getValueAt(jTable14_2.getSelectedRow(), 2).toString();
        String luxuryroom = tb1Model.getValueAt(jTable14_2.getSelectedRow(), 3).toString();

        prnI14_2.setText(prnstr);
        genderI14_2.setText(gender);
        simpleroomI14_2.setText(simpleroom);
        luxuryroomI14_2.setText(luxuryroom);
    }//GEN-LAST:event_jTable14_2MouseClicked

    private void addB14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addB14ActionPerformed
        // TODO add your handling code here:'
        jTabbedPane1.setSelectedIndex(40);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addB14ActionPerformed

    private void updateB14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateB14ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(41);
        jTabbedPane2.setSelectedIndex(4);
        showB14_2ActionPerformed(evt);
    }//GEN-LAST:event_updateB14ActionPerformed

    private void submitB15_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB15_1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String timetableid = timetableidI15_1.getText();
            String courseid = courseidI15_1.getText();
            String facultyid = facultyidI15_1.getText();
            String roomnumber = roomnumberI15_1.getText();
            String timings = timingsI15_1.getText();

            if (timetableid.isEmpty() || courseid.isEmpty() || facultyid.isEmpty() || roomnumber.isEmpty() || timings.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int timetableidint = Integer.parseInt(timetableid);
            int courseidint = Integer.parseInt(courseid);
            int facultyidint = Integer.parseInt(facultyid);
            String query0 = "SELECT * FROM Course where courseid='" + courseidint + "'";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Add Course Details First !");
                return;
            }
            String query = "SELECT * FROM Faculty where facultyid='" + facultyidint + "'";
            rs = stmt.executeQuery(query);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Add Faculty Details First !");
                return;
            }

            String query1 = "SELECT * FROM Timetable where timetableid='" + timetableidint + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Timetable VALUES('" + timetableidint + "','" + courseidint + "','" + facultyidint + "','" + roomnumber + "','" + timings + "')";

                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Added!");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Already Exists !");
            }
            timetableidI15_1.setText("");
            courseidI15_1.setText("");
            facultyidI15_1.setText("");
            roomnumberI15_1.setText("");
            timingsI15_1.setText("");
            showB15ActionPerformed(evt);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB15_1ActionPerformed

    private void resetB15_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB15_1ActionPerformed
        // TODO add your handling code here:
        timetableidI15_1.setText("");
        courseidI15_1.setText("");
        facultyidI15_1.setText("");
        roomnumberI15_1.setText("");
        timingsI15_1.setText("");
    }//GEN-LAST:event_resetB15_1ActionPerformed

    private void submitB15_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB15_2ActionPerformed
        // TODO add your handling code here:
        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable15_2.getModel();
            if (jTable15_2.getSelectedRowCount() == 1) {
                String timetableid = timetableidI15_2.getText();
                String courseid = courseidI15_2.getText();
                String facultyid = facultyidI15_2.getText();
                String roomnumber = roomnumberI15_2.getText();
                String timings = timingsI15_2.getText();

                //If Empty
                if (timetableid.isEmpty() || courseid.isEmpty() || facultyid.isEmpty() || roomnumber.isEmpty() || timings.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                int timetableidint = Integer.parseInt(timetableid);
                int courseidint = Integer.parseInt(courseid);
                int facultyidint = Integer.parseInt(facultyid);

                String query0 = "SELECT * FROM Course where courseid='" + courseidint + "'";
                rs = stmt.executeQuery(query0);
                //If cousrse does not exists in Main Table
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(rootPane, "Add Course Details First !");
                    return;
                }
                String query = "SELECT * FROM Faculty where facultyid='" + facultyidint + "'";
                rs = stmt.executeQuery(query);
                //If faculty does not exists in Main Table
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(rootPane, "Add Faculty Details First !");
                    return;
                }

                String query1 = "UPDATE Timetable SET courseid = '" + courseidint + "' WHERE timetableid = '" + timetableidint + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();
                String query2 = "UPDATE Timetable SET facultyid = '" + facultyid + "' WHERE timetableid = '" + timetableidint + "'";
                PreparedStatement stmt2 = conn.prepareStatement(query2);
                stmt2.executeUpdate();
                String query3 = "UPDATE Timetable SET roomnumber = '" + roomnumber + "' WHERE timetableid = '" + timetableidint + "'";
                PreparedStatement stmt3 = conn.prepareStatement(query3);
                stmt3.executeUpdate();
                String query4 = "UPDATE Timetable SET timing = '" + timings + "' WHERE timetableid = '" + timetableidint + "'";
                PreparedStatement stmt4 = conn.prepareStatement(query4);
                stmt4.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                showB15_2ActionPerformed(evt);

            } else {
                if (jTable15_2.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable15_2.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
            showB15ActionPerformed(evt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB15_2ActionPerformed

    private void resetB15_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB15_2ActionPerformed
        // TODO add your handling code here:
        timetableidI15_2.setText("");
        courseidI15_2.setText("");
        facultyidI15_2.setText("");
        roomnumberI15_2.setText("");
        timingsI15_2.setText("");
        showB15_2ActionPerformed(evt);
    }//GEN-LAST:event_resetB15_2ActionPerformed

    private void showB15_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB15_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Timetable";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable15_2.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String timetableid = rs.getString("TimetableID");
                String courseid = rs.getString("CourseID");
                String facultyid = rs.getString("FacultyID");
                String roomnumber = rs.getString("RoomNumber");
                String timing = rs.getString("Timing");
                String tb1Data[] = {timetableid, courseid, facultyid, roomnumber, timing};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB15_2ActionPerformed

    private void hideB15_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB15_2ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable15_2.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB15_2ActionPerformed

    private void jTable15_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable15_2MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable15_2.getModel();
        String timetableid = tb1Model.getValueAt(jTable15_2.getSelectedRow(), 0).toString();
        String courseid = tb1Model.getValueAt(jTable15_2.getSelectedRow(), 1).toString();
        String facultyid = tb1Model.getValueAt(jTable15_2.getSelectedRow(), 2).toString();
        String roomnumber = tb1Model.getValueAt(jTable15_2.getSelectedRow(), 3).toString();
        String timings = tb1Model.getValueAt(jTable15_2.getSelectedRow(), 4).toString();

        timetableidI15_2.setText(timetableid);
        courseidI15_2.setText(courseid);
        facultyidI15_2.setText(facultyid);
        roomnumberI15_2.setText(roomnumber);
        timingsI15_2.setText(timings);
    }//GEN-LAST:event_jTable15_2MouseClicked

    private void addB15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addB15ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(42);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addB15ActionPerformed

    private void addB23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addB23ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(47);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addB23ActionPerformed

    private void updateB23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateB23ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(48);
        jTabbedPane2.setSelectedIndex(4);
        showB23_2ActionPerformed(evt);
    }//GEN-LAST:event_updateB23ActionPerformed

    private void deleteB23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteB23ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String branchidstr = deleteI23.getText();
            if (branchidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something!");
                return;
            }
            int branchid = Integer.parseInt(branchidstr);

            String query0 = "SELECT * FROM Branch WHERE branchid ='" + branchid + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Does not Exists");
                deleteI23.setText("");
                return;

            }
            rs = stmt.executeQuery(query0);
            rs.next();
            if (branchidstr.equals(rs.getString("branchid"))) {
                String query1 = "DELETE FROM Branch WHERE branchid ='" + branchid + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Deleted!");
            }
            deleteI23.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "First Delete the entry from Student, Timetable, Faculty and Course Table");
            System.out.println(e);
        }

        showB23ActionPerformed(evt);
    }//GEN-LAST:event_deleteB23ActionPerformed

    private void showB23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB23ActionPerformed
        // TODO add your handling code here:

        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Branch";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable23.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String branchid = rs.getString("BranchID");
                String branchname = rs.getString("BranchName");
                String tb1Data[] = {branchid, branchname};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB23ActionPerformed

    private void hideB23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB23ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable23.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB23ActionPerformed

    private void findB23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB23ActionPerformed
        // TODO add your handling code here:
        try {

            String branchidstr = findI23.getText();

            if (branchidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int branchid = Integer.parseInt(branchidstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable23.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Branch WHERE branchid ='" + branchid + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB23ActionPerformed(evt);
                findI23.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (branchidstr.equals(rs.getString("branchid"))) {
                    String branchname = rs.getString("branchName");
                    String tb1Data[] = {branchidstr, branchname};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable23.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }
            findI23.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB23ActionPerformed

    private void deleteI23FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_deleteI23FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteI23FocusGained

    private void deleteI23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteI23ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteI23ActionPerformed

    private void addB24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addB24ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(51);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addB24ActionPerformed

    private void updateB24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateB24ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(52);
        jTabbedPane2.setSelectedIndex(4);
        showB24_2ActionPerformed(evt);
    }//GEN-LAST:event_updateB24ActionPerformed

    private void deleteB24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteB24ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prnstr = deleteI24.getText();
            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something!");
                return;
            }
            prn = Integer.parseInt(prnstr);

            String query0 = "SELECT * FROM Student where prn ='" + prn + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Does not Exists");
                deleteI24.setText("");
                return;

            }
            rs = stmt.executeQuery(query0);
            rs.next();
            if (prnstr.equals(rs.getString("prn"))) {

                String query1 = "DELETE FROM Phonenumber WHERE prn ='" + prn + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                String query2 = "DELETE FROM Attendance WHERE prn ='" + prn + "';";
                PreparedStatement stmt2 = conn.prepareStatement(query2);
                stmt2.executeUpdate();

                String query3 = "DELETE FROM Fees WHERE prn ='" + prn + "';";
                PreparedStatement stmt3 = conn.prepareStatement(query3);
                stmt3.executeUpdate();

                String query4 = "DELETE FROM Grades WHERE prn ='" + prn + "';";
                PreparedStatement stmt4 = conn.prepareStatement(query4);
                stmt4.executeUpdate();

                String query5 = "DELETE FROM Hostel WHERE prn ='" + prn + "';";
                PreparedStatement stmt5 = conn.prepareStatement(query5);
                stmt5.executeUpdate();

                String query7 = "DELETE FROM Studentlogin WHERE prn ='" + prn + "';";
                PreparedStatement stmt7 = conn.prepareStatement(query7);
                stmt7.executeUpdate();

                String query6 = "DELETE FROM Student WHERE prn ='" + prn + "';";
                PreparedStatement stmt6 = conn.prepareStatement(query6);
                stmt6.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Deleted!");
            }
            deleteI24.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "First Delete the entry from Parent Table");
            System.out.println(e);
        }

        showB24ActionPerformed(evt);
    }//GEN-LAST:event_deleteB24ActionPerformed

    private void showB24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB24ActionPerformed
        // TODO add your handling code here:

        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Student s LEFT JOIN Phonenumber p ON s.PRN=p.PRN";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable24.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                prnstr = rs.getString("PRN");
                String firstname = rs.getString("FirstName");
                String lastname = rs.getString("lastname");
                String year = rs.getString("Year");
                String branchid = rs.getString("Branchid");
                String semester = rs.getString("Semester");
                String dob = rs.getString("DOB");
                String fathersname = rs.getString("Fathersname");
                String email = rs.getString("Email");
                String streetname = rs.getString("AddressStreetName");
                String streetnumber = rs.getString("AddressStreetNumber");
                String zipcode = rs.getString("AddressZipCode");
                String state = rs.getString("AddressState");
                String city = rs.getString("AddressCity");
                String p1 = rs.getString("PhoneNumber1");
                String p2 = rs.getString("PhoneNumber2");

                String tb1Data[] = {prnstr, firstname, lastname, year, branchid, semester, dob, fathersname, email, streetname, streetnumber, zipcode, state, city, p1, p2};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB24ActionPerformed

    private void hideB24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB24ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable24.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB24ActionPerformed

    private void findB24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB24ActionPerformed
        // TODO add your handling code here:
        try {

            prnstr = findI24.getText();

            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable24.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Student s LEFT JOIN Phonenumber p ON s.prn=p.prn WHERE s.prn ='" + prn + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB24ActionPerformed(evt);
                findI24.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (prnstr.equals(rs.getString("prn"))) {
                    String firstname = rs.getString("FirstName");
                    String lastname = rs.getString("LastName");
                    String year = rs.getString("Year");
                    String branchid = rs.getString("BranchId");
                    String semester = rs.getString("Semester");
                    String dob = rs.getString("DOB");
                    String fathersname = rs.getString("FathersName");
                    String email = rs.getString("Email");
                    String addressstreetname = rs.getString("AddressStreetName");
                    String addressstreetnumber = rs.getString("AddressStreetNumber");
                    String addresszipcode = rs.getString("AddressZipcode");
                    String addressstate = rs.getString("AddressState");
                    String addresscity = rs.getString("AddressCity");
                    String p1 = rs.getString("Phonenumber1");
                    String p2 = rs.getString("Phonenumber2");
                    String tb1Data[] = {prnstr, firstname, lastname, year, branchid, semester, dob, fathersname, email, addressstreetname, addressstreetnumber, addresszipcode, addressstate, addresscity, p1, p2};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable24.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }
            findI24.setText("");

        } catch (Exception e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB24ActionPerformed

    private void deleteI24FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_deleteI24FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteI24FocusGained

    private void deleteI24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteI24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteI24ActionPerformed

    private void addB25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addB25ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(49);
        jTabbedPane2.setSelectedIndex(4);
    }//GEN-LAST:event_addB25ActionPerformed

    private void updateB25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateB25ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(50);
        jTabbedPane2.setSelectedIndex(4);
        showB25_2ActionPerformed(evt);
    }//GEN-LAST:event_updateB25ActionPerformed

    private void deleteB25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteB25ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            adminidstr = deleteI25.getText();
            if (adminidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something!");
                return;
            }
            adminid = Integer.parseInt(adminidstr);

            String query0 = "SELECT * FROM Admin WHERE adminid ='" + adminid + "';";
            rs = stmt.executeQuery(query0);
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Does not Exists");
                deleteI25.setText("");
                return;

            }
            rs = stmt.executeQuery(query0);
            rs.next();
            if (adminidstr.equals(rs.getString("adminid"))) {
                String query1 = "DELETE FROM Admin WHERE adminid ='" + adminid + "';";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Deleted!");
            }
            deleteI25.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "First Delete the entry from Parent Table");
            System.out.println(e);
        }

        showB25ActionPerformed(evt);
    }//GEN-LAST:event_deleteB25ActionPerformed

    private void showB25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB25ActionPerformed
        // TODO add your handling code here:

        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Admin";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable25.getModel();
            tb1Model.setRowCount(0);
            while (rs.next()) {
                String adminidstrall = rs.getString("Adminid");
                String firstname = rs.getString("firstname");
                String lastname = rs.getString("lastname");
                String email = rs.getString("email");
                String tb1Data[] = {adminidstrall, firstname, lastname, email};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB25ActionPerformed

    private void hideB25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB25ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable25.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB25ActionPerformed

    private void findB25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB25ActionPerformed
        // TODO add your handling code here:
        try {

            String adminidstr = findI25.getText();

            if (adminidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int adminid = Integer.parseInt(adminidstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable25.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Admin WHERE adminid ='" + adminid + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB25ActionPerformed(evt);
                findI25.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (adminidstr.equals(rs.getString("adminid"))) {
                    String firstname = rs.getString("firstName");
                    String lastname = rs.getString("lastName");
                    String email = rs.getString("Email");
                    String tb1Data[] = {adminidstr, firstname, lastname, email};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable25.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }
            findI25.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB25ActionPerformed

    private void deleteI25FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_deleteI25FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteI25FocusGained

    private void deleteI25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteI25ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteI25ActionPerformed

    private void admindetailsBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_admindetailsBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(46);
        showB25ActionPerformed(evt);
    }//GEN-LAST:event_admindetailsBst3ActionPerformed

    private void studentdetailsBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentdetailsBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(45);
        showB24ActionPerformed(evt);
    }//GEN-LAST:event_studentdetailsBst3ActionPerformed

    private void branchBst3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_branchBst3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(44);
        showB23ActionPerformed(evt);
    }//GEN-LAST:event_branchBst3ActionPerformed

    private void submitB23_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB23_1ActionPerformed
        // TODO add your handling code here:

        try {
            stmt = conn.createStatement();

            String branchid = branchidI23_1.getText();
            String branchname = branchnameI23_1.getText();

            if (branchid.isEmpty() || branchname.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int branchidint = Integer.parseInt(branchid);

            String query1 = "SELECT * FROM Branch where branchid='" + branchidint + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Branch VALUES('" + branchidint + "','" + branchname + "')";

                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Added!");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Already Exists !");
            }
            branchidI23_1.setText("");
            branchnameI23_1.setText("");
            showB23ActionPerformed(evt);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB23_1ActionPerformed

    private void resetB23_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB23_1ActionPerformed
        // TODO add your handling code here:
        branchidI23_1.setText("");
        branchnameI23_1.setText("");
    }//GEN-LAST:event_resetB23_1ActionPerformed

    private void submitB23_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB23_2ActionPerformed
        // TODO add your handling code here:
        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable23_2.getModel();
            if (jTable23_2.getSelectedRowCount() == 1) {
                String branchid = branchidI23_2.getText();
                String branchname = branchnameI23_2.getText();

                //If Empty
                if (branchid.isEmpty() || branchname.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                int branchidint = Integer.parseInt(branchid);

                String query1 = "UPDATE Branch SET branchname = '" + branchname + "' WHERE branchid = '" + branchidint + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                showB23_2ActionPerformed(evt);

            } else {
                if (jTable23_2.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable23_2.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
            showB23ActionPerformed(evt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB23_2ActionPerformed

    private void resetB23_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB23_2ActionPerformed
        // TODO add your handling code here:
        branchidI23_2.setText("");
        branchnameI23_2.setText("");
        showB23_2ActionPerformed(evt);
    }//GEN-LAST:event_resetB23_2ActionPerformed

    private void hideB23_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB23_2ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable23_2.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB23_2ActionPerformed

    private void showB23_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB23_2ActionPerformed
        // TODO add your handling code here:

        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Branch";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable23_2.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String branchid = rs.getString("BranchID");
                String branchname = rs.getString("BranchName");
                String tb1Data[] = {branchid, branchname};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB23_2ActionPerformed

    private void jTable23_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable23_2MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable23_2.getModel();
        String branchid = tb1Model.getValueAt(jTable23_2.getSelectedRow(), 0).toString();
        String branchname = tb1Model.getValueAt(jTable23_2.getSelectedRow(), 1).toString();

        branchidI23_2.setText(branchid);
        branchnameI23_2.setText(branchname);

    }//GEN-LAST:event_jTable23_2MouseClicked

    private void submitB25_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB25_1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            adminidstr = adminidI25_1.getText();
            String firstname = firstnameI25_1.getText();
            String lastname = lastnameI25_1.getText();
            String email = emailI25_1.getText();

            if (adminidstr.isEmpty() || firstname.isEmpty() || lastname.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            adminid = Integer.parseInt(adminidstr);

            String query1 = "SELECT * FROM Admin where adminid='" + adminid + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Admin VALUES('" + adminid + "','" + firstname + "','" + lastname + "','" + email + "')";
                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Added!");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Already Exists !");
            }
            adminidI25_1.setText("");
            firstnameI25_1.setText("");
            lastnameI25_1.setText("");
            emailI25_1.setText("");
            showB25ActionPerformed(evt);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB25_1ActionPerformed

    private void resetB25_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB25_1ActionPerformed
        // TODO add your handling code here:
        adminidI25_1.setText("");
        firstnameI25_1.setText("");
        lastnameI25_1.setText("");
        emailI25_1.setText("");
    }//GEN-LAST:event_resetB25_1ActionPerformed

    private void submitB25_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB25_2ActionPerformed
        // TODO add your handling code here:
        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable25_2.getModel();
            if (jTable25_2.getSelectedRowCount() == 1) {
                adminidstr = adminidI25_2.getText();
                String firstname = firstnameI25_2.getText();
                String lastname = lastnameI25_2.getText();
                String email = emailI25_2.getText();

                //If Empty
                if (adminidstr.isEmpty() || firstname.isEmpty() || lastname.isEmpty() || email.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                adminid = Integer.parseInt(adminidstr);

                String query1 = "UPDATE Admin SET firstname = '" + firstname + "' WHERE adminid = '" + adminid + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();
                String query2 = "UPDATE Admin SET lastname = '" + lastname + "' WHERE adminid = '" + adminid + "'";
                PreparedStatement stmt2 = conn.prepareStatement(query2);
                stmt2.executeUpdate();
                String query3 = "UPDATE Admin SET email= '" + email + "' WHERE adminid = '" + adminid + "'";
                PreparedStatement stmt3 = conn.prepareStatement(query3);
                stmt3.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                showB25_2ActionPerformed(evt);

            } else {
                if (jTable25_2.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable25_2.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
            showB25ActionPerformed(evt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB25_2ActionPerformed

    private void resetB25_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB25_2ActionPerformed
        // TODO add your handling code here:
        adminidI25_2.setText("");
        firstnameI25_2.setText("");
        lastnameI25_2.setText("");
        emailI25_2.setText("");
        showB25_2ActionPerformed(evt);
    }//GEN-LAST:event_resetB25_2ActionPerformed

    private void showB25_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB25_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Admin";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable25_2.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                String adminidstrall = rs.getString("Adminid");
                String firstname = rs.getString("firstname");
                String lastname = rs.getString("lastname");
                String email = rs.getString("email");
                String tb1Data[] = {adminidstrall, firstname, lastname, email};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB25_2ActionPerformed

    private void hideB25_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB25_2ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable25_2.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB25_2ActionPerformed

    private void jTable25_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable25_2MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable25_2.getModel();
        adminidstr = tb1Model.getValueAt(jTable25_2.getSelectedRow(), 0).toString();
        String firstname = tb1Model.getValueAt(jTable25_2.getSelectedRow(), 1).toString();
        String lastname = tb1Model.getValueAt(jTable25_2.getSelectedRow(), 2).toString();
        String email = tb1Model.getValueAt(jTable25_2.getSelectedRow(), 3).toString();

        adminidI25_2.setText(adminidstr);
        firstnameI25_2.setText(firstname);
        lastnameI25_2.setText(lastname);
        emailI25_2.setText(email);
    }//GEN-LAST:event_jTable25_2MouseClicked

    private void submitB24_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB24_1ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            prnstr = prnI24_1.getText();
            String firstname = firstnameI24_1.getText();
            String lastname = lastnameI24_1.getText();
            String year = yearI24_1.getText();
            String branchid = branchidI24_1.getText();
            String semester = semesterI24_1.getText();
            String dob = dobI24_1.getText();
            String fathersname = fathersnameI24_1.getText();
            String email = emailI24_1.getText();
            String streetname = streetnameI24_1.getText();
            String streetnumber = streetnumberI24_1.getText();
            String zipcode = zipcodeI24_1.getText();
            String city = cityI24_1.getText();
            String state = stateI24_1.getText();
            String phonenumber1 = phonenumber1I24_1.getText();
            String phonenumber2 = phonenumber2I24_1.getText();

            if (prnstr.isEmpty() || firstname.isEmpty() || lastname.isEmpty() || year.isEmpty() || branchid.isEmpty() || semester.isEmpty() || dob.isEmpty() || fathersname.isEmpty() || email.isEmpty() || streetname.isEmpty() || streetnumber.isEmpty() || zipcode.isEmpty() || city.isEmpty() || state.isEmpty() || phonenumber1.isEmpty() || phonenumber2.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            String query1 = "SELECT * FROM Student where prn='" + prn + "'";
            rs = stmt.executeQuery(query1);
            if (rs.next() == false) {
                String query2 = "INSERT INTO Student VALUES('" + prn + "','" + firstname + "','" + lastname + "','" + year + "','" + branchid + "','" + semester + "','" + dob + "','" + fathersname + "','" + email + "','" + streetname + "','" + streetnumber + "','" + zipcode + "','" + state + "','" + city + "')";
                PreparedStatement stmt1 = conn.prepareStatement(query2);
                stmt1.executeUpdate();

                String query3 = "INSERT INTO Phonenumber VALUES('" + prn + "','" + phonenumber1 + "','" + phonenumber2 + "')";
                PreparedStatement stmt2 = conn.prepareStatement(query3);
                stmt2.executeUpdate();

                JOptionPane.showMessageDialog(rootPane, "Added!");

            } else {
                JOptionPane.showMessageDialog(rootPane, "Already Exists !");
            }
            prnI24_1.setText("");
            firstnameI24_1.setText("");
            lastnameI24_1.setText("");
            yearI24_1.setText("");
            branchidI24_1.setText("");
            semesterI24_1.setText("");
            dobI24_1.setText("");
            fathersnameI24_1.setText("");
            emailI24_1.setText("");
            streetnameI24_1.setText("");
            streetnumberI24_1.setText("");
            zipcodeI24_1.setText("");
            stateI24_1.setText("");
            cityI24_1.setText("");
            phonenumber1I24_1.setText("");
            phonenumber2I24_1.setText("");
            showB24ActionPerformed(evt);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB24_1ActionPerformed

    private void resetB24_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB24_1ActionPerformed
        // TODO add your handling code here:
        prnI24_1.setText("");
        firstnameI24_1.setText("");
        lastnameI24_1.setText("");
        yearI24_1.setText("");
        branchidI24_1.setText("");
        semesterI24_1.setText("");
        dobI24_1.setText("");
        fathersnameI24_1.setText("");
        emailI24_1.setText("");
        streetnameI24_1.setText("");
        streetnumberI24_1.setText("");
        zipcodeI24_1.setText("");
        cityI24_1.setText("");
        stateI24_1.setText("");
        phonenumber1I24_1.setText("");
        phonenumber2I24_1.setText("");
    }//GEN-LAST:event_resetB24_1ActionPerformed

    private void submitB24_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitB24_2ActionPerformed
        // TODO add your handling code here:
        try {
            DefaultTableModel tb1Model = (DefaultTableModel) jTable24_2.getModel();
            if (jTable24_2.getSelectedRowCount() == 1) {
                prnstr = prnI24_2.getText();
                String firstname = firstnameI24_2.getText();
                String lastname = lastnameI24_2.getText();
                String year = yearI24_2.getText();
                String branchid = branchidI24_2.getText();
                String semester = semesterI24_2.getText();
                String dob = dobI24_2.getText();
                String fathersname = fathersnameI24_2.getText();
                String email = emailI24_2.getText();
                String streetname = streetnameI24_2.getText();
                String streetnumber = streetnumberI24_2.getText();
                String zipcode = zipcodeI24_2.getText();
                String state = stateI24_2.getText();
                String city = cityI24_2.getText();
                String p1 = phonenumber1I24_2.getText();
                String p2 = phonenumber2I24_2.getText();

                //If Empty
                if (prnstr.isEmpty() || firstname.isEmpty() || lastname.isEmpty() || year.isEmpty() || branchid.isEmpty() || semester.isEmpty() || dob.isEmpty() || fathersname.isEmpty() || email.isEmpty() || streetname.isEmpty() || streetnumber.isEmpty() || zipcode.isEmpty() || city.isEmpty() || state.isEmpty() || p1.isEmpty() || p2.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Enter Something");
                    return;
                }

                prn = Integer.parseInt(prnstr);

                String query1 = "UPDATE Student SET firstname = '" + firstname + "' WHERE prn = '" + prn + "'";
                PreparedStatement stmt1 = conn.prepareStatement(query1);
                stmt1.executeUpdate();
                String query2 = "UPDATE Student SET lastname = '" + lastname + "' WHERE prn = '" + prn + "'";
                PreparedStatement stmt2 = conn.prepareStatement(query2);
                stmt2.executeUpdate();
                String query3 = "UPDATE Student SET year= '" + year + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt3 = conn.prepareStatement(query3);
                stmt3.executeUpdate();
                String query4 = "UPDATE Student SET branchid= '" + branchid + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt4 = conn.prepareStatement(query4);
                stmt4.executeUpdate();
                String query5 = "UPDATE Student SET semester= '" + semester + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt5 = conn.prepareStatement(query5);
                stmt5.executeUpdate();
                String query6 = "UPDATE Student SET dob= '" + dob + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt6 = conn.prepareStatement(query6);
                stmt6.executeUpdate();
                String query7 = "UPDATE Student SET fathersname= '" + fathersname + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt7 = conn.prepareStatement(query7);
                stmt7.executeUpdate();
                String query8 = "UPDATE Student SET email= '" + email + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt8 = conn.prepareStatement(query8);
                stmt8.executeUpdate();
                String query9 = "UPDATE Student SET addressstreetname= '" + streetname + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt9 = conn.prepareStatement(query9);
                stmt9.executeUpdate();
                String query10 = "UPDATE Student SET addressstreetnumber= '" + streetnumber + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt10 = conn.prepareStatement(query10);
                stmt10.executeUpdate();
                String query11 = "UPDATE Student SET addresszipcode= '" + zipcode + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt11 = conn.prepareStatement(query11);
                stmt11.executeUpdate();
                String query12 = "UPDATE Student SET addressstate= '" + state + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt12 = conn.prepareStatement(query12);
                stmt12.executeUpdate();
                String query13 = "UPDATE Student SET addresscity= '" + city + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt13 = conn.prepareStatement(query13);
                stmt13.executeUpdate();
                String query14 = "UPDATE Phonenumber SET phonenumber1= '" + p1 + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt14 = conn.prepareStatement(query14);
                stmt14.executeUpdate();
                String query15 = "UPDATE Phonenumber SET phonenumber2= '" + p2 + "' WHERE prn= '" + prn + "'";
                PreparedStatement stmt15 = conn.prepareStatement(query15);
                stmt15.executeUpdate();

                JOptionPane.showMessageDialog(this, "Updated Successfully !");

                tb1Model.setRowCount(0);
                showB24_2ActionPerformed(evt);

            } else {
                if (jTable24_2.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table is Empty !");
                } else if (jTable24_2.getSelectedRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Select a Row !");
                } else {
                    JOptionPane.showMessageDialog(this, "Multiple Row Selected !");
                }
            }
            showB24ActionPerformed(evt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Does not Exists");
            System.out.println(e);
        }
    }//GEN-LAST:event_submitB24_2ActionPerformed

    private void resetB24_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetB24_2ActionPerformed
        // TODO add your handling code here:
        prnI24_2.setText("");
        firstnameI24_2.setText("");
        lastnameI24_2.setText("");
        yearI24_2.setText("");
        branchidI24_2.setText("");
        semesterI24_2.setText("");
        dobI24_2.setText("");
        fathersnameI24_2.setText("");
        emailI24_2.setText("");
        streetnameI24_2.setText("");
        streetnumberI24_2.setText("");
        zipcodeI24_2.setText("");
        cityI24_2.setText("");
        stateI24_2.setText("");
        phonenumber1I24_2.setText("");
        phonenumber2I24_2.setText("");
        showB24_2ActionPerformed(evt);
    }//GEN-LAST:event_resetB24_2ActionPerformed

    private void hideB24_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hideB24_2ActionPerformed
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable24_2.getModel();
        tb1Model.setRowCount(0);
    }//GEN-LAST:event_hideB24_2ActionPerformed

    private void showB24_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showB24_2ActionPerformed
        // TODO add your handling code here:
        try {
            stmt = conn.createStatement();

            String query = "SELECT * FROM Student s LEFT JOIN Phonenumber p ON s.PRN=p.PRN";
            rs = stmt.executeQuery(query);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable24_2.getModel();
            tb1Model.setRowCount(0);

            while (rs.next()) {
                prnstr = rs.getString("PRN");
                String firstname = rs.getString("FirstName");
                String lastname = rs.getString("lastname");
                String year = rs.getString("Year");
                String branchid = rs.getString("Branchid");
                String semester = rs.getString("Semester");
                String dob = rs.getString("DOB");
                String fathersname = rs.getString("Fathersname");
                String email = rs.getString("Email");
                String streetname = rs.getString("AddressStreetName");
                String streetnumber = rs.getString("AddressStreetNumber");
                String zipcode = rs.getString("AddressZipCode");
                String state = rs.getString("AddressState");
                String city = rs.getString("AddressCity");
                String p1 = rs.getString("PhoneNumber1");
                String p2 = rs.getString("PhoneNumber2");

                String tb1Data[] = {prnstr, firstname, lastname, year, branchid, semester, dob, fathersname, email, streetname, streetnumber, zipcode, state, city, p1, p2};
                tb1Model.addRow(tb1Data);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Error Occurred");
            System.out.println(e);
        }
    }//GEN-LAST:event_showB24_2ActionPerformed

    private void jTable24_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable24_2MouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb1Model = (DefaultTableModel) jTable24_2.getModel();
        prnstr = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 0).toString();
        String firstname = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 1).toString();
        String lastname = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 2).toString();
        String year = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 3).toString();
        String branchid = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 4).toString();
        String semester = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 5).toString();
        String dob = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 6).toString();
        String fathersname = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 7).toString();
        String email = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 8).toString();
        String streetname = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 9).toString();
        String streetnumber = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 10).toString();
        String zipcode = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 11).toString();
        String state = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 12).toString();
        String city = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 13).toString();
        String phonenumber1 = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 14).toString();
        String phonenumber2 = tb1Model.getValueAt(jTable24_2.getSelectedRow(), 15).toString();

        prnI24_2.setText(prnstr);
        firstnameI24_2.setText(firstname);
        lastnameI24_2.setText(lastname);
        yearI24_2.setText(year);
        branchidI24_2.setText(branchid);
        semesterI24_2.setText(semester);
        dobI24_2.setText(dob);
        fathersnameI24_2.setText(fathersname);
        emailI24_2.setText(email);
        streetnameI24_2.setText(streetname);
        streetnumberI24_2.setText(streetnumber);
        zipcodeI24_2.setText(zipcode);
        stateI24_2.setText(state);
        cityI24_2.setText(city);
        phonenumber1I24_2.setText(phonenumber1);
        phonenumber2I24_2.setText(phonenumber2);

    }//GEN-LAST:event_jTable24_2MouseClicked

    private void findB7_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB7_1ActionPerformed
        // TODO add your handling code here:
        try {
            prnstr = findI7_1.getText();

            //If username is Empty
            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            //Empty the table before showing the result
            DefaultTableModel tb1Model = (DefaultTableModel) jTable7_1.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM StudenlLogin WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query);

            //Username not found
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "User Not Found");
                allDetailsstu(jTable7_1);
                return;
            }

            //Refreshing rs
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {

                    stupassword = rs.getString("StudentPassword");
                    String tb1Data[] = {prnstr, stupassword};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable7_1.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "User does not Exists");
        }
    }//GEN-LAST:event_findB7_1ActionPerformed

    private void findB12_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB12_2ActionPerformed
        // TODO add your handling code here:
        try {

            prnstr = findI12_2.getText();

            //If username is Empty
            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            //Empty the table before showing the result
            DefaultTableModel tb1Model = (DefaultTableModel) jTable12_2.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Fees WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query);

            //Username not found
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB12_2ActionPerformed(evt);
                findI12_2.setText("");
                return;
            }

            //Refreshing rs
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    String paidunpaid = rs.getString("PaidUnpaid");
                    String fine = rs.getString("Fine");
                    String tb1Data[] = {prnstr, paidunpaid, fine};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable12_2.getModel();
                    tb1Model2.addRow(tb1Data);

                }
            }
            findI12_2.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB12_2ActionPerformed

    private void findB13_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB13_2ActionPerformed
        // TODO add your handling code here:
        try {

            String courseidstr = findI13_2.getText();

            if (courseidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int courseid = Integer.parseInt(courseidstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable13_2.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Course WHERE courseid ='" + courseid + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB13_2ActionPerformed(evt);
                findI13_2.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (courseidstr.equals(rs.getString("courseid"))) {
                    String coursename = rs.getString("CourseName");
                    String duration = rs.getString("Duration");
                    String branchID = rs.getString("BranchID");
                    String tb1Data[] = {courseidstr, coursename, duration, branchID};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable13_2.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }
            findI13_2.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB13_2ActionPerformed

    private void findB8_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB8_2ActionPerformed
        // TODO add your handling code here:
        try {

            prnstr = findI8_2.getText();

            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable8_2.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Grades WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");
                showB8_2ActionPerformed(evt);
                findI8_2.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    String midsem = rs.getString("MidSem");
                    String endsem = rs.getString("EndSem");
                    String tb1Data[] = {prnstr, midsem, endsem};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable8_2.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }
            findI8_2.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB8_2ActionPerformed

    private void findB9_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB9_2ActionPerformed
        // TODO add your handling code here:
        try {

            String facultyidstr = findI9_2.getText();

            if (facultyidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int facultyid = Integer.parseInt(facultyidstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable9_2.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Faculty WHERE facultyid ='" + facultyid + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB9_2ActionPerformed(evt);
                findI9_2.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (facultyidstr.equals(rs.getString("facultyid"))) {
                    String facultyname = rs.getString("FacultyName");
                    String branchid = rs.getString("branchID");
                    String tb1Data[] = {facultyidstr, facultyname, branchid};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable9_2.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }
            findI9_2.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB9_2ActionPerformed

    private void findB10_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB10_2ActionPerformed
        // TODO add your handling code here:
        try {

            prnstr = findI10_2.getText();

            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable10_2.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Attendance WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB10_2ActionPerformed(evt);
                findI10_2.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {

                    String percentage = rs.getString("Percentage");
                    String date = rs.getString("Date1");
                    String tb1Data[] = {prnstr, percentage, date};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable10_2.getModel();
                    tb1Model2.addRow(tb1Data);

                }
            }
            findI10_2.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB10_2ActionPerformed

    private void findB11_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB11_2ActionPerformed
        // TODO add your handling code here:
        try {

            String libraryidstr = findI11_2.getText();

            if (libraryidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int libraryid = Integer.parseInt(libraryidstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable11_2.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Library WHERE libraryid ='" + libraryid + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");
                showB11_2ActionPerformed(evt);
                findI11_2.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (libraryidstr.equals(rs.getString("libraryid"))) {

                    String category = rs.getString("Category");
                    String issuedate = rs.getString("Issue");
                    String returndate = rs.getString("Return1");
                    String tb1Data[] = {libraryidstr, category, issuedate, returndate};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable11_2.getModel();
                    tb1Model2.addRow(tb1Data);

                }
            }
            findI11_2.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB11_2ActionPerformed

    private void findB14_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB14_2ActionPerformed
        // TODO add your handling code here:
        try {

            prnstr = findI14_2.getText();

            //If username is Empty
            if (prnstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            prn = Integer.parseInt(prnstr);

            //Empty the table before showing the result
            DefaultTableModel tb1Model = (DefaultTableModel) jTable14_2.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Hostel WHERE PRN ='" + prn + "';";
            rs = stmt.executeQuery(query);

            //Username not found
            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB14_2ActionPerformed(evt);
                findI14_2.setText("");
                return;
            }

            //Refreshing rs
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                if (prnstr.equals(rs.getString("PRN"))) {
                    String gender = rs.getString("Gender");
                    String simpleroom = rs.getString("SimpleRoom");
                    String luxuryroom = rs.getString("LuxuryRoom");
                    String tb1Data[] = {prnstr, gender, simpleroom, luxuryroom};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable14_2.getModel();
                    tb1Model2.addRow(tb1Data);

                }
            }
            findI14_2.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB14_2ActionPerformed

    private void findB15_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findB15_2ActionPerformed
        // TODO add your handling code here:
        try {

            String timetableidstr = findI15_2.getText();

            if (timetableidstr.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Enter Something");
                return;
            }

            int timetableid = Integer.parseInt(timetableidstr);

            DefaultTableModel tb1Model = (DefaultTableModel) jTable15_2.getModel();
            tb1Model.setRowCount(0);
            String query = "SELECT * FROM Timetable WHERE timetableid ='" + timetableid + "';";
            rs = stmt.executeQuery(query);

            if (rs.next() == false) {
                JOptionPane.showMessageDialog(rootPane, "Not Found");

                showB15_2ActionPerformed(evt);
                findI15_2.setText("");
                return;
            }
            rs = stmt.executeQuery(query);
            while (rs.next()) {
                if (timetableidstr.equals(rs.getString("timetableid"))) {

                    String courseid = rs.getString("CourseID");
                    String facultyid = rs.getString("FacultyID");
                    String roomnumber = rs.getString("RoomNumber");
                    String timing = rs.getString("Timing");
                    String tb1Data[] = {timetableidstr, courseid, facultyid, roomnumber, timing};
                    DefaultTableModel tb1Model2 = (DefaultTableModel) jTable15_2.getModel();
                    tb1Model2.addRow(tb1Data);
                }
            }
            findI15_2.setText("");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Not Found");
        }
    }//GEN-LAST:event_findB15_2ActionPerformed

    private void crossL1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_crossL1MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_crossL1MouseClicked

    private void crossL3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_crossL3MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_crossL3MouseClicked

    private void crossL2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_crossL2MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_crossL2MouseClicked

    private void address2I4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_address2I4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_address2I4ActionPerformed

    private void address3I4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_address3I4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_address3I4ActionPerformed

    private void findI12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findI12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_findI12ActionPerformed

    private void findI15_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findI15_2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_findI15_2ActionPerformed

    private void findI8_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findI8_2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_findI8_2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(J01_MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(J01_MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(J01_MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(J01_MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                DBdata obj = new DBdata();
                obj.ConnectionCreationMethod();
//                obj.DBCreationMethod();
//                obj.createDB();
                
                new J01_MainPage().setVisible(true);
                obj.useDB();

            }
        });
    }
    //User Defined Variables
    protected static Statement stmt;
    protected static Connection conn;
    protected static ResultSet rs;
    
    protected static int prn;
    protected static String prnstr;
    protected static String stupassword;
    protected static String stuoldpassword;

    protected static int adminid;
    protected static String adminidstr;
    protected static String adpassword;
    protected static String adoldpassword;

//    Accessing last accessed tab
    protected static int lastAccessedTabIndex;
    protected static int temp;
    protected static int newAccessedTabIndex;
    protected static int lastAccessedTabIndex1;
    protected static int temp1;
    protected static int newAccessedTabIndex1;

    protected ChangeListener objChangeListener;
    protected ChangeListener objChangeListener1;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel FineL19;
    private javax.swing.JButton addB10;
    private javax.swing.JButton addB11;
    private javax.swing.JButton addB12;
    private javax.swing.JButton addB13;
    private javax.swing.JButton addB14;
    private javax.swing.JButton addB15;
    private javax.swing.JButton addB23;
    private javax.swing.JButton addB24;
    private javax.swing.JButton addB25;
    private javax.swing.JButton addB8;
    private javax.swing.JButton addB9;
    private javax.swing.JButton addBt6;
    private javax.swing.JButton addBt7;
    private javax.swing.JTextField address1I4;
    private javax.swing.JTextField address2I4;
    private javax.swing.JTextField address3I4;
    private javax.swing.JLabel addressL4;
    private javax.swing.JButton adminBt1;
    private javax.swing.JTable adminTABt6;
    private javax.swing.JButton admindetailsBst3;
    private javax.swing.JTextField adminidI25_1;
    private javax.swing.JTextField adminidI25_2;
    private javax.swing.JTextField adminidI5;
    private javax.swing.JTextField adminidIt3;
    private javax.swing.JTextField adminidIt6_1;
    private javax.swing.JTextField adminidIt6_2;
    private javax.swing.JTextField adminidIt6_3;
    private javax.swing.JLabel adminidL25_1;
    private javax.swing.JLabel adminidL25_2;
    private javax.swing.JLabel adminidL5;
    private javax.swing.JLabel adminidLt3;
    private javax.swing.JLabel adminidLt6_1;
    private javax.swing.JLabel adminidLt6_2;
    private javax.swing.JLabel adminidLt6_3;
    private javax.swing.JButton adminloginBst3;
    private javax.swing.JButton attendanceBst2;
    private javax.swing.JButton attendanceBst3;
    private javax.swing.JButton backBst3;
    private javax.swing.JButton backBst5;
    private javax.swing.JLabel bgL1;
    private javax.swing.JLabel bgL2;
    private javax.swing.JLabel bgL3;
    private javax.swing.JButton branchBst3;
    private javax.swing.JTextField branchI19;
    private javax.swing.JTextField branchI20;
    private javax.swing.JTextField branchI22;
    private javax.swing.JLabel branchL19;
    private javax.swing.JLabel branchL20;
    private javax.swing.JLabel branchL22;
    private javax.swing.JTextField branchidI13_1;
    private javax.swing.JTextField branchidI13_2;
    private javax.swing.JTextField branchidI23_1;
    private javax.swing.JTextField branchidI23_2;
    private javax.swing.JTextField branchidI24_1;
    private javax.swing.JTextField branchidI24_2;
    private javax.swing.JTextField branchidI4;
    private javax.swing.JTextField branchidI9_1;
    private javax.swing.JTextField branchidI9_2;
    private javax.swing.JLabel branchidL13_1;
    private javax.swing.JLabel branchidL13_2;
    private javax.swing.JLabel branchidL23_1;
    private javax.swing.JLabel branchidL23_2;
    private javax.swing.JLabel branchidL24_1;
    private javax.swing.JLabel branchidL24_2;
    private javax.swing.JLabel branchidL4;
    private javax.swing.JLabel branchidL9_1;
    private javax.swing.JLabel branchidL9_2;
    private javax.swing.JTextField branchnameI23_1;
    private javax.swing.JTextField branchnameI23_2;
    private javax.swing.JLabel branchnameL23_1;
    private javax.swing.JLabel branchnameL23_2;
    private javax.swing.JTextField categoryI11_1;
    private javax.swing.JTextField categoryI11_2;
    private javax.swing.JLabel categoryL11_1;
    private javax.swing.JLabel categoryL11_2;
    private javax.swing.JTextField cityI24_1;
    private javax.swing.JTextField cityI24_2;
    private javax.swing.JLabel cityL24_1;
    private javax.swing.JLabel cityL24_2;
    private javax.swing.JButton courseBst2;
    private javax.swing.JButton courseBst3;
    private javax.swing.JTextField courseidI13_1;
    private javax.swing.JTextField courseidI13_2;
    private javax.swing.JTextField courseidI15_1;
    private javax.swing.JTextField courseidI15_2;
    private javax.swing.JLabel courseidL13_1;
    private javax.swing.JLabel courseidL13_2;
    private javax.swing.JLabel courseidL15_1;
    private javax.swing.JLabel courseidL15_2;
    private javax.swing.JTextField coursenameI13_1;
    private javax.swing.JTextField coursenameI13_2;
    private javax.swing.JLabel coursenameL13_1;
    private javax.swing.JLabel coursenameL13_2;
    private javax.swing.JLabel crossL1;
    private javax.swing.JLabel crossL2;
    private javax.swing.JLabel crossL3;
    private javax.swing.JTextField dateI10_1;
    private javax.swing.JTextField dateI10_2;
    private javax.swing.JTextField dateI17;
    private javax.swing.JLabel dateL10_1;
    private javax.swing.JLabel dateL10_2;
    private javax.swing.JLabel dateL17;
    private javax.swing.JButton deleteB10;
    private javax.swing.JButton deleteB11;
    private javax.swing.JButton deleteB12;
    private javax.swing.JButton deleteB13;
    private javax.swing.JButton deleteB14;
    private javax.swing.JButton deleteB15;
    private javax.swing.JButton deleteB23;
    private javax.swing.JButton deleteB24;
    private javax.swing.JButton deleteB25;
    private javax.swing.JButton deleteB8;
    private javax.swing.JButton deleteB9;
    private javax.swing.JButton deleteBt6;
    private javax.swing.JButton deleteBt7;
    private javax.swing.JTextField deleteI10;
    private javax.swing.JTextField deleteI11;
    private javax.swing.JTextField deleteI12;
    private javax.swing.JTextField deleteI13;
    private javax.swing.JTextField deleteI14;
    private javax.swing.JTextField deleteI15;
    private javax.swing.JTextField deleteI23;
    private javax.swing.JTextField deleteI24;
    private javax.swing.JTextField deleteI25;
    private javax.swing.JTextField deleteI8;
    private javax.swing.JTextField deleteI9;
    private javax.swing.JTextField deleteissueI11;
    private javax.swing.JTextField dobI24_1;
    private javax.swing.JTextField dobI24_2;
    private javax.swing.JTextField dobI4;
    private javax.swing.JLabel dobL24_1;
    private javax.swing.JLabel dobL24_2;
    private javax.swing.JLabel dobL4;
    private javax.swing.JTextField durationI13_1;
    private javax.swing.JTextField durationI13_2;
    private javax.swing.JLabel durationL13_1;
    private javax.swing.JLabel durationL13_2;
    private javax.swing.JLabel emaiL25_1;
    private javax.swing.JLabel emaiL25_2;
    private javax.swing.JTextField emailI24_1;
    private javax.swing.JTextField emailI24_2;
    private javax.swing.JTextField emailI25_1;
    private javax.swing.JTextField emailI25_2;
    private javax.swing.JTextField emailI4;
    private javax.swing.JTextField emailI5;
    private javax.swing.JLabel emailL24_1;
    private javax.swing.JLabel emailL24_2;
    private javax.swing.JLabel emailL4;
    private javax.swing.JLabel emailL5;
    private javax.swing.JTextField endsemI16;
    private javax.swing.JTextField endsemI8_1;
    private javax.swing.JTextField endsemI8_2;
    private javax.swing.JLabel endsemL16;
    private javax.swing.JLabel endsemL8_1;
    private javax.swing.JLabel endsemL8_2;
    private javax.swing.JButton facultyBst3;
    private javax.swing.JTextField facultyidI15_1;
    private javax.swing.JTextField facultyidI15_2;
    private javax.swing.JTextField facultyidI9_1;
    private javax.swing.JTextField facultyidI9_2;
    private javax.swing.JLabel facultyidL15_1;
    private javax.swing.JLabel facultyidL15_2;
    private javax.swing.JLabel facultyidL9_1;
    private javax.swing.JLabel facultyidL9_2;
    private javax.swing.JTextField facultynameI9_1;
    private javax.swing.JTextField facultynameI9_2;
    private javax.swing.JLabel facultynameL9_1;
    private javax.swing.JLabel facultynameL9_2;
    private javax.swing.JTextField fathernameI4;
    private javax.swing.JLabel fathernameL4;
    private javax.swing.JTextField fathersnameI24_1;
    private javax.swing.JTextField fathersnameI24_2;
    private javax.swing.JLabel fathersnameL24_1;
    private javax.swing.JLabel fathersnameL24_2;
    private javax.swing.JButton feesBst2;
    private javax.swing.JButton feesBst3;
    private javax.swing.JButton findB10;
    private javax.swing.JButton findB10_2;
    private javax.swing.JButton findB11;
    private javax.swing.JButton findB11_2;
    private javax.swing.JButton findB12;
    private javax.swing.JButton findB12_2;
    private javax.swing.JButton findB13;
    private javax.swing.JButton findB13_2;
    private javax.swing.JButton findB14;
    private javax.swing.JButton findB14_2;
    private javax.swing.JButton findB15;
    private javax.swing.JButton findB15_2;
    private javax.swing.JButton findB23;
    private javax.swing.JButton findB24;
    private javax.swing.JButton findB25;
    private javax.swing.JToggleButton findB7_1;
    private javax.swing.JButton findB8;
    private javax.swing.JButton findB8_2;
    private javax.swing.JButton findB9;
    private javax.swing.JButton findB9_2;
    private javax.swing.JButton findBt6;
    private javax.swing.JButton findBt7;
    private javax.swing.JTextField findI10;
    private javax.swing.JTextField findI10_2;
    private javax.swing.JTextField findI11;
    private javax.swing.JTextField findI11_2;
    private javax.swing.JTextField findI12;
    private javax.swing.JTextField findI12_2;
    private javax.swing.JTextField findI13;
    private javax.swing.JTextField findI13_2;
    private javax.swing.JTextField findI14;
    private javax.swing.JTextField findI14_2;
    private javax.swing.JTextField findI15;
    private javax.swing.JTextField findI15_2;
    private javax.swing.JTextField findI23;
    private javax.swing.JTextField findI24;
    private javax.swing.JTextField findI25;
    private javax.swing.JTextField findI7_1;
    private javax.swing.JTextField findI8;
    private javax.swing.JTextField findI8_2;
    private javax.swing.JTextField findI9;
    private javax.swing.JTextField findI9_2;
    private javax.swing.JTextField findIt6;
    private javax.swing.JTextField findIt7;
    private javax.swing.JTextField fineI12_1;
    private javax.swing.JTextField fineI12_2;
    private javax.swing.JTextField fineI19;
    private javax.swing.JLabel fineL12_1;
    private javax.swing.JLabel fineL12_2;
    private javax.swing.JTextField firstnameI24_1;
    private javax.swing.JTextField firstnameI24_2;
    private javax.swing.JTextField firstnameI25_1;
    private javax.swing.JTextField firstnameI25_2;
    private javax.swing.JTextField firstnameI4;
    private javax.swing.JTextField firstnameI5;
    private javax.swing.JLabel firstnameL24_1;
    private javax.swing.JLabel firstnameL24_2;
    private javax.swing.JLabel firstnameL25_1;
    private javax.swing.JLabel firstnameL25_2;
    private javax.swing.JLabel firstnameL4;
    private javax.swing.JLabel firstnameL5;
    private javax.swing.JTextField genderI14_1;
    private javax.swing.JTextField genderI14_2;
    private javax.swing.JTextField genderI21;
    private javax.swing.JLabel genderL14_1;
    private javax.swing.JLabel genderL14_2;
    private javax.swing.JLabel genderL21;
    private javax.swing.JButton gradesBst2;
    private javax.swing.JButton gradesBst3;
    private javax.swing.JLabel headingL10;
    private javax.swing.JLabel headingL10_1;
    private javax.swing.JLabel headingL10_2;
    private javax.swing.JLabel headingL11;
    private javax.swing.JLabel headingL11_1;
    private javax.swing.JLabel headingL11_2;
    private javax.swing.JLabel headingL12;
    private javax.swing.JLabel headingL12_1;
    private javax.swing.JLabel headingL12_2;
    private javax.swing.JLabel headingL13;
    private javax.swing.JLabel headingL13_1;
    private javax.swing.JLabel headingL13_2;
    private javax.swing.JLabel headingL14;
    private javax.swing.JLabel headingL14_1;
    private javax.swing.JLabel headingL14_2;
    private javax.swing.JLabel headingL15;
    private javax.swing.JLabel headingL15_1;
    private javax.swing.JLabel headingL15_2;
    private javax.swing.JLabel headingL16;
    private javax.swing.JLabel headingL17;
    private javax.swing.JLabel headingL18;
    private javax.swing.JLabel headingL19;
    private javax.swing.JLabel headingL20;
    private javax.swing.JLabel headingL21;
    private javax.swing.JLabel headingL22;
    private javax.swing.JLabel headingL23;
    private javax.swing.JLabel headingL23_1;
    private javax.swing.JLabel headingL23_2;
    private javax.swing.JLabel headingL24;
    private javax.swing.JLabel headingL24_1;
    private javax.swing.JLabel headingL24_2;
    private javax.swing.JLabel headingL25;
    private javax.swing.JLabel headingL25_1;
    private javax.swing.JLabel headingL25_2;
    private javax.swing.JLabel headingL4;
    private javax.swing.JLabel headingL5;
    private javax.swing.JLabel headingL8;
    private javax.swing.JLabel headingL8_1;
    private javax.swing.JLabel headingL8_2;
    private javax.swing.JLabel headingL9;
    private javax.swing.JLabel headingL9_1;
    private javax.swing.JLabel headingL9_2;
    private javax.swing.JLabel headingLt1;
    private javax.swing.JLabel headingLt2;
    private javax.swing.JLabel headingLt3;
    private javax.swing.JLabel headingLt6;
    private javax.swing.JLabel headingLt6_1;
    private javax.swing.JLabel headingLt6_2;
    private javax.swing.JLabel headingLt6_3;
    private javax.swing.JLabel headingLt7;
    private javax.swing.JLabel headingLt7_1;
    private javax.swing.JLabel headingLt7_2;
    private javax.swing.JLabel headingLt7_3;
    private javax.swing.JButton hideB10;
    private javax.swing.JButton hideB10_2;
    private javax.swing.JButton hideB11;
    private javax.swing.JButton hideB11_2;
    private javax.swing.JButton hideB12;
    private javax.swing.JButton hideB12_2;
    private javax.swing.JButton hideB13;
    private javax.swing.JButton hideB13_2;
    private javax.swing.JButton hideB14;
    private javax.swing.JButton hideB14_2;
    private javax.swing.JButton hideB15;
    private javax.swing.JButton hideB15_2;
    private javax.swing.JButton hideB23;
    private javax.swing.JButton hideB23_2;
    private javax.swing.JButton hideB24;
    private javax.swing.JButton hideB24_2;
    private javax.swing.JButton hideB25;
    private javax.swing.JButton hideB25_2;
    private javax.swing.JButton hideB8;
    private javax.swing.JButton hideB8_2;
    private javax.swing.JButton hideB9;
    private javax.swing.JButton hideB9_2;
    private javax.swing.JButton hideBt6;
    private javax.swing.JButton hideBt7;
    private javax.swing.JButton hideBt7_1;
    private javax.swing.JButton homeBst4;
    private javax.swing.JButton homeBst5;
    private javax.swing.JButton hostelBst2;
    private javax.swing.JButton hostelBst3;
    private javax.swing.JTextField issuedateI11_1;
    private javax.swing.JTextField issuedateI11_2;
    private javax.swing.JLabel issuedateL11_1;
    private javax.swing.JLabel issuedateL11_2;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane10_2;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane11_2;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane12_2;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane13_2;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane14_2;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane15_2;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane23_2;
    private javax.swing.JScrollPane jScrollPane24;
    private javax.swing.JScrollPane jScrollPane24_2;
    private javax.swing.JScrollPane jScrollPane25;
    private javax.swing.JScrollPane jScrollPane25_2;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane8_2;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JScrollPane jScrollPane9_2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable10;
    private javax.swing.JTable jTable10_2;
    private javax.swing.JTable jTable11;
    private javax.swing.JTable jTable11_2;
    private javax.swing.JTable jTable12;
    private javax.swing.JTable jTable12_2;
    private javax.swing.JTable jTable13;
    private javax.swing.JTable jTable13_2;
    private javax.swing.JTable jTable14;
    private javax.swing.JTable jTable14_2;
    private javax.swing.JTable jTable15;
    private javax.swing.JTable jTable15_2;
    private javax.swing.JTable jTable18;
    private javax.swing.JTable jTable20;
    private javax.swing.JTable jTable22;
    private javax.swing.JTable jTable23;
    private javax.swing.JTable jTable23_2;
    private javax.swing.JTable jTable24;
    private javax.swing.JTable jTable24_2;
    private javax.swing.JTable jTable25;
    private javax.swing.JTable jTable25_2;
    private javax.swing.JTable jTable7;
    private javax.swing.JTable jTable7_1;
    private javax.swing.JTable jTable8;
    private javax.swing.JTable jTable8_2;
    private javax.swing.JTable jTable9;
    private javax.swing.JTable jTable9_2;
    private javax.swing.JTextField lastnameI24_1;
    private javax.swing.JTextField lastnameI24_2;
    private javax.swing.JTextField lastnameI25_1;
    private javax.swing.JTextField lastnameI25_2;
    private javax.swing.JTextField lastnameI4;
    private javax.swing.JTextField lastnameI5;
    private javax.swing.JLabel lastnameL24_1;
    private javax.swing.JLabel lastnameL24_2;
    private javax.swing.JLabel lastnameL25_1;
    private javax.swing.JLabel lastnameL25_2;
    private javax.swing.JLabel lastnameL4;
    private javax.swing.JLabel lastnamel5;
    private javax.swing.JButton libraryBst2;
    private javax.swing.JButton libraryBst3;
    private javax.swing.JTextField libraryidI11_1;
    private javax.swing.JTextField libraryidI11_2;
    private javax.swing.JTextField libraryidI18;
    private javax.swing.JLabel libraryidL11_1;
    private javax.swing.JLabel libraryidL11_2;
    private javax.swing.JLabel libraryidL18;
    private javax.swing.JLabel logoL1;
    private javax.swing.JButton logoutBst2;
    private javax.swing.JTextField luxuryroomI14_1;
    private javax.swing.JTextField luxuryroomI14_2;
    private javax.swing.JLabel luxuryroomL14_1;
    private javax.swing.JLabel luxuryroomL14_2;
    private javax.swing.JTextField midsemI16;
    private javax.swing.JTextField midsemI8_1;
    private javax.swing.JTextField midsemI8_2;
    private javax.swing.JLabel midsemL16;
    private javax.swing.JLabel midsemL8_1;
    private javax.swing.JLabel midsemL8_2;
    private javax.swing.JTextField paidunpaidI12_1;
    private javax.swing.JTextField paidunpaidI12_2;
    private javax.swing.JTextField paidunpaidI19;
    private javax.swing.JLabel paidunpaidL12_1;
    private javax.swing.JLabel paidunpaidL12_2;
    private javax.swing.JLabel paidunpaidL19;
    private javax.swing.JLabel passLt6_2;
    private javax.swing.JLabel passLt6_3;
    private javax.swing.JLabel passLt7_2;
    private javax.swing.JLabel passLt7_3;
    private javax.swing.JLabel passnewLt6_1;
    private javax.swing.JLabel passoldLt6_1;
    private javax.swing.JPasswordField passwordIt2;
    private javax.swing.JPasswordField passwordIt3;
    private javax.swing.JPasswordField passwordIt6_2;
    private javax.swing.JPasswordField passwordIt6_3;
    private javax.swing.JTextField passwordIt7_1;
    private javax.swing.JPasswordField passwordIt7_2;
    private javax.swing.JPasswordField passwordIt7_3;
    private javax.swing.JLabel passwordLt2;
    private javax.swing.JLabel passwordLt3;
    private javax.swing.JLabel passwordLt7_1;
    private javax.swing.JPasswordField passwordnewIt6_1;
    private javax.swing.JPasswordField passwordoldIt6_1;
    private javax.swing.JTextField percentageI10_1;
    private javax.swing.JTextField percentageI10_2;
    private javax.swing.JTextField percentageI17;
    private javax.swing.JLabel percentageL10_1;
    private javax.swing.JLabel percentageL10_2;
    private javax.swing.JLabel percentageL17;
    private javax.swing.JTextField phonenumber1I24_1;
    private javax.swing.JTextField phonenumber1I24_2;
    private javax.swing.JTextField phonenumber1I4;
    private javax.swing.JLabel phonenumber1L24_1;
    private javax.swing.JLabel phonenumber1L24_2;
    private javax.swing.JTextField phonenumber2I24_1;
    private javax.swing.JTextField phonenumber2I24_2;
    private javax.swing.JTextField phonenumber2I4;
    private javax.swing.JLabel phonenumber2L24_1;
    private javax.swing.JLabel phonenumber2L24_2;
    private javax.swing.JLabel phonenumberL4;
    private javax.swing.JTextField prnI10_1;
    private javax.swing.JTextField prnI10_2;
    private javax.swing.JTextField prnI12_1;
    private javax.swing.JTextField prnI12_2;
    private javax.swing.JTextField prnI14_1;
    private javax.swing.JTextField prnI14_2;
    private javax.swing.JTextField prnI16;
    private javax.swing.JTextField prnI17;
    private javax.swing.JTextField prnI19;
    private javax.swing.JTextField prnI21;
    private javax.swing.JTextField prnI24_1;
    private javax.swing.JTextField prnI24_2;
    private javax.swing.JTextField prnI4;
    private javax.swing.JTextField prnI8_1;
    private javax.swing.JTextField prnI8_2;
    private javax.swing.JTextField prnIt2;
    private javax.swing.JTextField prnIt7_1;
    private javax.swing.JTextField prnIt7_2;
    private javax.swing.JTextField prnIt7_3;
    private javax.swing.JLabel prnL10_1;
    private javax.swing.JLabel prnL10_2;
    private javax.swing.JLabel prnL12_1;
    private javax.swing.JLabel prnL12_2;
    private javax.swing.JLabel prnL14_1;
    private javax.swing.JLabel prnL14_2;
    private javax.swing.JLabel prnL16;
    private javax.swing.JLabel prnL17;
    private javax.swing.JLabel prnL19;
    private javax.swing.JLabel prnL21;
    private javax.swing.JLabel prnL24_1;
    private javax.swing.JLabel prnL24_2;
    private javax.swing.JLabel prnL4;
    private javax.swing.JLabel prnL8_1;
    private javax.swing.JLabel prnL8_2;
    private javax.swing.JLabel prnLt2;
    private javax.swing.JLabel prnLt7_1;
    private javax.swing.JLabel prnLt7_2;
    private javax.swing.JLabel prnLt7_3;
    private javax.swing.JButton profileBst2;
    private javax.swing.JButton profileBst3;
    private javax.swing.JPanel redlineP;
    private javax.swing.JButton resetB10_1;
    private javax.swing.JButton resetB10_2;
    private javax.swing.JButton resetB11_1;
    private javax.swing.JButton resetB11_2;
    private javax.swing.JButton resetB12_1;
    private javax.swing.JButton resetB12_2;
    private javax.swing.JButton resetB13_1;
    private javax.swing.JButton resetB13_2;
    private javax.swing.JButton resetB14_1;
    private javax.swing.JButton resetB14_2;
    private javax.swing.JButton resetB15_1;
    private javax.swing.JButton resetB15_2;
    private javax.swing.JButton resetB23_1;
    private javax.swing.JButton resetB23_2;
    private javax.swing.JButton resetB24_1;
    private javax.swing.JButton resetB24_2;
    private javax.swing.JButton resetB25_1;
    private javax.swing.JButton resetB25_2;
    private javax.swing.JButton resetB8_1;
    private javax.swing.JButton resetB8_2;
    private javax.swing.JButton resetB9_1;
    private javax.swing.JButton resetB9_2;
    private javax.swing.JButton resetBt2;
    private javax.swing.JButton resetBt3;
    private javax.swing.JButton resetBt6_1;
    private javax.swing.JButton resetBt6_2;
    private javax.swing.JButton resetBt6_3;
    private javax.swing.JButton resetBt7_1;
    private javax.swing.JButton resetBt7_2;
    private javax.swing.JButton resetBt7_3;
    private javax.swing.JTextField returndateI11_1;
    private javax.swing.JTextField returndateI11_2;
    private javax.swing.JLabel returndateL11_1;
    private javax.swing.JLabel returndateL11_2;
    private javax.swing.JTextField roomnumberI15_1;
    private javax.swing.JTextField roomnumberI15_2;
    private javax.swing.JLabel roomnumberL15_1;
    private javax.swing.JLabel roomnumberL15_2;
    private javax.swing.JTextField roomtypeI21;
    private javax.swing.JLabel roomtypeL21;
    private javax.swing.JScrollPane scroll7;
    private javax.swing.JScrollPane scrollt6;
    private javax.swing.JScrollPane scrollt7_1;
    private javax.swing.JTextField semesterI24_1;
    private javax.swing.JTextField semesterI24_2;
    private javax.swing.JTextField semesterI4;
    private javax.swing.JLabel semesterL24_1;
    private javax.swing.JLabel semesterL24_2;
    private javax.swing.JLabel semesterL4;
    private javax.swing.JButton showB10;
    private javax.swing.JButton showB10_2;
    private javax.swing.JButton showB11;
    private javax.swing.JButton showB11_2;
    private javax.swing.JButton showB12;
    private javax.swing.JButton showB12_2;
    private javax.swing.JButton showB13;
    private javax.swing.JButton showB13_2;
    private javax.swing.JButton showB14;
    private javax.swing.JButton showB14_2;
    private javax.swing.JButton showB15;
    private javax.swing.JButton showB15_2;
    private javax.swing.JButton showB23;
    private javax.swing.JButton showB23_2;
    private javax.swing.JButton showB24;
    private javax.swing.JButton showB24_2;
    private javax.swing.JButton showB25;
    private javax.swing.JButton showB25_2;
    private javax.swing.JButton showB8;
    private javax.swing.JButton showB8_2;
    private javax.swing.JButton showB9;
    private javax.swing.JButton showB9_2;
    private javax.swing.JButton showBt6;
    private javax.swing.JButton showBt7;
    private javax.swing.JButton showBt7_1;
    private javax.swing.JTextField simpleroomI14_1;
    private javax.swing.JTextField simpleroomI14_2;
    private javax.swing.JLabel simpleroomL14_1;
    private javax.swing.JLabel simpleroomL14_2;
    private javax.swing.JPanel st1;
    private javax.swing.JPanel st2;
    private javax.swing.JPanel st3;
    private javax.swing.JPanel st4;
    private javax.swing.JPanel st5;
    private javax.swing.JTextField stateI24_1;
    private javax.swing.JTextField stateI24_2;
    private javax.swing.JLabel stateL24_1;
    private javax.swing.JLabel stateL24_2;
    private javax.swing.JTextField streetnameI24_1;
    private javax.swing.JTextField streetnameI24_2;
    private javax.swing.JLabel streetnameL24_1;
    private javax.swing.JLabel streetnameL24_2;
    private javax.swing.JTextField streetnumberI24_1;
    private javax.swing.JTextField streetnumberI24_2;
    private javax.swing.JLabel streetnumberL24_1;
    private javax.swing.JLabel streetnumberL24_2;
    private javax.swing.JButton studentBt1;
    private javax.swing.JButton studentdetailsBst3;
    private javax.swing.JButton studentloginBst3;
    private javax.swing.JButton submitB10_1;
    private javax.swing.JButton submitB10_2;
    private javax.swing.JButton submitB11_1;
    private javax.swing.JButton submitB11_2;
    private javax.swing.JButton submitB12_1;
    private javax.swing.JButton submitB12_2;
    private javax.swing.JButton submitB13_1;
    private javax.swing.JButton submitB13_2;
    private javax.swing.JButton submitB14_1;
    private javax.swing.JButton submitB14_2;
    private javax.swing.JButton submitB15_1;
    private javax.swing.JButton submitB15_2;
    private javax.swing.JButton submitB23_1;
    private javax.swing.JButton submitB23_2;
    private javax.swing.JButton submitB24_1;
    private javax.swing.JButton submitB24_2;
    private javax.swing.JButton submitB25_1;
    private javax.swing.JButton submitB25_2;
    private javax.swing.JButton submitB8_1;
    private javax.swing.JButton submitB8_2;
    private javax.swing.JButton submitB9_1;
    private javax.swing.JButton submitB9_2;
    private javax.swing.JButton submitBt2;
    private javax.swing.JButton submitBt3;
    private javax.swing.JButton submitBt6_1;
    private javax.swing.JButton submitBt6_2;
    private javax.swing.JButton submitBt6_3;
    private javax.swing.JButton submitBt7_2;
    private javax.swing.JButton submitBt7_3;
    private javax.swing.JPanel t10AdAttendance;
    private javax.swing.JPanel t10_1Add;
    private javax.swing.JPanel t10_2Update;
    private javax.swing.JPanel t11AdLibrary;
    private javax.swing.JPanel t11_1Add;
    private javax.swing.JPanel t11_2Update;
    private javax.swing.JPanel t12AdFees;
    private javax.swing.JPanel t12_1Add;
    private javax.swing.JPanel t12_2Update;
    private javax.swing.JPanel t13AdCourse;
    private javax.swing.JPanel t13_1Add;
    private javax.swing.JPanel t13_2Update;
    private javax.swing.JPanel t14AdHostel;
    private javax.swing.JPanel t14_1Add;
    private javax.swing.JPanel t14_2Update;
    private javax.swing.JPanel t15AdTimeT;
    private javax.swing.JPanel t15_1Add;
    private javax.swing.JPanel t15_2Update;
    private javax.swing.JPanel t16StuGrades;
    private javax.swing.JPanel t17StuAttendance;
    private javax.swing.JPanel t18StuLibrary;
    private javax.swing.JPanel t19StuFees;
    private javax.swing.JPanel t1Main;
    private javax.swing.JPanel t20StuCourse;
    private javax.swing.JPanel t21StuHostel;
    private javax.swing.JPanel t22StuTimeT;
    private javax.swing.JPanel t23AdBranch;
    private javax.swing.JPanel t23_1Add;
    private javax.swing.JPanel t23_2Update;
    private javax.swing.JPanel t24AdStudentDetails;
    private javax.swing.JPanel t24_1Add;
    private javax.swing.JPanel t24_2Update;
    private javax.swing.JPanel t25AdAdminDetails;
    private javax.swing.JPanel t25_1Add;
    private javax.swing.JPanel t25_2Update;
    private javax.swing.JPanel t2StuLogin;
    private javax.swing.JPanel t3Adlogin;
    private javax.swing.JPanel t4StuMenu;
    private javax.swing.JPanel t5AdMenu;
    private javax.swing.JPanel t6AdLogin;
    private javax.swing.JPanel t6_1AdUpdate;
    private javax.swing.JPanel t6_2AdAdd;
    private javax.swing.JPanel t6_3AdDelete;
    private javax.swing.JPanel t7StuLogin;
    private javax.swing.JPanel t7_1StuUpdate;
    private javax.swing.JPanel t7_2StuAdd;
    private javax.swing.JPanel t7_3StuDelete;
    private javax.swing.JPanel t8AdGrades;
    private javax.swing.JPanel t8_1Add;
    private javax.swing.JPanel t8_2Update;
    private javax.swing.JPanel t9AdFaculty;
    private javax.swing.JPanel t9_1Add;
    private javax.swing.JPanel t9_2Update;
    private javax.swing.JButton timetableBst2;
    private javax.swing.JButton timetableBst3;
    private javax.swing.JTextField timetableidI15_1;
    private javax.swing.JTextField timetableidI15_2;
    private javax.swing.JLabel timetableidL15_1;
    private javax.swing.JLabel timetableidL15_2;
    private javax.swing.JTextField timingsI15_1;
    private javax.swing.JTextField timingsI15_2;
    private javax.swing.JLabel timingsL15_1;
    private javax.swing.JLabel timingsL15_2;
    private javax.swing.JButton updateB10;
    private javax.swing.JButton updateB11;
    private javax.swing.JButton updateB12;
    private javax.swing.JButton updateB13;
    private javax.swing.JButton updateB14;
    private javax.swing.JButton updateB15;
    private javax.swing.JButton updateB23;
    private javax.swing.JButton updateB24;
    private javax.swing.JButton updateB25;
    private javax.swing.JButton updateB8;
    private javax.swing.JButton updateB9;
    private javax.swing.JButton updateBt6;
    private javax.swing.JButton updateBt7;
    private javax.swing.JButton updateBt7_1;
    private javax.swing.JTextField yearI24_1;
    private javax.swing.JTextField yearI24_2;
    private javax.swing.JTextField yearI4;
    private javax.swing.JLabel yearL24_1;
    private javax.swing.JLabel yearL24_2;
    private javax.swing.JLabel yearL4;
    private javax.swing.JTextField zipcodeI24_1;
    private javax.swing.JTextField zipcodeI24_2;
    private javax.swing.JLabel zipcodeL24_1;
    private javax.swing.JLabel zipcodeL24_2;
    // End of variables declaration//GEN-END:variables
}
